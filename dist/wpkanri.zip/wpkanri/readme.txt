=== WPKanri ===
Contributors: kanripress
Tags: maintenance, backup, monitoring, security, checksum
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 0.0.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight connector plugin that links this WordPress site to the WPKanri cloud (assist.kanripress.com) for backups, monitoring, updates, and scans.

== 動作環境 ==

**WordPress:**

* 最低要件: **WordPress 6.0** 以上(6.0.x の全マイナー/パッチを含む)
* 動作確認済み: **WordPress 6.9.x** まで(6.0 〜 6.9 系の全パッチリリース対応)
* 6.10 以降も互換性維持を方針(WP の破壊的変更があれば対応版をリリース)
* 6.0 未満では REST API / Settings API の挙動差で動作しない可能性あり

**PHP:**

* 最低要件: **PHP 7.4** 以上
* 動作確認済み (構文チェック pass): **PHP 7.4 / 8.0 / 8.2 / 8.4 / 8.5**
* PHP 7.3 以前は typed property 構文(`private static ?Class $instance`)が使えないため非対応
* 最新の PHP 8.5 までサポート。今後の 8.x 系も互換性維持を方針とする

**外部依存:**

* assist.kanripress.com (Cloudflare Workers) への HTTPS 接続
* `wp_remote_*`・`wp-cron` が動作すること
* JavaScript 有効のブラウザ(RUM 収集のため。ただし RUM だけオフでも他機能は動作)

== Description ==

WPKanri はコネクタ専用の軽量プラグインです。本体の処理はクラウド側(assist.kanripress.com)で行うため、共有ホスティングでも安心して利用できます。

Phase 1 MVP で提供する機能:

* コンパネ (assist.kanripress.com) への接続設定と API キー管理
* サイトの自動登録
* WordPress コアファイルの改ざんスキャン(Worker の wp.org チェックサム DB と照合)
* 外部死活監視用のヘルスエンドポイント (/wp-json/wpkanri/v1/health)
* 日次スキャンの WP Cron 登録
* RUM (Core Web Vitals 実ユーザー計測) — web-vitals.js による LCP/INP/CLS/FCP/TTFB 自動収集
* PHP エラー監視 — E_WARNING + Fatal Error を自動キャプチャ、AI 解析付き
* CO2 排出量トラッキング — ページ転送バイト数からカーボン計測

将来追加予定(Phase 2 以降):

* バックアップ・復元
* アップデート管理(VRT + 信頼スコア)
* Emergency Connector(WP 停止時の 1 クリック復元)

== Installation ==

1. https://github.com/KanriPress/wpkanri/releases/latest から `wpkanri.zip` をダウンロードします
2. WordPress 管理画面で「プラグイン」→「新規追加」→「プラグインのアップロード」から ZIP を選択してインストールします
3. 「プラグインを有効化」を押すと、自動で「設定」→「WPKanri」に誘導されます
4. 「接続する」ボタンを押すとコンパネにリダイレクトされ、承認すると API キーが自動発行されてサイトに返却されます
5. 「今すぐスキャン」で初回スキャンを実行します

将来 WordPress.org プラグインディレクトリからも配信予定。公開後は `プラグイン > 新規追加` から「WPKanri」で検索可能になります。

== Updates ==

インストール済みの WPKanri は WordPress 標準の更新通知経路を使います。
新しいリリースが GitHub に公開されると、最大 12 時間以内に「プラグイン」画面に
「更新があります」と表示され、ワンクリックで適用できます (Plugin Update Checker 経由)。

自動更新を無効化する場合は `wp-config.php` に以下を追加してください:

`define( 'WPKANRI_DISABLE_AUTO_UPDATE', true );`

フォークを配信元にする場合:

`define( 'WPKANRI_GITHUB_REPO', 'my-agency/my-fork' );`

== Frequently Asked Questions ==

= API キーはどこで発行しますか？ =

assist.kanripress.com にログインし、「設定」→「API キー」→「新しい API キーを発行」から作成できます。発行時のみ平文で表示されるので、このプラグインの「API キー」欄に貼り付けてください。

= スキャンはどのくらい重いですか？ =

wp-admin / wp-includes の全 PHP・JS・CSS ファイル(通常 1800〜2000 件)の md5 を計算し、チャンクに分けて Worker に送信します。共有ホスティングで 30〜60 秒程度です。

= エージェンシーとしてホワイトラベルで使いたい =

以下を wp-config.php で定義すると、全画面通知・有効化リダイレクト・プロモーション文言が非表示になります:

`define( 'WPKANRI_WHITELABEL', true );`

ブランド名を独自のものに差し替える場合:

`define( 'WPKANRI_BRAND_NAME', 'My Agency Care' );`
`define( 'WPKANRI_BRAND_DESCRIPTION', 'サイトを My Agency の保守クラウドに接続します。' );`

プログラマブルに制御したい場合は mu-plugin からフィルターで:

`add_filter( 'wpkanri_whitelabel_mode', '__return_true' );`
`add_filter( 'wpkanri_brand_name', fn() => 'My Agency Care' );`

== Changelog ==

= 0.0.4 =
* 5 分ごとのステータス ポーリング (`/api/v1/public/sites/:id/status`) を追加
* Branded Maintenance: `.htaccess` + 静的 HTML による 503 応答 (WP 停止時も動作)
* 管理者バイパス用 Cookie + mu-plugin を自動設置 (nginx/IIS 環境のフォールバック)
* アップデート自動適用 (safe / fast / scheduled モード): WP_Upgrader + メンテナンスモード連動
* 日次アップデート検知: plugins/themes/core を Worker へレポート
* アクティビティログ送信 (plugin/theme 有効化・更新・ユーザー作成・設定変更)
* 増分バックアップ作成 + R2 へのアップロード (presigned PUT) + manifest 報告
* コードスニペット実行: hourly ポーリング + SHA-256 整合性検証 + サンドボックス実行
* Emergency Connector: `wp-content/kanripress_emergency_<random>.php` を自動設置 (WP 停止時復元用)
* 接続オプション活用: 外向き HTTP に Basic 認証を注入するフィルター
* サイト移行ヘルパー `apply_backup` 実装 (Worker 生成・シリアライズ対応 URL 置換)
* キャッシュクリア対応拡張: W3TC / Rocket / LSCache / Super Cache / Autoptimize / Cache Enabler / Breeze / SG Optimizer / Kinsta / Cloudflare
* DB 最適化: revision / 期限切れ transient / orphan postmeta 削除 + OPTIMIZE TABLE

= 0.0.3 =
* ワンクリック接続(OAuth 風リダイレクト) — 「接続する」ボタンで assist.kanripress.com に遷移→承認→API キー自動返却
* 手動 API キー入力はフォールバックとして温存
* 初期セットアップウィザード — 有効化直後にリダイレクト + 全画面通知 + 設定ページにステップ表示
* ホワイトラベル対応 — 定数/フィルターで通知・ブランド名を抑制/差し替え可能(エージェンシー向け)
* 中立プラグイン名 (WPKanri) に改名 — ホワイトラベル時の顧客側露出を最小化
* GitHub Releases 経由の自動更新 — Plugin Update Checker v5.6 を同梱、WP 標準の更新通知に統合

= 0.0.2 =
* RUM (Core Web Vitals) 自動収集 — web-vitals.js v4 を wp_footer に挿入
* PHP エラー監視 — E_WARNING + Fatal Error を非ブロッキングで Worker に送信
* CO2 カーボントラッキング — ページ転送バイト数を自動計測・送信

= 0.0.1 =
* 初回リリース(Phase 1 MVP)
* 接続設定・サイト登録・コアチェックサムスキャン・ヘルスエンドポイント
