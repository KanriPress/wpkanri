<?php
/**
 * Legacy Maintenance — creates the WP-native `.maintenance` file at
 * ABSPATH which makes WP core short-circuit to `wp_maintenance()`.
 *
 * Used as a fallback / secondary layer for environments where the
 * Branded_Maintenance `.htaccess` approach does not fire (nginx, IIS).
 * Both run together on every maintenance state change so whichever
 * layer the server honours will serve the maintenance page.
 *
 * A companion mu-plugin (kanripress-maintenance-mu.php) is dropped into
 * wp-content/mu-plugins/ so we can customize the message text and also
 * act as the nginx fallback for serving the branded HTML directly.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Maintenance {

	private const FLAG_FILE         = '.maintenance';
	private const MU_PLUGIN_NAME    = 'kanripress-maintenance-mu.php';
	private const OPT_MESSAGE       = 'wpkanri_maintenance_message';
	private const OPT_REASON        = 'wpkanri_maintenance_reason';
	private const OPT_BYPASS_TOKEN  = 'wpkanri_maintenance_bypass_token';

	private static ?Maintenance $instance = null;

	public static function instance(): Maintenance {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function enable( string $message = '', string $reason = 'manual' ): bool {
		update_option( self::OPT_MESSAGE, $message );
		update_option( self::OPT_REASON, $reason );
		$this->ensure_mu_plugin();
		$this->ensure_bypass_token();
		return $this->write_flag_file();
	}

	public function disable(): bool {
		delete_option( self::OPT_MESSAGE );
		delete_option( self::OPT_REASON );
		return $this->remove_flag_file();
	}

	public function is_active(): bool {
		return file_exists( ABSPATH . self::FLAG_FILE );
	}

	/**
	 * Generate or return the 32-hex admin bypass token. This is the same
	 * token used by Branded_Maintenance for the `kanripress_bypass` cookie.
	 */
	public function get_bypass_token(): string {
		$token = (string) get_option( self::OPT_BYPASS_TOKEN, '' );
		if ( '' === $token || ! preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
			$token = $this->ensure_bypass_token();
		}
		return $token;
	}

	// ── Internal ─────────────────────────────────────────────

	private function ensure_bypass_token(): string {
		$token = bin2hex( random_bytes( 16 ) );
		update_option( self::OPT_BYPASS_TOKEN, $token );
		return $token;
	}

	private function write_flag_file(): bool {
		$path = ABSPATH . self::FLAG_FILE;
		// WP checks that the file's mtime is within the last 10 minutes, so
		// re-touch on every call.
		$content = '<?php $upgrading = ' . time() . '; ?>';
		$result  = @file_put_contents( $path, $content );
		return false !== $result;
	}

	private function remove_flag_file(): bool {
		$path = ABSPATH . self::FLAG_FILE;
		if ( ! file_exists( $path ) ) {
			return true;
		}
		return @unlink( $path );
	}

	/**
	 * Install the mu-plugin that overrides `wp_maintenance()` message text
	 * and also serves as the non-Apache fallback for Branded Maintenance.
	 */
	private function ensure_mu_plugin(): void {
		$mu_dir = defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins';
		if ( ! is_dir( $mu_dir ) ) {
			@wp_mkdir_p( $mu_dir );
		}
		$target = trailingslashit( $mu_dir ) . self::MU_PLUGIN_NAME;
		$source = WPKANRI_PLUGIN_DIR . 'assets/mu/' . self::MU_PLUGIN_NAME;
		if ( ! file_exists( $source ) ) {
			return;
		}
		// Only (re)write when the source differs — reduces pointless fs writes.
		if ( file_exists( $target ) && @md5_file( $target ) === @md5_file( $source ) ) {
			return;
		}
		@copy( $source, $target );
	}
}
