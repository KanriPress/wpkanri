<?php
/**
 * Update Detector — runs daily, reads the standard WP update transients,
 * and reports what is available to the Worker so the dashboard / AI can
 * decide when and how to roll them out.
 *
 * Does NOT apply updates — that is the Worker-driven `pending_updates`
 * flow in Update_Processor.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Update_Detector {

	public const CRON_HOOK = 'wpkanri_update_detect';

	private static ?Update_Detector $instance = null;

	public static function instance(): Update_Detector {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( self::CRON_HOOK, array( $this, 'run' ) );
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			// Stagger away from the scan cron by 6 hours.
			wp_schedule_event( time() + 6 * HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	public static function unschedule(): void {
		$ts = wp_next_scheduled( self::CRON_HOOK );
		if ( false !== $ts ) {
			wp_unschedule_event( $ts, self::CRON_HOOK );
		}
	}

	public function run(): void {
		$connector = Connector::instance();
		if ( ! $connector->is_setup_complete() ) {
			return;
		}

		// Nudge WP to refresh its update caches without spamming wp.org.
		if ( function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
		}
		if ( function_exists( 'wp_update_themes' ) ) {
			wp_update_themes();
		}
		if ( function_exists( 'wp_version_check' ) ) {
			wp_version_check();
		}

		$updates = $this->collect();
		if ( empty( $updates ) ) {
			return;
		}

		$client = new Api_Client();
		$client->report_detected_updates( $connector->get_site_id(), $updates );
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	private function collect(): array {
		$out = array();

		// ── Plugins ──
		$plugin_updates = get_site_transient( 'update_plugins' );
		if ( is_object( $plugin_updates ) && isset( $plugin_updates->response ) && is_array( $plugin_updates->response ) ) {
			foreach ( $plugin_updates->response as $file => $info ) {
				$slug = isset( $info->slug ) ? (string) $info->slug : explode( '/', (string) $file )[0];
				$from = '';
				if ( function_exists( 'get_plugin_data' ) ) {
					$data = @get_plugin_data( WP_PLUGIN_DIR . '/' . $file, false, false );
					$from = isset( $data['Version'] ) ? (string) $data['Version'] : '';
				}
				$out[] = array(
					'component'    => 'plugin',
					'slug'         => $slug,
					'from_version' => $from,
					'to_version'   => isset( $info->new_version ) ? (string) $info->new_version : '',
				);
			}
		}

		// ── Themes ──
		$theme_updates = get_site_transient( 'update_themes' );
		if ( is_object( $theme_updates ) && isset( $theme_updates->response ) && is_array( $theme_updates->response ) ) {
			foreach ( $theme_updates->response as $slug => $info ) {
				$from = '';
				$theme = wp_get_theme( (string) $slug );
				if ( $theme->exists() ) {
					$from = (string) $theme->get( 'Version' );
				}
				$new = is_array( $info ) && isset( $info['new_version'] ) ? (string) $info['new_version'] : '';
				$out[] = array(
					'component'    => 'theme',
					'slug'         => (string) $slug,
					'from_version' => $from,
					'to_version'   => $new,
				);
			}
		}

		// ── Core ──
		$core_updates = get_site_transient( 'update_core' );
		if ( is_object( $core_updates ) && isset( $core_updates->updates ) && is_array( $core_updates->updates ) ) {
			foreach ( $core_updates->updates as $core ) {
				if ( isset( $core->response ) && 'upgrade' === $core->response ) {
					$out[] = array(
						'component'    => 'core',
						'slug'         => '',
						'from_version' => (string) get_bloginfo( 'version' ),
						'to_version'   => isset( $core->current ) ? (string) $core->current : '',
					);
					break;
				}
			}
		}

		return $out;
	}
}
