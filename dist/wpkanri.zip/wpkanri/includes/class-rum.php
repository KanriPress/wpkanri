<?php
/**
 * RUM (Real User Monitoring) — web-vitals.js injection.
 *
 * Enqueues web-vitals.js (IIFE build) and wpkanri-rum.js on the public
 * frontend. The JS collects Core Web Vitals (LCP, INP, CLS, FCP, TTFB) and
 * transfer bytes, then sends them to the KanriPress Worker via fetch with
 * keepalive on page visibility change / unload.
 *
 * Only active when site_id and api_key are both configured.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Rum {

	private static ?Rum $instance = null;

	public static function instance(): Rum {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		// Only inject on the public frontend, not in wp-admin.
		if ( is_admin() ) {
			return;
		}

		$connector = Connector::instance();
		if ( ! $connector->has_api_key() || ! $connector->is_registered() ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	public function enqueue(): void {
		$connector = Connector::instance();
		$api_base  = $connector->get_api_base();
		$version   = WPKANRI_VERSION;
		$base_url  = WPKANRI_PLUGIN_URL . 'assets/js/';

		// 1. web-vitals IIFE (~7 KB uncompressed, ~3 KB gzip).
		wp_enqueue_script(
			'wpkanri-web-vitals',
			$base_url . 'web-vitals.iife.js',
			array(),
			$version,
			true // in_footer — boolean form for WP 6.0+ compat.
		);

		// 2. Our beacon script — depends on web-vitals.
		wp_enqueue_script(
			'wpkanri-rum',
			$base_url . 'wpkanri-rum.js',
			array( 'wpkanri-web-vitals' ),
			$version,
			true // in_footer — boolean form for WP 6.0+ compat.
		);

		// 3. Pass config to JS.
		wp_localize_script(
			'wpkanri-rum',
			'wpkanriRumConfig',
			array(
				'endpoint'       => untrailingslashit( $api_base ) . '/api/v1/public/rum',
				'carbonEndpoint' => untrailingslashit( $api_base ) . '/api/v1/public/carbon',
				'apiKey'         => $connector->get_api_key(),
				'siteId'         => $connector->get_site_id(),
			)
		);
	}
}
