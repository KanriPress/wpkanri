<?php
/**
 * RUM (Real User Monitoring) — web-vitals.js injection.
 *
 * Enqueues web-vitals.js (IIFE build) and wpkanri-rum.js on the public
 * frontend. The JS collects Core Web Vitals (LCP, INP, CLS, FCP, TTFB) and
 * transfer bytes, then POSTs them to a same-origin admin-ajax endpoint
 * which proxies to the KanriPress Worker. The API key never leaves the
 * server — visitors only see the ajax URL + site_id.
 *
 * Only active when site_id and api_key are both configured.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Rum {

	public const AJAX_RUM    = 'wpkanri_rum';
	public const AJAX_CARBON = 'wpkanri_rum_carbon';

	private static ?Rum $instance = null;

	public static function instance(): Rum {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		// Ajax proxy — must register regardless of is_admin() so frontend
		// POSTs to /wp-admin/admin-ajax.php hit our handlers. wp_ajax_nopriv_*
		// covers logged-out visitors (the normal RUM audience).
		add_action( 'wp_ajax_nopriv_' . self::AJAX_RUM,    array( $this, 'handle_rum_ajax' ) );
		add_action( 'wp_ajax_' . self::AJAX_RUM,           array( $this, 'handle_rum_ajax' ) );
		add_action( 'wp_ajax_nopriv_' . self::AJAX_CARBON, array( $this, 'handle_carbon_ajax' ) );
		add_action( 'wp_ajax_' . self::AJAX_CARBON,        array( $this, 'handle_carbon_ajax' ) );

		// Script injection only on the public frontend, not in wp-admin.
		if ( is_admin() ) {
			return;
		}

		$connector = Connector::instance();
		if ( ! $connector->has_api_key() || ! $connector->is_registered() ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	public function enqueue(): void {
		$connector = Connector::instance();
		$version   = WPKANRI_VERSION;
		$base_url  = WPKANRI_PLUGIN_URL . 'assets/js/';

		// 1. web-vitals IIFE (~7 KB uncompressed, ~3 KB gzip).
		wp_enqueue_script(
			'wpkanri-web-vitals',
			$base_url . 'web-vitals.iife.js',
			array(),
			$version,
			true
		);

		// 2. Our beacon script — depends on web-vitals.
		wp_enqueue_script(
			'wpkanri-rum',
			$base_url . 'wpkanri-rum.js',
			array( 'wpkanri-web-vitals' ),
			$version,
			true
		);

		// 3. Pass config to JS. NOTE: api_key is deliberately omitted — the
		// beacons go to same-origin admin-ajax, which proxies to the Worker
		// server-side with the API key added there.
		wp_localize_script(
			'wpkanri-rum',
			'wpkanriRumConfig',
			array(
				'endpoint'       => admin_url( 'admin-ajax.php?action=' . self::AJAX_RUM ),
				'carbonEndpoint' => admin_url( 'admin-ajax.php?action=' . self::AJAX_CARBON ),
				'siteId'         => $connector->get_site_id(),
			)
		);
	}

	// ── Ajax proxies ─────────────────────────────────────────

	public function handle_rum_ajax(): void {
		$payload = $this->read_json_payload();
		$site_id = isset( $payload['site_id'] ) ? sanitize_text_field( (string) $payload['site_id'] ) : '';
		$expected_site_id = Connector::instance()->get_site_id();
		if ( '' === $expected_site_id || '' === $site_id || ! hash_equals( $expected_site_id, $site_id ) ) {
			wp_send_json_error( null, 400 );
		}

		$metrics = array(
			'site_id'  => $expected_site_id,
			'page_url' => isset( $payload['page_url'] ) ? esc_url_raw( (string) $payload['page_url'] ) : '',
			'device'   => isset( $payload['device'] ) ? sanitize_key( (string) $payload['device'] ) : '',
		);
		foreach ( array( 'lcp', 'inp', 'fcp', 'ttfb' ) as $int_key ) {
			if ( isset( $payload[ $int_key ] ) && is_numeric( $payload[ $int_key ] ) ) {
				$metrics[ $int_key ] = max( 0, (int) $payload[ $int_key ] );
			}
		}
		if ( isset( $payload['cls'] ) && is_numeric( $payload['cls'] ) ) {
			$metrics['cls'] = max( 0.0, (float) $payload['cls'] );
		}

		( new Api_Client() )->send_rum( $expected_site_id, $metrics );

		// Return a 204-equivalent quickly so keepalive beacons unwind.
		wp_send_json_success();
	}

	public function handle_carbon_ajax(): void {
		$payload = $this->read_json_payload();
		$site_id = isset( $payload['site_id'] ) ? sanitize_text_field( (string) $payload['site_id'] ) : '';
		$expected_site_id = Connector::instance()->get_site_id();
		if ( '' === $expected_site_id || '' === $site_id || ! hash_equals( $expected_site_id, $site_id ) ) {
			wp_send_json_error( null, 400 );
		}

		$bytes    = isset( $payload['bytes'] ) && is_numeric( $payload['bytes'] ) ? max( 0, (int) $payload['bytes'] ) : 0;
		$page_url = isset( $payload['page_url'] ) ? esc_url_raw( (string) $payload['page_url'] ) : '';
		if ( $bytes <= 0 ) {
			wp_send_json_success();
		}

		// send_carbon is blocking by design (it returns WP_Error on failure);
		// we intentionally swallow the result because the visitor is unloading.
		( new Api_Client() )->send_carbon( $expected_site_id, $bytes, $page_url );
		wp_send_json_success();
	}

	/**
	 * Read + decode JSON body. Cap size to keep the request cheap.
	 *
	 * @return array<string,mixed>
	 */
	private function read_json_payload(): array {
		$raw = file_get_contents( 'php://input' );
		if ( ! is_string( $raw ) || '' === $raw ) {
			return array();
		}
		if ( strlen( $raw ) > 8192 ) {
			return array();
		}
		$decoded = json_decode( $raw, true );
		return is_array( $decoded ) ? $decoded : array();
	}
}
