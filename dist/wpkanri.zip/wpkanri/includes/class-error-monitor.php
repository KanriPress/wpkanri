<?php
/**
 * PHP Error Monitor — captures E_WARNING and fatal errors.
 *
 * Registers a custom error handler (for warnings) and a shutdown function
 * (for fatal errors) and sends each unique error to the KanriPress Worker
 * via a non-blocking wp_remote_post.
 *
 * Only active when site_id and api_key are both configured.
 * Does NOT require WP_DEBUG to be enabled.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Error_Monitor {

	/**
	 * Maximum errors sent per PHP request to avoid flooding.
	 */
	private const MAX_ERRORS_PER_REQUEST = 5;

	/**
	 * Fatal error types captured via shutdown function.
	 */
	private const FATAL_TYPES = E_ERROR | E_COMPILE_ERROR | E_PARSE | E_CORE_ERROR;

	private static ?Error_Monitor $instance = null;

	/** @var array<string,true> Dedup set for the current request. */
	private array $seen = array();

	/** @var int Counter of errors sent in the current request. */
	private int $sent_count = 0;

	public static function instance(): Error_Monitor {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		$connector = Connector::instance();
		if ( ! $connector->has_api_key() || ! $connector->is_registered() ) {
			return;
		}

		// Register on `init` so WordPress core is loaded.
		add_action( 'init', array( $this, 'register_handlers' ), 1 );
	}

	public function register_handlers(): void {
		set_error_handler( array( $this, 'handle_error' ), E_WARNING | E_USER_WARNING );
		register_shutdown_function( array( $this, 'handle_shutdown' ) );
	}

	/**
	 * Custom error handler — captures E_WARNING and E_USER_WARNING.
	 *
	 * @return false Always returns false so PHP's default handler still runs.
	 */
	public function handle_error( int $errno, string $errstr, string $errfile = '', int $errline = 0 ): bool {
		$this->dispatch( 'warning', $errstr, $errfile, $errline );

		// Return false to let PHP's built-in handler run as well.
		return false;
	}

	/**
	 * Shutdown function — captures fatal errors that set_error_handler cannot.
	 */
	public function handle_shutdown(): void {
		$error = error_get_last();
		if ( null === $error ) {
			return;
		}
		if ( 0 === ( $error['type'] & self::FATAL_TYPES ) ) {
			return;
		}

		$this->dispatch(
			'error',
			$error['message'] ?? '',
			$error['file'] ?? '',
			$error['line'] ?? 0
		);
	}

	// ── Internal ─────────────────────────────────────────────

	private function dispatch( string $severity, string $message, string $file, int $line ): void {
		if ( $this->sent_count >= self::MAX_ERRORS_PER_REQUEST ) {
			return;
		}

		// Deduplicate within the same request.
		$hash = md5( $severity . $message . $file );
		if ( isset( $this->seen[ $hash ] ) ) {
			return;
		}
		$this->seen[ $hash ] = true;

		$connector = Connector::instance();
		$api_base  = $connector->get_api_base();
		$api_key   = $connector->get_api_key();
		$site_id   = $connector->get_site_id();

		if ( '' === $api_key || '' === $site_id ) {
			return;
		}

		// Strip ABSPATH from file path to avoid leaking server paths.
		$safe_file = $this->sanitize_path( $file );

		$body = array(
			'site_id'  => $site_id,
			'severity' => $severity,
			'message'  => mb_substr( $message, 0, 2000 ),
			'file'     => $safe_file,
			'line'     => $line,
		);

		wp_remote_post(
			untrailingslashit( $api_base ) . '/api/v1/public/errors',
			array(
				'method'   => 'POST',
				'timeout'  => 1,
				'blocking' => false,
				'headers'  => array(
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'     => wp_json_encode( $body ),
			)
		);

		++$this->sent_count;
	}

	/**
	 * Remove ABSPATH from file paths so full server paths are not transmitted.
	 */
	private function sanitize_path( string $path ): string {
		if ( '' === $path ) {
			return '';
		}
		$abspath = defined( 'ABSPATH' ) ? ABSPATH : '';
		if ( '' !== $abspath && 0 === strpos( $path, $abspath ) ) {
			return substr( $path, strlen( $abspath ) );
		}
		return basename( $path );
	}
}
