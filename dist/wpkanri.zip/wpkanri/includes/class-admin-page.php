<?php
/**
 * Admin settings page for WPKanri.
 *
 * Uses WP's Settings API for the persisted fields (API base / API key) and
 * admin-post.php endpoints for the action buttons (test connection, register
 * site, run scan). Everything sits under Settings → WPKanri.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Admin_Page {

	private const MENU_SLUG         = 'wpkanri';
	private const OPTION_GROUP      = 'wpkanri_settings';
	private const ACTION_TEST       = 'wpkanri_test';
	private const ACTION_REGISTER   = 'wpkanri_register';
	private const ACTION_SCAN       = 'wpkanri_scan';
	private const ACTION_CONNECT    = 'wpkanri_connect';
	private const ACTION_CALLBACK   = 'wpkanri_connect_callback';
	private const ACTION_SCHEDULE   = 'wpkanri_save_schedule';
	private const NOTICE_TRANSIENT  = 'wpkanri_notice';
	private const STATE_TRANSIENT   = 'wpkanri_connect_state';
	private const STATE_TTL         = 15 * MINUTE_IN_SECONDS;

	private static ?Admin_Page $instance = null;

	public static function instance(): Admin_Page {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_init', array( $this, 'maybe_activation_redirect' ) );
		add_action( 'admin_notices', array( $this, 'render_notices' ) );
		add_action( 'admin_notices', array( $this, 'render_setup_notice' ) );

		add_action( 'admin_post_' . self::ACTION_TEST, array( $this, 'handle_test' ) );
		add_action( 'admin_post_' . self::ACTION_REGISTER, array( $this, 'handle_register' ) );
		add_action( 'admin_post_' . self::ACTION_SCAN, array( $this, 'handle_scan' ) );
		add_action( 'admin_post_' . self::ACTION_CONNECT, array( $this, 'handle_connect_start' ) );
		add_action( 'admin_post_' . self::ACTION_CALLBACK, array( $this, 'handle_connect_callback' ) );
		add_action( 'admin_post_' . self::ACTION_SCHEDULE, array( $this, 'handle_save_schedule' ) );
	}

	// ── Activation redirect / setup notice ───────────────────

	/**
	 * One-shot redirect to the settings page right after plugin activation.
	 * Guarded by a 30 sec transient so it never fires twice. Skipped in
	 * white-label mode to avoid revealing the KanriPress URL to end clients.
	 */
	public function maybe_activation_redirect(): void {
		if ( ! get_transient( 'wpkanri_activation_redirect' ) ) {
			return;
		}
		delete_transient( 'wpkanri_activation_redirect' );

		// Never redirect on bulk-activate, multisite network activate, or AJAX.
		if ( isset( $_GET['activate-multi'] ) || wp_doing_ajax() || is_network_admin() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( Connector::instance()->is_whitelabel_mode() ) {
			return;
		}

		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::MENU_SLUG . '&welcome=1' ) );
		exit;
	}

	/**
	 * Global admin notice shown on every admin page (except our own settings
	 * page) when setup is not yet complete. Acts as the "setup wizard" entry
	 * point — one-line prompt with a CTA button to the settings page.
	 *
	 * Entirely suppressed in white-label mode so agency clients do not see
	 * any reference to KanriPress on their site.
	 */
	public function render_setup_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$connector = Connector::instance();
		if ( $connector->is_setup_complete() ) {
			return;
		}
		if ( $connector->is_whitelabel_mode() ) {
			return;
		}

		// Avoid double messaging on our own page (the page already shows the
		// inline wizard).
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false !== strpos( (string) $screen->id, self::MENU_SLUG ) ) {
			return;
		}

		$url = admin_url( 'options-general.php?page=' . self::MENU_SLUG );
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a href="%3$s" class="button button-primary" style="margin-left:8px;">%4$s</a></p></div>',
			esc_html( $connector->get_brand_name() . ':' ),
			esc_html__( '初期セットアップが完了していません。クラウドに接続してサイトを保護してください。', 'wpkanri' ),
			esc_url( $url ),
			esc_html__( '設定を続ける', 'wpkanri' )
		);
	}

	public function register_menu(): void {
		$brand = Connector::instance()->get_brand_name();
		add_options_page(
			$brand,
			$brand,
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function register_settings(): void {
		register_setting(
			self::OPTION_GROUP,
			Connector::instance()->opt_key( 'api_base' ),
			array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
				'default'           => WPKANRI_DEFAULT_API_BASE,
			)
		);
		register_setting(
			self::OPTION_GROUP,
			Connector::instance()->opt_key( 'api_key' ),
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_api_key' ),
				'default'           => '',
			)
		);
	}

	public function sanitize_api_key( $value ): string {
		$value = is_string( $value ) ? trim( $value ) : '';
		// If the field was left as the masked placeholder, keep the existing key.
		if ( '' === $value || false !== strpos( $value, '…' ) ) {
			return Connector::instance()->get_api_key();
		}
		return sanitize_text_field( $value );
	}

	// ── Page render ──────────────────────────────────────────

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$connector = Connector::instance();
		$api_base  = $connector->get_api_base();
		$masked    = $connector->masked_api_key();
		$site_id   = $connector->get_site_id();
		$last_scan = $connector->get_last_scan();
		$brand     = $connector->get_brand_name();
		$host      = wp_parse_url( $api_base, PHP_URL_HOST ) ?: 'assist.kanripress.com';

		$connected = $connector->has_api_key() && '' !== $site_id;
		$action_url = admin_url( 'admin-post.php' );
		?>
		<div class="wrap wpkanri-admin">
			<?php $this->render_admin_styles(); ?>

			<h1 class="wpkanri-admin__title"><?php echo esc_html( $brand ); ?></h1>
			<p class="wpkanri-admin__subtitle"><?php echo esc_html( $connector->get_brand_description() ); ?></p>

			<?php $this->render_setup_wizard( $connector, $site_id, $last_scan ); ?>

			<div class="wpkanri-cards">

				<!-- ── Connection status card ────────────────────────── -->
				<section class="wpkanri-card wpkanri-card--status" aria-labelledby="wpkanri-status-title">
					<header class="wpkanri-card__header">
						<h2 id="wpkanri-status-title" class="wpkanri-card__title">
							<?php echo esc_html__( '接続状態', 'wpkanri' ); ?>
						</h2>
						<?php if ( $connected ) : ?>
							<span class="wpkanri-badge wpkanri-badge--ok">
								<span aria-hidden="true">●</span>
								<?php echo esc_html__( '接続済み', 'wpkanri' ); ?>
							</span>
						<?php else : ?>
							<span class="wpkanri-badge wpkanri-badge--warn">
								<span aria-hidden="true">●</span>
								<?php echo esc_html__( '未接続', 'wpkanri' ); ?>
							</span>
						<?php endif; ?>
					</header>
					<div class="wpkanri-card__body">
						<?php if ( $connected ) : ?>
							<dl class="wpkanri-meta">
								<div class="wpkanri-meta__row">
									<dt><?php echo esc_html__( '接続先', 'wpkanri' ); ?></dt>
									<dd><code><?php echo esc_html( $host ); ?></code></dd>
								</div>
								<div class="wpkanri-meta__row">
									<dt><?php echo esc_html__( 'サイト ID', 'wpkanri' ); ?></dt>
									<dd><code><?php echo esc_html( $site_id ); ?></code></dd>
								</div>
								<div class="wpkanri-meta__row">
									<dt><?php echo esc_html__( 'API キー', 'wpkanri' ); ?></dt>
									<dd><code><?php echo esc_html( $masked ); ?></code></dd>
								</div>
							</dl>
							<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-card__actions">
								<?php wp_nonce_field( self::ACTION_CONNECT ); ?>
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_CONNECT ); ?>" />
								<button type="submit" class="button">
									<?php echo esc_html__( '再接続する', 'wpkanri' ); ?>
								</button>
								<span class="wpkanri-help">
									<?php echo esc_html__( 'API キーを再発行して接続し直します。', 'wpkanri' ); ?>
								</span>
							</form>
						<?php else : ?>
							<p class="wpkanri-lead">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %s: brand name of the cloud service */
										__( 'まだ %s に接続されていません。ワンクリックで安全な接続を始めましょう。', 'wpkanri' ),
										$brand
									)
								);
								?>
							</p>
							<p class="wpkanri-help">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %s: host of the configured service */
										__( '「接続する」を押すと %s のログインページに移動します。承認するだけで API キーが自動的に発行され、このサイトに保存されます。', 'wpkanri' ),
										$host
									)
								);
								?>
							</p>
							<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-card__actions">
								<?php wp_nonce_field( self::ACTION_CONNECT ); ?>
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_CONNECT ); ?>" />
								<button type="submit" class="button button-primary button-hero">
									<?php echo esc_html__( '接続する', 'wpkanri' ); ?>
								</button>
							</form>
						<?php endif; ?>
					</div>
				</section>

				<!-- ── Core scan card ───────────────────────────────────── -->
				<section class="wpkanri-card" aria-labelledby="wpkanri-scan-title">
					<header class="wpkanri-card__header">
						<h2 id="wpkanri-scan-title" class="wpkanri-card__title">
							<?php echo esc_html__( 'コアファイル整合性チェック', 'wpkanri' ); ?>
						</h2>
						<?php
						if ( $last_scan ) :
							$mismatch = (int) ( $last_scan['mismatch'] ?? 0 );
							if ( $mismatch > 0 ) :
								?>
								<span class="wpkanri-badge wpkanri-badge--error">
									<span aria-hidden="true">●</span>
									<?php
									echo esc_html(
										sprintf(
											/* translators: %d: number of mismatched files */
											_n( '%d 件の不一致', '%d 件の不一致', $mismatch, 'wpkanri' ),
											$mismatch
										)
									);
									?>
								</span>
							<?php else : ?>
								<span class="wpkanri-badge wpkanri-badge--ok">
									<span aria-hidden="true">●</span>
									<?php echo esc_html__( '異常なし', 'wpkanri' ); ?>
								</span>
								<?php
							endif;
						endif;
						?>
					</header>
					<div class="wpkanri-card__body">
						<p class="wpkanri-lead">
							<?php echo esc_html__( 'WordPress 本体のコアファイル(サイトの動作を支える根幹部分)が、外部からの不正侵入やハッキングによって書き換えられていないかを、定期的に自動で点検する機能です。', 'wpkanri' ); ?>
						</p>
						<p class="wpkanri-help">
							<?php echo esc_html__( '悪意のある第三者がサイトに侵入した場合、コアファイルに隠しコードを埋め込み、スパムメール送信・外部サイトへの勝手なリダイレクト・他サイトへの攻撃踏み台として悪用するケースがあります。この機能は WordPress 公式の正規ファイルと照らし合わせることで、そうした改変を早期に発見します。', 'wpkanri' ); ?>
						</p>

						<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( 'いつ実行されますか？', 'wpkanri' ); ?></h3>
						<p class="wpkanri-help">
							<?php echo esc_html__( '初期設定では毎日 1 回、サイトに訪問者が来たタイミングを契機に裏側で起動します。実行時刻を固定したい場合は下の設定で「毎日 3:00」等をお選びください。(未選択時は有効化した時刻を基準に動作します)', 'wpkanri' ); ?>
						</p>

						<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-schedule">
							<?php wp_nonce_field( self::ACTION_SCHEDULE ); ?>
							<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_SCHEDULE ); ?>" />
							<label for="wpkanri_scan_schedule" class="wpkanri-schedule__label">
								<?php echo esc_html__( '自動実行のタイミング:', 'wpkanri' ); ?>
							</label>
							<select id="wpkanri_scan_schedule" name="schedule" class="wpkanri-schedule__select">
								<?php
								$current_schedule = $connector->get_scan_schedule();
								foreach ( Connector::scan_schedule_choices() as $value => $label ) :
									?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_schedule, $value ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>
							<button type="submit" class="button"><?php echo esc_html__( '保存', 'wpkanri' ); ?></button>
							<?php
							$next_auto = wp_next_scheduled( WPKANRI_CRON_HOOK );
							if ( $next_auto ) :
								?>
								<span class="wpkanri-help" style="margin-left:8px;">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %s: next run date-time */
											__( '次回: %s', 'wpkanri' ),
											$this->format_datetime( (int) $next_auto )
										)
									);
									?>
								</span>
							<?php endif; ?>
						</form>

						<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( 'サイトにかかる負荷はどの程度ですか？', 'wpkanri' ); ?></h3>
						<p class="wpkanri-help">
							<?php echo esc_html__( 'チェックを起動したタイミングで訪問者が待たされることはありません (WordPress が裏側で処理するため)。ただし処理中は PHP プロセスを 1 つ使用するため、共有ホスティングで同時アクセスが多い時間帯と重なった場合、ごく僅かに他の訪問者の応答が遅れる可能性があります。一般的な運用ではほぼ体感できないレベル (CPU スパイクは数秒・メモリ増分は約 10 MB) です。', 'wpkanri' ); ?>
						</p>
						<p class="wpkanri-help">
							<?php echo esc_html__( '負荷が気になる場合は、アクセスの少ない深夜時刻 (例: 3:00) を上の設定でお選びください。', 'wpkanri' ); ?>
						</p>

						<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( '所要時間はどのくらいですか？', 'wpkanri' ); ?></h3>
						<p class="wpkanri-help">
							<?php echo esc_html__( '通常 30 秒〜 1 分程度です。サイト規模が大きいと最長 2 分ほどかかる場合があります。', 'wpkanri' ); ?>
						</p>

						<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( '異常が見つかったらどうなりますか？', 'wpkanri' ); ?></h3>
						<p class="wpkanri-help">
							<?php echo esc_html__( '該当ファイルのパスが下に一覧表示されます。管理画面のお知らせ通知にも表示されます。対応方法として WordPress の再インストール・プラグインの停止/削除・テーマの差し替え等が有効です。', 'wpkanri' ); ?>
						</p>

						<?php if ( $last_scan ) : ?>
							<div class="wpkanri-stats">
								<div class="wpkanri-stat">
									<span class="wpkanri-stat__label"><?php echo esc_html__( '検査ファイル数', 'wpkanri' ); ?></span>
									<span class="wpkanri-stat__value"><?php echo esc_html( number_format_i18n( (int) $last_scan['total'] ) ); ?></span>
								</div>
								<div class="wpkanri-stat wpkanri-stat--ok">
									<span class="wpkanri-stat__label"><?php echo esc_html__( '正常', 'wpkanri' ); ?></span>
									<span class="wpkanri-stat__value"><?php echo esc_html( number_format_i18n( (int) $last_scan['match'] ) ); ?></span>
								</div>
								<div class="wpkanri-stat <?php echo ( (int) $last_scan['mismatch'] > 0 ) ? 'wpkanri-stat--error' : ''; ?>">
									<span class="wpkanri-stat__label"><?php echo esc_html__( '不一致', 'wpkanri' ); ?></span>
									<span class="wpkanri-stat__value"><?php echo esc_html( number_format_i18n( (int) $last_scan['mismatch'] ) ); ?></span>
								</div>
								<div class="wpkanri-stat">
									<span class="wpkanri-stat__label"><?php echo esc_html__( '不明', 'wpkanri' ); ?></span>
									<span class="wpkanri-stat__value"><?php echo esc_html( number_format_i18n( (int) $last_scan['unknown'] ) ); ?></span>
								</div>
							</div>
							<p class="wpkanri-help">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %s: formatted date-time */
										__( '最終実行: %s', 'wpkanri' ),
										$this->format_datetime( (int) $last_scan['finished_at'] )
									)
								);
								?>
								<?php if ( ! empty( $last_scan['truncated'] ) ) : ?>
									<em>(<?php echo esc_html__( '一部打ち切り', 'wpkanri' ); ?>)</em>
								<?php endif; ?>
							</p>

							<?php if ( ! empty( $last_scan['mismatches'] ) ) : ?>
								<div class="notice notice-warning inline wpkanri-mismatches">
									<p><strong><?php echo esc_html__( '公式値と一致しないファイル:', 'wpkanri' ); ?></strong></p>
									<ul>
										<?php foreach ( $last_scan['mismatches'] as $row ) : ?>
											<li><code><?php echo esc_html( (string) ( $row['path'] ?? '' ) ); ?></code></li>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>
						<?php else : ?>
							<p class="wpkanri-lead"><?php echo esc_html__( 'まだチェックは実行されていません。', 'wpkanri' ); ?></p>
						<?php endif; ?>

						<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-card__actions">
							<?php wp_nonce_field( self::ACTION_SCAN ); ?>
							<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_SCAN ); ?>" />
							<button type="submit" class="button button-primary" <?php disabled( ! $connected ); ?>>
								<?php echo esc_html( $last_scan ? __( '再チェック', 'wpkanri' ) : __( '今すぐチェック', 'wpkanri' ) ); ?>
							</button>
							<?php if ( ! $connected ) : ?>
								<span class="wpkanri-help">
									<?php echo esc_html__( 'チェックを実行するには先に接続を完了してください。', 'wpkanri' ); ?>
								</span>
							<?php endif; ?>
						</form>
					</div>
				</section>

				<!-- ── Diagnostics card ─────────────────────────────────── -->
				<section class="wpkanri-card" aria-labelledby="wpkanri-diag-title">
					<header class="wpkanri-card__header">
						<h2 id="wpkanri-diag-title" class="wpkanri-card__title">
							<?php echo esc_html__( '接続診断', 'wpkanri' ); ?>
						</h2>
					</header>
					<div class="wpkanri-card__body">
						<p class="wpkanri-help">
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s: cloud host name */
									__( 'このサイトから %s のクラウドに到達できるかをテストします。接続が不安定なときに利用してください。', 'wpkanri' ),
									$host
								)
							);
							?>
						</p>
						<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-card__actions">
							<?php wp_nonce_field( self::ACTION_TEST ); ?>
							<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_TEST ); ?>" />
							<button type="submit" class="button" <?php disabled( ! $connected ); ?>>
								<?php echo esc_html__( '接続テストを実行', 'wpkanri' ); ?>
							</button>
							<?php if ( ! $connected ) : ?>
								<span class="wpkanri-help">
									<?php echo esc_html__( '先に「接続状態」で接続してください。', 'wpkanri' ); ?>
								</span>
							<?php endif; ?>
						</form>
					</div>
				</section>

				<!-- ── Advanced (manual API key) card — collapsed ───────── -->
				<section class="wpkanri-card wpkanri-card--advanced" aria-labelledby="wpkanri-adv-title">
					<details>
						<summary class="wpkanri-card__header">
							<h2 id="wpkanri-adv-title" class="wpkanri-card__title">
								<?php echo esc_html__( '高度な設定', 'wpkanri' ); ?>
							</h2>
							<span class="wpkanri-help">
								<?php echo esc_html__( '手動 API キー入力・クラウド URL 変更', 'wpkanri' ); ?>
							</span>
						</summary>
						<div class="wpkanri-card__body">
							<p class="wpkanri-help">
								<?php echo esc_html__( '通常は「接続する」ボタンで自動設定されます。ここでの手動設定は、接続がうまくいかない場合の代替手段です。', 'wpkanri' ); ?>
							</p>
							<form method="post" action="options.php">
								<?php settings_fields( self::OPTION_GROUP ); ?>
								<table class="form-table" role="presentation">
									<tr>
										<th scope="row">
											<label for="wpkanri_api_base"><?php echo esc_html__( 'クラウド URL', 'wpkanri' ); ?></label>
										</th>
										<td>
											<input
												type="url"
												id="wpkanri_api_base"
												name="<?php echo esc_attr( $connector->opt_key( 'api_base' ) ); ?>"
												value="<?php echo esc_attr( $api_base ); ?>"
												class="regular-text"
												placeholder="https://assist.kanripress.com"
											/>
											<p class="description"><?php echo esc_html__( '通常は既定値のままで変更不要です。', 'wpkanri' ); ?></p>
										</td>
									</tr>
									<tr>
										<th scope="row">
											<label for="wpkanri_api_key"><?php echo esc_html__( 'API キー', 'wpkanri' ); ?></label>
										</th>
										<td>
											<input
												type="text"
												id="wpkanri_api_key"
												name="<?php echo esc_attr( $connector->opt_key( 'api_key' ) ); ?>"
												value="<?php echo esc_attr( $masked ); ?>"
												class="regular-text"
												placeholder="kpa_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
												autocomplete="off"
												spellcheck="false"
											/>
											<p class="description">
												<?php
												echo esc_html(
													sprintf(
														/* translators: %s: cloud host */
														__( '%s の「設定 → API キー」で発行したキーを貼り付けてください。既存のキーは伏せ字で表示されます。', 'wpkanri' ),
														$host
													)
												);
												?>
											</p>
										</td>
									</tr>
								</table>
								<?php submit_button( __( '設定を保存', 'wpkanri' ) ); ?>
							</form>

							<hr class="wpkanri-divider" />

							<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( 'サイトを手動で再登録', 'wpkanri' ); ?></h3>
							<p class="wpkanri-help">
								<?php echo esc_html__( 'API キーは正しく設定されているがサイト ID が取得できていない場合に使用します。', 'wpkanri' ); ?>
							</p>
							<form method="post" action="<?php echo esc_url( $action_url ); ?>">
								<?php wp_nonce_field( self::ACTION_REGISTER ); ?>
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_REGISTER ); ?>" />
								<p>
									<button type="submit" class="button">
										<?php echo esc_html( $site_id ? __( 'サイトを再登録', 'wpkanri' ) : __( 'サイトを登録', 'wpkanri' ) ); ?>
									</button>
								</p>
							</form>
						</div>
					</details>
				</section>

			</div><!-- /.wpkanri-cards -->
		</div>
		<?php
	}

	/**
	 * Emit scoped CSS for the admin page. Kept inline (no asset enqueue) so
	 * the settings screen works even if something breaks the wp-admin asset
	 * pipeline — and so it does not leak onto other admin pages.
	 */
	private function render_admin_styles(): void {
		?>
		<style>
		.wpkanri-admin { max-width: 960px; }
		.wpkanri-admin__title { font-size: 28px; margin-top: 12px; }
		.wpkanri-admin__subtitle { color: #50575e; font-size: 14px; margin: 4px 0 20px; }

		.wpkanri-cards {
			display: grid;
			grid-template-columns: 1fr;
			gap: 16px;
			margin-top: 20px;
		}
		@media (min-width: 1100px) {
			.wpkanri-cards { grid-template-columns: 2fr 1fr; }
			.wpkanri-card--status { grid-column: 1 / -1; }
			.wpkanri-card--advanced { grid-column: 1 / -1; }
		}

		.wpkanri-card {
			background: #fff;
			border: 1px solid #dcdcde;
			border-radius: 8px;
			box-shadow: 0 1px 2px rgba(0,0,0,0.04);
			overflow: hidden;
		}
		.wpkanri-card__header {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 12px;
			padding: 16px 20px;
			border-bottom: 1px solid #f0f0f1;
			background: #f9fafb;
			list-style: none;
		}
		.wpkanri-card__header::-webkit-details-marker { display: none; }
		details > .wpkanri-card__header { cursor: pointer; }
		details > .wpkanri-card__header::after {
			content: "▸";
			color: #646970;
			font-size: 12px;
			margin-left: auto;
		}
		details[open] > .wpkanri-card__header::after { content: "▾"; }
		.wpkanri-card__title {
			margin: 0;
			font-size: 15px;
			font-weight: 600;
			color: #1d2327;
		}
		.wpkanri-card__subtitle {
			margin: 0 0 8px;
			font-size: 14px;
			font-weight: 600;
			color: #1d2327;
		}
		.wpkanri-card__body { padding: 20px; }
		.wpkanri-card__actions {
			margin-top: 16px;
			display: flex;
			align-items: center;
			gap: 12px;
			flex-wrap: wrap;
		}

		.wpkanri-lead { font-size: 14px; color: #1d2327; margin: 0 0 10px; }
		.wpkanri-help { font-size: 13px; color: #646970; margin: 0 0 6px; line-height: 1.6; }

		.wpkanri-badge {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			padding: 3px 10px;
			border-radius: 999px;
			font-size: 12px;
			font-weight: 600;
			line-height: 1.6;
		}
		.wpkanri-badge span { font-size: 8px; line-height: 1; }
		.wpkanri-badge--ok    { background: #e7f7ed; color: #15803d; }
		.wpkanri-badge--warn  { background: #fff4e5; color: #b45309; }
		.wpkanri-badge--error { background: #fde8e8; color: #b42318; }

		.wpkanri-meta { margin: 0 0 12px; }
		.wpkanri-meta__row {
			display: grid;
			grid-template-columns: 120px 1fr;
			gap: 12px;
			padding: 6px 0;
			border-bottom: 1px dashed #f0f0f1;
			font-size: 13px;
		}
		.wpkanri-meta__row:last-child { border-bottom: 0; }
		.wpkanri-meta__row dt { color: #646970; margin: 0; }
		.wpkanri-meta__row dd { margin: 0; color: #1d2327; word-break: break-all; }

		.wpkanri-stats {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
			gap: 10px;
			margin: 12px 0 14px;
		}
		.wpkanri-stat {
			padding: 12px 14px;
			border: 1px solid #dcdcde;
			border-radius: 6px;
			background: #fff;
			display: flex;
			flex-direction: column;
			gap: 4px;
		}
		.wpkanri-stat__label { font-size: 12px; color: #646970; }
		.wpkanri-stat__value { font-size: 20px; font-weight: 600; color: #1d2327; font-variant-numeric: tabular-nums; }
		.wpkanri-stat--ok    { background: #f7fbf8; border-color: #c5e5d1; }
		.wpkanri-stat--ok    .wpkanri-stat__value { color: #15803d; }
		.wpkanri-stat--error { background: #fdf6f6; border-color: #f0c2be; }
		.wpkanri-stat--error .wpkanri-stat__value { color: #b42318; }

		.wpkanri-divider {
			border: 0;
			border-top: 1px solid #f0f0f1;
			margin: 24px 0;
		}
		.wpkanri-mismatches { margin: 12px 0; }

		.wpkanri-schedule {
			margin: 10px 0 18px;
			padding: 14px 16px;
			background: #f6f7f7;
			border: 1px solid #dcdcde;
			border-radius: 6px;
			display: flex;
			align-items: center;
			gap: 10px;
			flex-wrap: wrap;
		}
		.wpkanri-schedule__label {
			font-size: 13px;
			font-weight: 600;
			color: #1d2327;
		}
		.wpkanri-schedule__select {
			font-size: 13px;
			padding: 4px 6px;
		}

		.wpkanri-card__subtitle {
			margin-top: 18px;
		}
		</style>
		<?php
	}

	/**
	 * Inline setup wizard shown at the top of the settings page. Displays the
	 * three-step progress (接続 → 初回スキャン → 完了) and highlights the next
	 * action the user should take. Auto-hides the completion banner after the
	 * first time it is shown post-welcome.
	 *
	 * @param array<string,mixed>|null $last_scan
	 */
	private function render_setup_wizard( Connector $connector, string $site_id, ?array $last_scan ): void {
		$connected = '' !== $connector->get_api_key() && '' !== $site_id;
		$scanned   = null !== $last_scan && ! empty( $last_scan['finished_at'] );
		$welcome   = isset( $_GET['welcome'] );

		// Step states: current | done | todo
		$step1 = $connected ? 'done' : 'current';
		$step2 = $connected ? ( $scanned ? 'done' : 'current' ) : 'todo';
		$step3 = $connected && $scanned ? 'done' : 'todo';

		$all_done = $connected && $scanned;
		// Once everything is done, only show the wizard if the user just
		// arrived via the activation redirect (welcome=1).
		if ( $all_done && ! $welcome ) {
			return;
		}
		?>
		<div style="background:#f6f7f7; border:1px solid #dcdcde; border-left:4px solid #2271b1; padding:16px 20px; margin:20px 0; border-radius:4px;">
			<h2 style="margin-top:0;">
				<?php
				echo esc_html(
					$all_done
						? __( 'セットアップ完了', 'wpkanri' )
						: __( '初期セットアップ', 'wpkanri' )
				);
				?>
			</h2>

			<?php if ( $all_done ) : ?>
				<p><?php echo esc_html__( '全ての初期設定が完了しました。クラウドのコンパネからこのサイトを管理できます。', 'wpkanri' ); ?></p>
			<?php else : ?>
				<p><?php echo esc_html__( '以下の 3 ステップで初期設定を完了してください:', 'wpkanri' ); ?></p>
			<?php endif; ?>

			<ol style="list-style:none; padding:0; margin:12px 0 0; display:flex; gap:16px; flex-wrap:wrap;">
				<?php
				$this->render_wizard_step( 1, __( 'クラウドに接続', 'wpkanri' ), $step1 );
				$this->render_wizard_step( 2, __( '初回チェックを実行', 'wpkanri' ), $step2 );
				$this->render_wizard_step( 3, __( '完了', 'wpkanri' ), $step3 );
				?>
			</ol>

			<?php if ( ! $connected ) : ?>
				<p style="margin-top:16px; margin-bottom:0;">
					<strong>
						<?php echo esc_html__( '次のアクション:', 'wpkanri' ); ?>
					</strong>
					<?php echo esc_html__( '下の「接続する」ボタンを押してください。', 'wpkanri' ); ?>
				</p>
			<?php elseif ( ! $scanned ) : ?>
				<p style="margin-top:16px; margin-bottom:0;">
					<strong>
						<?php echo esc_html__( '次のアクション:', 'wpkanri' ); ?>
					</strong>
					<?php echo esc_html__( '下の「今すぐチェック」で初回のコアファイル整合性チェックを実行してください。', 'wpkanri' ); ?>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	private function render_wizard_step( int $number, string $label, string $state ): void {
		$colors = array(
			'done'    => array( 'bg' => '#15803d', 'fg' => '#ffffff', 'icon' => '✓', 'text' => 'color:#15803d;' ),
			'current' => array( 'bg' => '#2271b1', 'fg' => '#ffffff', 'icon' => (string) $number, 'text' => 'color:#2271b1; font-weight:600;' ),
			'todo'    => array( 'bg' => '#dcdcde', 'fg' => '#50575e', 'icon' => (string) $number, 'text' => 'color:#50575e;' ),
		);
		$c = $colors[ $state ] ?? $colors['todo'];
		?>
		<li style="display:flex; align-items:center; gap:8px;">
			<span style="display:inline-flex; align-items:center; justify-content:center; width:24px; height:24px; border-radius:50%; background:<?php echo esc_attr( $c['bg'] ); ?>; color:<?php echo esc_attr( $c['fg'] ); ?>; font-size:13px; font-weight:600;">
				<?php echo esc_html( $c['icon'] ); ?>
			</span>
			<span style="<?php echo esc_attr( $c['text'] ); ?>">
				<?php echo esc_html( $label ); ?>
			</span>
		</li>
		<?php
	}

	// ── Action handlers ──────────────────────────────────────

	public function handle_test(): void {
		$this->ensure_can( self::ACTION_TEST );
		$res = ( new Api_Client() )->ping();
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( '接続に失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$this->push_notice( 'success', __( '接続成功。クラウドから応答がありました。', 'wpkanri' ) );
		}
		$this->redirect_back();
	}

	public function handle_register(): void {
		$this->ensure_can( self::ACTION_REGISTER );
		$name = (string) get_bloginfo( 'name' );
		$url  = (string) home_url();
		$res  = ( new Api_Client() )->register_site( $name, $url );
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( 'サイト登録に失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$site_id = isset( $res['id'] ) ? (string) $res['id'] : '';
			if ( $site_id ) {
				Connector::instance()->set_site_id( $site_id );
				$this->push_notice(
					'success',
					sprintf(
						/* translators: %s: site id */
						__( 'サイトを登録しました: %s', 'wpkanri' ),
						$site_id
					)
				);
			} else {
				$this->push_notice( 'warning', __( 'サイト登録レスポンスに id が含まれていません。', 'wpkanri' ) );
			}
		}
		$this->redirect_back();
	}

	public function handle_scan(): void {
		$this->ensure_can( self::ACTION_SCAN );
		$res = Scanner::instance()->run();
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( 'チェックに失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$mismatch = (int) ( $res['mismatch'] ?? 0 );
			if ( $mismatch > 0 ) {
				$this->push_notice(
					'warning',
					sprintf(
						/* translators: %d: number of mismatches */
						__( 'チェック完了 ― %d 件の不一致が検出されました。', 'wpkanri' ),
						$mismatch
					)
				);
			} else {
				$this->push_notice( 'success', __( 'チェック完了 ― コアファイルに異常はありません。', 'wpkanri' ) );
			}
		}
		$this->redirect_back();
	}

	// ── Integrity check schedule ─────────────────────────────

	public function handle_save_schedule(): void {
		$this->ensure_can( self::ACTION_SCHEDULE );
		$schedule = isset( $_POST['schedule'] ) ? sanitize_text_field( wp_unslash( $_POST['schedule'] ) ) : 'auto';
		Connector::instance()->set_scan_schedule( $schedule );
		$this->push_notice( 'success', __( '実行タイミングを更新しました。', 'wpkanri' ) );
		$this->redirect_back();
	}

	// ── OAuth-style connect flow ─────────────────────────────

	/**
	 * Kicks off the connect flow. Generates a state nonce, stores it in a
	 * transient, and redirects the admin's browser to the conpanel /connect
	 * route with all parameters the approval screen needs.
	 */
	public function handle_connect_start(): void {
		$this->ensure_can( self::ACTION_CONNECT );

		$connector = Connector::instance();
		$state     = wp_generate_password( 40, false, false );

		set_transient( self::STATE_TRANSIENT, $state, self::STATE_TTL );

		$callback = add_query_arg(
			array( 'action' => self::ACTION_CALLBACK ),
			admin_url( 'admin-post.php' )
		);

		$connect_url = add_query_arg(
			array(
				'state'     => $state,
				'callback'  => $callback,
				'site_url'  => home_url(),
				'site_name' => get_bloginfo( 'name' ),
			),
			untrailingslashit( $connector->get_api_base() ) . '/connect'
		);

		wp_redirect( $connect_url );
		exit;
	}

	/**
	 * Handles the redirect back from the conpanel. Verifies the state matches
	 * our transient, stores the returned api_key + site_id, and redirects the
	 * admin back to the settings page with a notice.
	 */
	public function handle_connect_callback(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'wpkanri' ), '', array( 'response' => 403 ) );
		}

		$received_state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		$stored_state   = (string) get_transient( self::STATE_TRANSIENT );
		delete_transient( self::STATE_TRANSIENT );

		if ( '' === $received_state || '' === $stored_state || ! hash_equals( $stored_state, $received_state ) ) {
			$this->push_notice( 'error', __( '接続リクエストの検証に失敗しました。もう一度「接続する」から開始してください。', 'wpkanri' ) );
			$this->redirect_back();
			return;
		}

		// Check for cancellation from the conpanel.
		if ( isset( $_GET['error'] ) && '' !== $_GET['error'] ) {
			$this->push_notice( 'warning', __( '接続がキャンセルされました。', 'wpkanri' ) );
			$this->redirect_back();
			return;
		}

		$api_key = isset( $_GET['api_key'] ) ? sanitize_text_field( wp_unslash( $_GET['api_key'] ) ) : '';
		$site_id = isset( $_GET['site_id'] ) ? sanitize_text_field( wp_unslash( $_GET['site_id'] ) ) : '';

		// Accept any of the known KanriPress API key prefixes:
		//   kpa_live_ — REST API key (Assist, current)
		//   kpa_mcp_  — MCP token (Assist, current)
		//   kph_live_ — REST API key (Helper, legacy)
		//   kph_mcp_  — MCP token (Helper, legacy)
		// The legacy kph_* prefixes are retained so existing installs do not
		// break when the plugin is upgraded ahead of Worker-side migration.
		$valid_prefix = (
			0 === strpos( $api_key, 'kpa_live_' ) ||
			0 === strpos( $api_key, 'kpa_mcp_' )  ||
			0 === strpos( $api_key, 'kph_live_' ) ||
			0 === strpos( $api_key, 'kph_mcp_' )
		);

		if ( '' === $api_key || '' === $site_id || ! $valid_prefix ) {
			// Persist diagnostic so we can see WHAT came back (no full key —
			// only length + leading 10 chars to avoid leaking the token into
			// the admin notice while still being debuggable).
			$diag = sprintf(
				'site_id=[%s] api_key_len=%d api_key_head=[%s]',
				$site_id,
				strlen( $api_key ),
				substr( $api_key, 0, 10 )
			);
			update_option( 'wpkanri_last_callback_diag', $diag );
			$this->push_notice(
				'error',
				sprintf(
					/* translators: %s: diagnostic string */
					__( '接続情報が正しく返されませんでした。(%s)', 'wpkanri' ),
					$diag
				)
			);
			$this->redirect_back();
			return;
		}

		$connector = Connector::instance();
		$connector->set_api_key( $api_key );
		$connector->set_site_id( $site_id );

		$this->push_notice( 'success', __( '接続が完了しました。', 'wpkanri' ) );
		$this->redirect_back();
	}

	// ── Notice plumbing ──────────────────────────────────────

	public function render_notices(): void {
		$notice = get_transient( self::NOTICE_TRANSIENT );
		if ( ! is_array( $notice ) || empty( $notice['message'] ) ) {
			return;
		}
		delete_transient( self::NOTICE_TRANSIENT );
		$type  = (string) ( $notice['type'] ?? 'info' );
		$class = 'notice notice-' . sanitize_html_class( $type, 'info' );
		printf(
			'<div class="%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $class ),
			esc_html( (string) $notice['message'] )
		);
	}

	private function push_notice( string $type, string $message ): void {
		set_transient(
			self::NOTICE_TRANSIENT,
			array(
				'type'    => $type,
				'message' => $message,
			),
			60
		);
	}

	private function ensure_can( string $action ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'wpkanri' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action );
	}

	private function redirect_back(): void {
		wp_safe_redirect(
			admin_url( 'options-general.php?page=' . self::MENU_SLUG )
		);
		exit;
	}

	private function format_datetime( int $timestamp ): string {
		if ( 0 === $timestamp ) {
			return '-';
		}
		return wp_date( 'Y-m-d H:i', $timestamp );
	}
}
