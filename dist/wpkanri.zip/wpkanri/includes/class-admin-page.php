<?php
/**
 * Admin settings page for WPKanri.
 *
 * Uses WP's Settings API for the persisted fields (API base / API key) and
 * admin-post.php endpoints for the action buttons (test connection, register
 * site, run scan). Everything sits under Settings → WPKanri.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Admin_Page {

	private const MENU_SLUG         = 'wpkanri';
	private const OPTION_GROUP      = 'wpkanri_settings';
	private const ACTION_TEST       = 'wpkanri_test';
	private const ACTION_REGISTER   = 'wpkanri_register';
	private const ACTION_SCAN       = 'wpkanri_scan';
	private const ACTION_CONNECT    = 'wpkanri_connect';
	private const ACTION_CALLBACK   = 'wpkanri_connect_callback';
	private const ACTION_SCHEDULE   = 'wpkanri_save_schedule';
	private const NOTICE_TRANSIENT  = 'wpkanri_notice';
	private const STATE_TRANSIENT   = 'wpkanri_connect_state';
	private const STATE_TTL         = 15 * MINUTE_IN_SECONDS;

	private static ?Admin_Page $instance = null;

	public static function instance(): Admin_Page {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_init', array( $this, 'maybe_activation_redirect' ) );
		add_action( 'admin_notices', array( $this, 'render_notices' ) );
		add_action( 'admin_notices', array( $this, 'render_setup_notice' ) );

		add_action( 'admin_post_' . self::ACTION_TEST, array( $this, 'handle_test' ) );
		add_action( 'admin_post_' . self::ACTION_REGISTER, array( $this, 'handle_register' ) );
		add_action( 'admin_post_' . self::ACTION_SCAN, array( $this, 'handle_scan' ) );
		add_action( 'admin_post_' . self::ACTION_CONNECT, array( $this, 'handle_connect_start' ) );
		add_action( 'admin_post_' . self::ACTION_CALLBACK, array( $this, 'handle_connect_callback' ) );
		add_action( 'admin_post_' . self::ACTION_SCHEDULE, array( $this, 'handle_save_schedule' ) );
	}

	// ── Activation redirect / setup notice ───────────────────

	/**
	 * One-shot redirect to the settings page right after plugin activation.
	 * Guarded by a 30 sec transient so it never fires twice. Skipped in
	 * white-label mode to avoid revealing the KanriPress URL to end clients.
	 */
	public function maybe_activation_redirect(): void {
		if ( ! get_transient( 'wpkanri_activation_redirect' ) ) {
			return;
		}
		delete_transient( 'wpkanri_activation_redirect' );

		// Never redirect on bulk-activate, multisite network activate, or AJAX.
		if ( isset( $_GET['activate-multi'] ) || wp_doing_ajax() || is_network_admin() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( Connector::instance()->is_whitelabel_mode() ) {
			return;
		}

		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::MENU_SLUG . '&welcome=1' ) );
		exit;
	}

	/**
	 * Global admin notice shown on every admin page (except our own settings
	 * page) when setup is not yet complete. Acts as the "setup wizard" entry
	 * point — one-line prompt with a CTA button to the settings page.
	 *
	 * Entirely suppressed in white-label mode so agency clients do not see
	 * any reference to KanriPress on their site.
	 */
	public function render_setup_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$connector = Connector::instance();
		if ( $connector->is_setup_complete() ) {
			return;
		}
		if ( $connector->is_whitelabel_mode() ) {
			return;
		}

		// Avoid double messaging on our own page (the page already shows the
		// inline wizard).
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false !== strpos( (string) $screen->id, self::MENU_SLUG ) ) {
			return;
		}

		$url = admin_url( 'options-general.php?page=' . self::MENU_SLUG );
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a href="%3$s" class="button button-primary" style="margin-left:8px;">%4$s</a></p></div>',
			esc_html( $connector->get_brand_name() . ':' ),
			esc_html__( '初期セットアップが完了していません。クラウドに接続してサイトを保護してください。', 'wpkanri' ),
			esc_url( $url ),
			esc_html__( '設定を続ける', 'wpkanri' )
		);
	}

	public function register_menu(): void {
		$brand = Connector::instance()->get_brand_name();
		add_options_page(
			$brand,
			$brand,
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function register_settings(): void {
		register_setting(
			self::OPTION_GROUP,
			Connector::instance()->opt_key( 'api_base' ),
			array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
				'default'           => WPKANRI_DEFAULT_API_BASE,
			)
		);
		register_setting(
			self::OPTION_GROUP,
			Connector::instance()->opt_key( 'api_key' ),
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_api_key' ),
				'default'           => '',
			)
		);
	}

	public function sanitize_api_key( $value ): string {
		$value = is_string( $value ) ? trim( $value ) : '';
		// If the field was left as the masked placeholder, keep the existing key.
		if ( '' === $value || false !== strpos( $value, '…' ) ) {
			return Connector::instance()->get_api_key();
		}
		return sanitize_text_field( $value );
	}

	// ── Page render ──────────────────────────────────────────

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$connector = Connector::instance();
		$brand     = $connector->get_brand_name();

		$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'main';
		if ( ! in_array( $current_tab, array( 'main', 'debug' ), true ) ) {
			$current_tab = 'main';
		}
		$base_url = admin_url( 'options-general.php?page=' . self::MENU_SLUG );
		?>
		<div class="wrap wpkanri-admin">
			<?php $this->render_admin_styles(); ?>

			<h1 class="wpkanri-admin__title"><?php echo esc_html( $brand ); ?></h1>
			<p class="wpkanri-admin__subtitle"><?php echo esc_html( $connector->get_brand_description() ); ?></p>

			<h2 class="nav-tab-wrapper wpkanri-tabs">
				<a href="<?php echo esc_url( $base_url ); ?>" class="nav-tab <?php echo 'main' === $current_tab ? 'nav-tab-active' : ''; ?>">
					<?php echo esc_html__( '設定', 'wpkanri' ); ?>
				</a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'debug', $base_url ) ); ?>" class="nav-tab <?php echo 'debug' === $current_tab ? 'nav-tab-active' : ''; ?>">
					<?php echo esc_html__( 'デバッグ情報', 'wpkanri' ); ?>
				</a>
			</h2>

			<?php
			if ( 'debug' === $current_tab ) {
				$this->render_tab_debug();
			} else {
				$this->render_tab_main();
			}
			?>
		</div>
		<?php
	}

	private function render_tab_main(): void {
		$connector = Connector::instance();
		$api_base  = $connector->get_api_base();
		$masked    = $connector->masked_api_key();
		$site_id   = $connector->get_site_id();
		$last_scan = $connector->get_last_scan();
		$brand     = $connector->get_brand_name();
		$host      = wp_parse_url( $api_base, PHP_URL_HOST ) ?: 'assist.kanripress.com';

		$connected = $connector->has_api_key() && '' !== $site_id;
		$action_url = admin_url( 'admin-post.php' );
		?>
		<?php $this->render_setup_wizard( $connector, $site_id, $last_scan ); ?>

		<div class="wpkanri-cards">

				<!-- ── Connection status card ────────────────────────── -->
				<section class="wpkanri-card wpkanri-card--status" aria-labelledby="wpkanri-status-title">
					<header class="wpkanri-card__header">
						<h2 id="wpkanri-status-title" class="wpkanri-card__title">
							<?php echo esc_html__( '接続状態', 'wpkanri' ); ?>
						</h2>
						<?php if ( $connected ) : ?>
							<span class="wpkanri-badge wpkanri-badge--ok">
								<span aria-hidden="true">●</span>
								<?php echo esc_html__( '接続済み', 'wpkanri' ); ?>
							</span>
						<?php else : ?>
							<span class="wpkanri-badge wpkanri-badge--warn">
								<span aria-hidden="true">●</span>
								<?php echo esc_html__( '未接続', 'wpkanri' ); ?>
							</span>
						<?php endif; ?>
					</header>
					<div class="wpkanri-card__body">
						<?php if ( $connected ) : ?>
							<dl class="wpkanri-meta">
								<div class="wpkanri-meta__row">
									<dt><?php echo esc_html__( '接続先', 'wpkanri' ); ?></dt>
									<dd><code><?php echo esc_html( $host ); ?></code></dd>
								</div>
								<div class="wpkanri-meta__row">
									<dt><?php echo esc_html__( 'サイト ID', 'wpkanri' ); ?></dt>
									<dd><code><?php echo esc_html( $site_id ); ?></code></dd>
								</div>
								<div class="wpkanri-meta__row">
									<dt><?php echo esc_html__( 'API キー', 'wpkanri' ); ?></dt>
									<dd><code><?php echo esc_html( $masked ); ?></code></dd>
								</div>
							</dl>
							<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-card__actions">
								<?php wp_nonce_field( self::ACTION_CONNECT ); ?>
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_CONNECT ); ?>" />
								<button type="submit" class="button">
									<?php echo esc_html__( '再接続する', 'wpkanri' ); ?>
								</button>
								<span class="wpkanri-help">
									<?php echo esc_html__( 'API キーを再発行して接続し直します。', 'wpkanri' ); ?>
								</span>
							</form>
						<?php else : ?>
							<p class="wpkanri-lead">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %s: brand name of the cloud service */
										__( 'まだ %s に接続されていません。ワンクリックで安全な接続を始めましょう。', 'wpkanri' ),
										$brand
									)
								);
								?>
							</p>
							<p class="wpkanri-help">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %s: host of the configured service */
										__( '「接続する」を押すと %s のログインページに移動します。承認するだけで API キーが自動的に発行され、このサイトに保存されます。', 'wpkanri' ),
										$host
									)
								);
								?>
							</p>
							<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-card__actions">
								<?php wp_nonce_field( self::ACTION_CONNECT ); ?>
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_CONNECT ); ?>" />
								<button type="submit" class="button button-primary button-hero">
									<?php echo esc_html__( '接続する', 'wpkanri' ); ?>
								</button>
							</form>
						<?php endif; ?>
					</div>
				</section>

				<!-- ── Core scan card ───────────────────────────────────── -->
				<?php
				$scan_async = Scanner::instance()->get_async_status();
				$is_running = 'running' === $scan_async['status'];
				?>
				<section class="wpkanri-card" aria-labelledby="wpkanri-scan-title" data-wpkanri-scan-card data-running="<?php echo $is_running ? '1' : '0'; ?>">
					<header class="wpkanri-card__header">
						<h2 id="wpkanri-scan-title" class="wpkanri-card__title">
							<?php echo esc_html__( 'コアファイル整合性チェック', 'wpkanri' ); ?>
						</h2>
						<?php
						if ( $is_running ) :
							?>
							<span class="wpkanri-badge wpkanri-badge--info">
								<span class="wpkanri-spinner" aria-hidden="true"></span>
								<?php echo esc_html__( '実行中', 'wpkanri' ); ?>
							</span>
							<?php
						elseif ( $last_scan ) :
							$mismatch = (int) ( $last_scan['mismatch'] ?? 0 );
							if ( $mismatch > 0 ) :
								?>
								<span class="wpkanri-badge wpkanri-badge--error">
									<span aria-hidden="true">●</span>
									<?php
									echo esc_html(
										sprintf(
											/* translators: %d: number of mismatched files */
											_n( '%d 件の不一致', '%d 件の不一致', $mismatch, 'wpkanri' ),
											$mismatch
										)
									);
									?>
								</span>
							<?php else : ?>
								<span class="wpkanri-badge wpkanri-badge--ok">
									<span aria-hidden="true">●</span>
									<?php echo esc_html__( '異常なし', 'wpkanri' ); ?>
								</span>
								<?php
							endif;
						endif;
						?>
					</header>
					<div class="wpkanri-card__body">
						<p class="wpkanri-lead">
							<?php echo esc_html__( 'WordPress 本体のコアファイル(サイトの動作を支える根幹部分)が、外部からの不正侵入やハッキングによって書き換えられていないかを、定期的に自動で点検する機能です。', 'wpkanri' ); ?>
						</p>
						<p class="wpkanri-help">
							<?php echo esc_html__( '悪意のある第三者がサイトに侵入した場合、コアファイルに隠しコードを埋め込み、スパムメール送信・外部サイトへの勝手なリダイレクト・他サイトへの攻撃踏み台として悪用するケースがあります。この機能は WordPress 公式の正規ファイルと照らし合わせることで、そうした改変を早期に発見します。', 'wpkanri' ); ?>
						</p>

						<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( 'いつ実行されますか？', 'wpkanri' ); ?></h3>
						<p class="wpkanri-help">
							<?php echo esc_html__( '初期設定では毎日 1 回、サイトに訪問者が来たタイミングを契機に裏側で起動します。実行時刻を固定したい場合は下の設定で「毎日 3:00」等をお選びください。(未選択時は有効化した時刻を基準に動作します)', 'wpkanri' ); ?>
						</p>

						<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-schedule">
							<?php wp_nonce_field( self::ACTION_SCHEDULE ); ?>
							<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_SCHEDULE ); ?>" />
							<label for="wpkanri_scan_schedule" class="wpkanri-schedule__label">
								<?php echo esc_html__( '自動実行のタイミング:', 'wpkanri' ); ?>
							</label>
							<select id="wpkanri_scan_schedule" name="schedule" class="wpkanri-schedule__select">
								<?php
								$current_schedule = $connector->get_scan_schedule();
								foreach ( Connector::scan_schedule_choices() as $value => $label ) :
									?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_schedule, $value ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>
							<button type="submit" class="button"><?php echo esc_html__( '保存', 'wpkanri' ); ?></button>
							<?php
							$next_auto = wp_next_scheduled( WPKANRI_CRON_HOOK );
							if ( $next_auto ) :
								?>
								<span class="wpkanri-help" style="margin-left:8px;">
									<?php
									echo esc_html(
										sprintf(
											/* translators: %s: next run date-time */
											__( '次回: %s', 'wpkanri' ),
											$this->format_datetime( (int) $next_auto )
										)
									);
									?>
								</span>
							<?php endif; ?>
						</form>

						<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( 'サイトにかかる負荷はどの程度ですか？', 'wpkanri' ); ?></h3>
						<p class="wpkanri-help">
							<?php echo esc_html__( 'チェックを起動したタイミングで訪問者が待たされることはありません (WordPress が裏側で処理するため)。ただし処理中は PHP プロセスを 1 つ使用するため、共有ホスティングで同時アクセスが多い時間帯と重なった場合、ごく僅かに他の訪問者の応答が遅れる可能性があります。一般的な運用ではほぼ体感できないレベル (CPU スパイクは数秒・メモリ増分は約 10 MB) です。', 'wpkanri' ); ?>
						</p>
						<p class="wpkanri-help">
							<?php echo esc_html__( '負荷が気になる場合は、アクセスの少ない深夜時刻 (例: 3:00) を上の設定でお選びください。', 'wpkanri' ); ?>
						</p>

						<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( '所要時間はどのくらいですか？', 'wpkanri' ); ?></h3>
						<p class="wpkanri-help">
							<?php echo esc_html__( '通常 30 秒〜 1 分程度です。サイト規模が大きいと最長 2 分ほどかかる場合があります。', 'wpkanri' ); ?>
						</p>

						<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( '異常が見つかったらどうなりますか？', 'wpkanri' ); ?></h3>
						<p class="wpkanri-help">
							<?php echo esc_html__( '該当ファイルのパスが下に一覧表示されます。管理画面のお知らせ通知にも表示されます。対応方法として WordPress の再インストール・プラグインの停止/削除・テーマの差し替え等が有効です。', 'wpkanri' ); ?>
						</p>

						<?php if ( $last_scan ) : ?>
							<div class="wpkanri-stats">
								<div class="wpkanri-stat">
									<span class="wpkanri-stat__label"><?php echo esc_html__( '検査ファイル数', 'wpkanri' ); ?></span>
									<span class="wpkanri-stat__value"><?php echo esc_html( number_format_i18n( (int) $last_scan['total'] ) ); ?></span>
								</div>
								<div class="wpkanri-stat wpkanri-stat--ok">
									<span class="wpkanri-stat__label"><?php echo esc_html__( '正常', 'wpkanri' ); ?></span>
									<span class="wpkanri-stat__value"><?php echo esc_html( number_format_i18n( (int) $last_scan['match'] ) ); ?></span>
								</div>
								<div class="wpkanri-stat <?php echo ( (int) $last_scan['mismatch'] > 0 ) ? 'wpkanri-stat--error' : ''; ?>">
									<span class="wpkanri-stat__label"><?php echo esc_html__( '不一致', 'wpkanri' ); ?></span>
									<span class="wpkanri-stat__value"><?php echo esc_html( number_format_i18n( (int) $last_scan['mismatch'] ) ); ?></span>
								</div>
								<div class="wpkanri-stat">
									<span class="wpkanri-stat__label"><?php echo esc_html__( '不明', 'wpkanri' ); ?></span>
									<span class="wpkanri-stat__value"><?php echo esc_html( number_format_i18n( (int) $last_scan['unknown'] ) ); ?></span>
								</div>
							</div>
							<p class="wpkanri-help">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %s: formatted date-time */
										__( '最終実行: %s', 'wpkanri' ),
										$this->format_datetime( (int) $last_scan['finished_at'] )
									)
								);
								?>
								<?php if ( ! empty( $last_scan['truncated'] ) ) : ?>
									<em>(<?php echo esc_html__( '一部打ち切り', 'wpkanri' ); ?>)</em>
								<?php endif; ?>
							</p>

							<?php if ( ! empty( $last_scan['mismatches'] ) ) : ?>
								<div class="notice notice-warning inline wpkanri-mismatches">
									<p><strong><?php echo esc_html__( '公式値と一致しないファイル:', 'wpkanri' ); ?></strong></p>
									<ul>
										<?php foreach ( $last_scan['mismatches'] as $row ) : ?>
											<li><code><?php echo esc_html( (string) ( $row['path'] ?? '' ) ); ?></code></li>
										<?php endforeach; ?>
									</ul>
								</div>
							<?php endif; ?>
						<?php else : ?>
							<p class="wpkanri-lead"><?php echo esc_html__( 'まだチェックは実行されていません。', 'wpkanri' ); ?></p>
						<?php endif; ?>

						<?php if ( $is_running ) : ?>
							<div class="wpkanri-running" role="status">
								<span class="wpkanri-spinner wpkanri-spinner--lg" aria-hidden="true"></span>
								<div>
									<p class="wpkanri-lead" style="margin:0 0 4px;">
										<?php echo esc_html__( 'バックグラウンドでチェックを実行中です…', 'wpkanri' ); ?>
									</p>
									<p class="wpkanri-help" style="margin:0;">
										<?php echo esc_html__( '画面を閉じても処理は継続します。完了すると自動でこのページが更新されます (通常 30 秒〜 1 分)。', 'wpkanri' ); ?>
									</p>
								</div>
							</div>
						<?php endif; ?>

						<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-card__actions">
							<?php wp_nonce_field( self::ACTION_SCAN ); ?>
							<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_SCAN ); ?>" />
							<button type="submit" class="button button-primary" <?php disabled( ! $connected || $is_running ); ?>>
								<?php
								if ( $is_running ) {
									echo esc_html__( '実行中…', 'wpkanri' );
								} else {
									echo esc_html( $last_scan ? __( '再チェック', 'wpkanri' ) : __( '今すぐチェック', 'wpkanri' ) );
								}
								?>
							</button>
							<?php if ( ! $connected ) : ?>
								<span class="wpkanri-help">
									<?php echo esc_html__( 'チェックを実行するには先に接続を完了してください。', 'wpkanri' ); ?>
								</span>
							<?php endif; ?>
						</form>
					</div>
				</section>

				<!-- ── Diagnostics card ─────────────────────────────────── -->
				<section class="wpkanri-card" aria-labelledby="wpkanri-diag-title">
					<header class="wpkanri-card__header">
						<h2 id="wpkanri-diag-title" class="wpkanri-card__title">
							<?php echo esc_html__( '接続診断', 'wpkanri' ); ?>
						</h2>
					</header>
					<div class="wpkanri-card__body">
						<p class="wpkanri-help">
							<?php
							echo esc_html(
								sprintf(
									/* translators: %s: cloud host name */
									__( 'このサイトから %s のクラウドに到達できるかをテストします。接続が不安定なときに利用してください。', 'wpkanri' ),
									$host
								)
							);
							?>
						</p>
						<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="wpkanri-card__actions">
							<?php wp_nonce_field( self::ACTION_TEST ); ?>
							<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_TEST ); ?>" />
							<button type="submit" class="button" <?php disabled( ! $connected ); ?>>
								<?php echo esc_html__( '接続テストを実行', 'wpkanri' ); ?>
							</button>
							<?php if ( ! $connected ) : ?>
								<span class="wpkanri-help">
									<?php echo esc_html__( '先に「接続状態」で接続してください。', 'wpkanri' ); ?>
								</span>
							<?php endif; ?>
						</form>
					</div>
				</section>

				<!-- ── Advanced (manual API key) card — collapsed ───────── -->
				<section class="wpkanri-card wpkanri-card--advanced" aria-labelledby="wpkanri-adv-title">
					<details>
						<summary class="wpkanri-card__header">
							<h2 id="wpkanri-adv-title" class="wpkanri-card__title">
								<?php echo esc_html__( '高度な設定', 'wpkanri' ); ?>
							</h2>
							<span class="wpkanri-help">
								<?php echo esc_html__( '手動 API キー入力・クラウド URL 変更', 'wpkanri' ); ?>
							</span>
						</summary>
						<div class="wpkanri-card__body">
							<p class="wpkanri-help">
								<?php echo esc_html__( '通常は「接続する」ボタンで自動設定されます。ここでの手動設定は、接続がうまくいかない場合の代替手段です。', 'wpkanri' ); ?>
							</p>
							<form method="post" action="options.php">
								<?php settings_fields( self::OPTION_GROUP ); ?>
								<table class="form-table" role="presentation">
									<tr>
										<th scope="row">
											<label for="wpkanri_api_base"><?php echo esc_html__( 'クラウド URL', 'wpkanri' ); ?></label>
										</th>
										<td>
											<input
												type="url"
												id="wpkanri_api_base"
												name="<?php echo esc_attr( $connector->opt_key( 'api_base' ) ); ?>"
												value="<?php echo esc_attr( $api_base ); ?>"
												class="regular-text"
												placeholder="https://assist.kanripress.com"
											/>
											<p class="description"><?php echo esc_html__( '通常は既定値のままで変更不要です。', 'wpkanri' ); ?></p>
										</td>
									</tr>
									<tr>
										<th scope="row">
											<label for="wpkanri_api_key"><?php echo esc_html__( 'API キー', 'wpkanri' ); ?></label>
										</th>
										<td>
											<input
												type="text"
												id="wpkanri_api_key"
												name="<?php echo esc_attr( $connector->opt_key( 'api_key' ) ); ?>"
												value="<?php echo esc_attr( $masked ); ?>"
												class="regular-text"
												placeholder="kpa_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
												autocomplete="off"
												spellcheck="false"
											/>
											<p class="description">
												<?php
												echo esc_html(
													sprintf(
														/* translators: %s: cloud host */
														__( '%s の「設定 → API キー」で発行したキーを貼り付けてください。既存のキーは伏せ字で表示されます。', 'wpkanri' ),
														$host
													)
												);
												?>
											</p>
										</td>
									</tr>
								</table>
								<?php submit_button( __( '設定を保存', 'wpkanri' ) ); ?>
							</form>

							<hr class="wpkanri-divider" />

							<h3 class="wpkanri-card__subtitle"><?php echo esc_html__( 'サイトを手動で再登録', 'wpkanri' ); ?></h3>
							<p class="wpkanri-help">
								<?php echo esc_html__( 'API キーは正しく設定されているがサイト ID が取得できていない場合に使用します。', 'wpkanri' ); ?>
							</p>
							<form method="post" action="<?php echo esc_url( $action_url ); ?>">
								<?php wp_nonce_field( self::ACTION_REGISTER ); ?>
								<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_REGISTER ); ?>" />
								<p>
									<button type="submit" class="button">
										<?php echo esc_html( $site_id ? __( 'サイトを再登録', 'wpkanri' ) : __( 'サイトを登録', 'wpkanri' ) ); ?>
									</button>
								</p>
							</form>
						</div>
					</details>
				</section>

		</div><!-- /.wpkanri-cards -->
		<?php
	}

	// ── Debug tab ──────────────────────────────────────────────

	private function render_tab_debug(): void {
		global $wp_version;

		$connector     = Connector::instance();
		$scanner       = Scanner::instance();
		$scan_async    = $scanner->get_async_status();
		$action_url    = admin_url( 'admin-post.php' );
		$diag          = $this->collect_diagnostics();
		$diag_text     = $this->diagnostics_as_text( $diag );
		?>
		<div class="wpkanri-cards wpkanri-cards--debug">
			<!-- Copy-paste block -->
			<section class="wpkanri-card" aria-labelledby="wpkanri-dbg-copy">
				<header class="wpkanri-card__header">
					<h2 id="wpkanri-dbg-copy" class="wpkanri-card__title">
						<?php echo esc_html__( 'サポートに共有する', 'wpkanri' ); ?>
					</h2>
					<button type="button" class="button" data-wpkanri-copy-diag>
						<?php echo esc_html__( 'コピー', 'wpkanri' ); ?>
					</button>
				</header>
				<div class="wpkanri-card__body">
					<p class="wpkanri-help">
						<?php echo esc_html__( '下のブロックにすべての診断情報が含まれています。右上の「コピー」ボタンでクリップボードにコピーし、お問い合わせ時にそのまま貼り付けてください。', 'wpkanri' ); ?>
					</p>
					<textarea id="wpkanri-diag-text" class="wpkanri-diag-text" rows="12" readonly><?php echo esc_textarea( $diag_text ); ?></textarea>
				</div>
			</section>

			<!-- Summary table -->
			<section class="wpkanri-card" aria-labelledby="wpkanri-dbg-summary">
				<header class="wpkanri-card__header">
					<h2 id="wpkanri-dbg-summary" class="wpkanri-card__title">
						<?php echo esc_html__( '機能別 動作状況', 'wpkanri' ); ?>
					</h2>
				</header>
				<div class="wpkanri-card__body">
					<table class="wpkanri-diag-table">
						<thead>
							<tr>
								<th><?php echo esc_html__( '機能', 'wpkanri' ); ?></th>
								<th><?php echo esc_html__( '状態', 'wpkanri' ); ?></th>
								<th><?php echo esc_html__( '詳細', 'wpkanri' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $diag['features'] as $feat ) : ?>
								<tr>
									<td><?php echo esc_html( $feat['name'] ); ?></td>
									<td>
										<span class="wpkanri-badge wpkanri-badge--<?php echo esc_attr( $feat['state'] ); ?>">
											<span aria-hidden="true">●</span>
											<?php echo esc_html( $feat['state_label'] ); ?>
										</span>
									</td>
									<td class="wpkanri-help"><?php echo esc_html( $feat['detail'] ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>

					<div class="wpkanri-card__actions">
						<form method="post" action="<?php echo esc_url( $action_url ); ?>">
							<?php wp_nonce_field( self::ACTION_TEST ); ?>
							<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_TEST ); ?>" />
							<button type="submit" class="button">
								<?php echo esc_html__( 'クラウドに疎通テスト', 'wpkanri' ); ?>
							</button>
							<span class="wpkanri-help" style="margin-left:8px;">
								<?php echo esc_html__( 'KanriPress Assist クラウドへの到達可否をその場で確認します。', 'wpkanri' ); ?>
							</span>
						</form>
					</div>
				</div>
			</section>

			<!-- Plugin state -->
			<section class="wpkanri-card" aria-labelledby="wpkanri-dbg-plugin">
				<header class="wpkanri-card__header">
					<h2 id="wpkanri-dbg-plugin" class="wpkanri-card__title">
						<?php echo esc_html__( 'プラグイン状態', 'wpkanri' ); ?>
					</h2>
				</header>
				<div class="wpkanri-card__body">
					<?php $this->render_kv_list( $diag['plugin_state'] ); ?>
				</div>
			</section>

			<!-- WordPress -->
			<section class="wpkanri-card" aria-labelledby="wpkanri-dbg-wp">
				<header class="wpkanri-card__header">
					<h2 id="wpkanri-dbg-wp" class="wpkanri-card__title">
						<?php echo esc_html__( 'WordPress', 'wpkanri' ); ?>
					</h2>
				</header>
				<div class="wpkanri-card__body">
					<?php $this->render_kv_list( $diag['wordpress'] ); ?>
				</div>
			</section>

			<!-- Server -->
			<section class="wpkanri-card" aria-labelledby="wpkanri-dbg-server">
				<header class="wpkanri-card__header">
					<h2 id="wpkanri-dbg-server" class="wpkanri-card__title">
						<?php echo esc_html__( 'サーバー環境', 'wpkanri' ); ?>
					</h2>
				</header>
				<div class="wpkanri-card__body">
					<?php $this->render_kv_list( $diag['server'] ); ?>
				</div>
			</section>

			<!-- Active theme -->
			<section class="wpkanri-card" aria-labelledby="wpkanri-dbg-theme">
				<header class="wpkanri-card__header">
					<h2 id="wpkanri-dbg-theme" class="wpkanri-card__title">
						<?php echo esc_html__( 'アクティブテーマ', 'wpkanri' ); ?>
					</h2>
				</header>
				<div class="wpkanri-card__body">
					<?php $this->render_kv_list( $diag['active_theme'] ); ?>
				</div>
			</section>

			<!-- Plugins list -->
			<section class="wpkanri-card" aria-labelledby="wpkanri-dbg-plugins">
				<header class="wpkanri-card__header">
					<h2 id="wpkanri-dbg-plugins" class="wpkanri-card__title">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %d: number of plugins */
								__( 'インストール済みプラグイン (%d)', 'wpkanri' ),
								count( $diag['plugins'] )
							)
						);
						?>
					</h2>
				</header>
				<div class="wpkanri-card__body">
					<table class="wpkanri-diag-table">
						<thead>
							<tr>
								<th><?php echo esc_html__( '名前', 'wpkanri' ); ?></th>
								<th><?php echo esc_html__( 'バージョン', 'wpkanri' ); ?></th>
								<th><?php echo esc_html__( '状態', 'wpkanri' ); ?></th>
								<th><?php echo esc_html__( 'ファイル', 'wpkanri' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $diag['plugins'] as $p ) : ?>
								<tr>
									<td><?php echo esc_html( $p['name'] ); ?></td>
									<td><?php echo esc_html( $p['version'] ); ?></td>
									<td>
										<?php if ( $p['active'] ) : ?>
											<span class="wpkanri-badge wpkanri-badge--ok">
												<span aria-hidden="true">●</span>
												<?php echo esc_html__( '有効', 'wpkanri' ); ?>
											</span>
										<?php else : ?>
											<span class="wpkanri-help"><?php echo esc_html__( '無効', 'wpkanri' ); ?></span>
										<?php endif; ?>
									</td>
									<td><code><?php echo esc_html( $p['file'] ); ?></code></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</section>

			<!-- Themes list -->
			<section class="wpkanri-card" aria-labelledby="wpkanri-dbg-themes">
				<header class="wpkanri-card__header">
					<h2 id="wpkanri-dbg-themes" class="wpkanri-card__title">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %d: number of themes */
								__( 'インストール済みテーマ (%d)', 'wpkanri' ),
								count( $diag['themes'] )
							)
						);
						?>
					</h2>
				</header>
				<div class="wpkanri-card__body">
					<table class="wpkanri-diag-table">
						<thead>
							<tr>
								<th><?php echo esc_html__( '名前', 'wpkanri' ); ?></th>
								<th><?php echo esc_html__( 'バージョン', 'wpkanri' ); ?></th>
								<th><?php echo esc_html__( '状態', 'wpkanri' ); ?></th>
								<th><?php echo esc_html__( 'スラッグ', 'wpkanri' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $diag['themes'] as $t ) : ?>
								<tr>
									<td><?php echo esc_html( $t['name'] ); ?></td>
									<td><?php echo esc_html( $t['version'] ); ?></td>
									<td>
										<?php if ( $t['active'] ) : ?>
											<span class="wpkanri-badge wpkanri-badge--ok">
												<span aria-hidden="true">●</span>
												<?php echo esc_html__( 'アクティブ', 'wpkanri' ); ?>
											</span>
										<?php else : ?>
											<span class="wpkanri-help"><?php echo esc_html__( '非アクティブ', 'wpkanri' ); ?></span>
										<?php endif; ?>
									</td>
									<td><code><?php echo esc_html( $t['slug'] ); ?></code></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</section>
		</div>
		<script>
		(function () {
			var btn = document.querySelector('[data-wpkanri-copy-diag]');
			var ta  = document.getElementById('wpkanri-diag-text');
			if (!btn || !ta) return;
			btn.addEventListener('click', function () {
				ta.focus();
				ta.select();
				var ok = false;
				try { ok = document.execCommand('copy'); } catch (e) {}
				if (!ok && navigator.clipboard) {
					navigator.clipboard.writeText(ta.value);
					ok = true;
				}
				var original = btn.textContent;
				btn.textContent = ok ? '✓ コピーしました' : 'コピー失敗';
				setTimeout(function () { btn.textContent = original; }, 1800);
			});
		})();
		</script>
		<?php unset( $scanner, $scan_async ); // referenced by collect_diagnostics already
	}

	/**
	 * Collect the full diagnostics payload. Kept as a single method so the
	 * HTML renderer and the text formatter (copy-paste block) consume the
	 * same data.
	 */
	private function collect_diagnostics(): array {
		global $wp_version, $wpdb;

		$connector  = Connector::instance();
		$scanner    = Scanner::instance();
		$scan_async = $scanner->get_async_status();
		$next_cron  = wp_next_scheduled( WPKANRI_CRON_HOOK );
		$last_scan  = $connector->get_last_scan();

		// ── Feature-by-feature status ────────────────────────
		$is_connected = $connector->has_api_key() && $connector->is_registered();

		$features = array();

		// Connection
		$features[] = array(
			'name'        => __( 'クラウド接続', 'wpkanri' ),
			'state'       => $is_connected ? 'ok' : 'warn',
			'state_label' => $is_connected ? __( '接続済み', 'wpkanri' ) : __( '未接続', 'wpkanri' ),
			'detail'      => $is_connected
				? sprintf( 'Site ID: %s', $connector->get_site_id() )
				: __( '「設定」タブで接続してください。', 'wpkanri' ),
		);

		// Integrity check
		$scan_schedule_choices = Connector::scan_schedule_choices();
		$scan_schedule_key     = $connector->get_scan_schedule();
		$scan_schedule_label   = isset( $scan_schedule_choices[ $scan_schedule_key ] ) ? $scan_schedule_choices[ $scan_schedule_key ] : $scan_schedule_key;
		$next_fmt              = $next_cron ? $this->format_datetime( (int) $next_cron ) : '—';

		$scan_state = 'ok';
		if ( 'disabled' === $scan_schedule_key ) {
			$scan_state = 'warn';
		}
		$features[] = array(
			'name'        => __( 'コアファイル整合性チェック', 'wpkanri' ),
			'state'       => $scan_state,
			'state_label' => 'disabled' === $scan_schedule_key ? __( '無効', 'wpkanri' ) : __( 'スケジュール済み', 'wpkanri' ),
			'detail'      => sprintf( '%s / %s: %s', $scan_schedule_label, __( '次回', 'wpkanri' ), $next_fmt ),
		);

		// Status poller (assumed started when connected)
		$poll_next = wp_next_scheduled( 'wpkanri_status_poll' );
		$features[] = array(
			'name'        => __( 'ステータスポーリング (5 分間隔)', 'wpkanri' ),
			'state'       => $poll_next ? 'ok' : ( $is_connected ? 'error' : 'warn' ),
			'state_label' => $poll_next ? __( 'スケジュール済み', 'wpkanri' ) : __( '未登録', 'wpkanri' ),
			'detail'      => $poll_next ? sprintf( '%s: %s', __( '次回', 'wpkanri' ), $this->format_datetime( (int) $poll_next ) ) : __( '接続後に自動登録されます。', 'wpkanri' ),
		);

		// Update detector
		$upd_next = wp_next_scheduled( 'wpkanri_update_detect' );
		$features[] = array(
			'name'        => __( 'アップデート検知 (日次)', 'wpkanri' ),
			'state'       => $upd_next ? 'ok' : ( $is_connected ? 'error' : 'warn' ),
			'state_label' => $upd_next ? __( 'スケジュール済み', 'wpkanri' ) : __( '未登録', 'wpkanri' ),
			'detail'      => $upd_next ? sprintf( '%s: %s', __( '次回', 'wpkanri' ), $this->format_datetime( (int) $upd_next ) ) : '—',
		);

		// Snippet polling
		$snip_next = wp_next_scheduled( 'wpkanri_snippets_poll' );
		$features[] = array(
			'name'        => __( 'コードスニペット実行 (毎時)', 'wpkanri' ),
			'state'       => $snip_next ? 'ok' : ( $is_connected ? 'error' : 'warn' ),
			'state_label' => $snip_next ? __( 'スケジュール済み', 'wpkanri' ) : __( '未登録', 'wpkanri' ),
			'detail'      => $snip_next ? sprintf( '%s: %s', __( '次回', 'wpkanri' ), $this->format_datetime( (int) $snip_next ) ) : '—',
		);

		// ── Frontend measurement scripts (RUM + CO2) ──
		$webvitals_path = WPKANRI_PLUGIN_DIR . 'assets/js/web-vitals.iife.js';
		$rum_js_path    = WPKANRI_PLUGIN_DIR . 'assets/js/wpkanri-rum.js';
		$rum_assets_ok  = file_exists( $webvitals_path ) && file_exists( $rum_js_path );
		$rum_will_load  = $rum_assets_ok && $is_connected; // Rum::boot() gates on is_setup_complete()
		$features[] = array(
			'name'        => __( 'RUM (Core Web Vitals)', 'wpkanri' ),
			'state'       => $rum_will_load ? 'ok' : ( $rum_assets_ok ? 'warn' : 'error' ),
			'state_label' => $rum_will_load
				? __( 'フロントで計測中', 'wpkanri' )
				: ( $rum_assets_ok ? __( '接続待ち', 'wpkanri' ) : __( 'アセット欠落', 'wpkanri' ) ),
			'detail'      => $rum_assets_ok
				? __( 'wp_footer で web-vitals.js 同梱。LCP/INP/CLS/FCP/TTFB を訪問者側で計測しクラウド送信。', 'wpkanri' )
				: __( 'プラグインファイルが破損している可能性。再インストールしてください。', 'wpkanri' ),
		);
		$features[] = array(
			'name'        => __( 'CO2 (転送バイト計測)', 'wpkanri' ),
			'state'       => $rum_will_load ? 'ok' : ( $rum_assets_ok ? 'warn' : 'error' ),
			'state_label' => $rum_will_load
				? __( '同一スクリプトで収集中', 'wpkanri' )
				: ( $rum_assets_ok ? __( '接続待ち', 'wpkanri' ) : __( 'アセット欠落', 'wpkanri' ) ),
			'detail'      => __( 'wpkanri-rum.js 内で PerformanceNavigationTiming の transferSize を集計してクラウド送信。', 'wpkanri' ),
		);

		// PHP error monitor
		$err_monitor_active = $is_connected; // Error_Monitor::boot() gates on is_setup_complete()
		$features[] = array(
			'name'        => __( 'PHP エラー監視', 'wpkanri' ),
			'state'       => $err_monitor_active ? 'ok' : 'warn',
			'state_label' => $err_monitor_active ? __( '監視中', 'wpkanri' ) : __( '接続待ち', 'wpkanri' ),
			'detail'      => __( 'E_WARNING + Fatal Error を捕捉し非ブロッキングでクラウド送信 (1 リクエストあたり最大 5 件)。', 'wpkanri' ),
		);

		// Activity logger
		$activity_active = $is_connected;
		$features[] = array(
			'name'        => __( 'アクティビティログ', 'wpkanri' ),
			'state'       => $activity_active ? 'ok' : 'warn',
			'state_label' => $activity_active ? __( 'フック登録済み', 'wpkanri' ) : __( '接続待ち', 'wpkanri' ),
			'detail'      => __( 'プラグイン有効化/更新・ユーザー作成・設定変更等をクラウドに非同期送信。', 'wpkanri' ),
		);

		// Health endpoint
		$health_route = rest_url( WPKANRI_REST_NAMESPACE . '/health' );
		$features[] = array(
			'name'        => __( 'ヘルスエンドポイント', 'wpkanri' ),
			'state'       => 'ok',
			'state_label' => __( '登録済み', 'wpkanri' ),
			'detail'      => sprintf(
				/* translators: %s: health endpoint URL */
				__( '外部死活監視用。%s (X-WPKanri-Token 認証必須)', 'wpkanri' ),
				$health_route
			),
		);

		// Auto-updater (PUC)
		$updater_disabled = defined( 'WPKANRI_DISABLE_AUTO_UPDATE' ) && WPKANRI_DISABLE_AUTO_UPDATE;
		$features[] = array(
			'name'        => __( '自動アップデート (GitHub Releases)', 'wpkanri' ),
			'state'       => $updater_disabled ? 'warn' : 'ok',
			'state_label' => $updater_disabled ? __( '無効化設定', 'wpkanri' ) : __( '有効', 'wpkanri' ),
			'detail'      => $updater_disabled
				? __( 'wp-config.php で WPKANRI_DISABLE_AUTO_UPDATE=true が定義されています。', 'wpkanri' )
				: sprintf(
					/* translators: %s: GitHub repository */
					__( 'Plugin Update Checker が %s を 12 時間ごとに監視。', 'wpkanri' ),
					defined( 'WPKANRI_GITHUB_REPO' ) ? (string) WPKANRI_GITHUB_REPO : 'KanriPress/wpkanri'
				),
		);

		// Emergency connector
		$emerg_file = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/' . (string) get_option( 'wpkanri_emergency_filename', '' ) : '';
		$emerg_ok   = '' !== $emerg_file && file_exists( $emerg_file );
		$features[] = array(
			'name'        => __( 'Emergency Connector', 'wpkanri' ),
			'state'       => $emerg_ok ? 'ok' : 'warn',
			'state_label' => $emerg_ok ? __( '設置済み', 'wpkanri' ) : __( '未設置', 'wpkanri' ),
			'detail'      => $emerg_ok ? basename( $emerg_file ) : __( '有効化時に自動設置されます。', 'wpkanri' ),
		);

		// Maintenance state
		$maint_active = (bool) get_option( 'wpkanri_maintenance_active', false );
		$features[] = array(
			'name'        => __( 'メンテナンスモード', 'wpkanri' ),
			'state'       => $maint_active ? 'warn' : 'ok',
			'state_label' => $maint_active ? __( '有効中', 'wpkanri' ) : __( '停止中', 'wpkanri' ),
			'detail'      => $maint_active ? __( '.htaccess に 503 ルールあり / サイトは停止表示中', 'wpkanri' ) : __( '通常運用中', 'wpkanri' ),
		);

		// wp-cron status
		$wp_cron_ok = ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON );
		$features[] = array(
			'name'        => __( 'WP Cron', 'wpkanri' ),
			'state'       => $wp_cron_ok ? 'ok' : 'warn',
			'state_label' => $wp_cron_ok ? __( '有効', 'wpkanri' ) : __( '無効 (DISABLE_WP_CRON)', 'wpkanri' ),
			'detail'      => $wp_cron_ok ? __( '通常動作', 'wpkanri' ) : __( 'wp-config.php で DISABLE_WP_CRON = true になっています。サーバー cron の設定が必要です。', 'wpkanri' ),
		);

		// Required PHP extensions
		$ext_zip  = class_exists( 'ZipArchive' );
		$ext_curl = function_exists( 'curl_init' );
		$ext_mb   = function_exists( 'mb_substr' );
		$ext_mysqli = class_exists( 'mysqli' );
		$all_exts = $ext_zip && $ext_curl && $ext_mb && $ext_mysqli;
		$features[] = array(
			'name'        => __( '必須 PHP 拡張', 'wpkanri' ),
			'state'       => $all_exts ? 'ok' : 'error',
			'state_label' => $all_exts ? __( '全て利用可能', 'wpkanri' ) : __( '一部欠落', 'wpkanri' ),
			'detail'      => sprintf(
				'ZipArchive=%s, cURL=%s, mbstring=%s, mysqli=%s',
				$ext_zip ? '✓' : '✗',
				$ext_curl ? '✓' : '✗',
				$ext_mb ? '✓' : '✗',
				$ext_mysqli ? '✓' : '✗'
			),
		);

		// ── Plugin state ───────────────────────────────────
		$plugin_state = array(
			__( 'プラグインバージョン', 'wpkanri' ) => WPKANRI_VERSION,
			__( 'API Base URL', 'wpkanri' )        => $connector->get_api_base(),
			__( 'Site ID', 'wpkanri' )             => $connector->get_site_id() ?: '—',
			__( 'API キー (マスク)', 'wpkanri' )   => $connector->masked_api_key() ?: '—',
			__( '自動チェック設定', 'wpkanri' )    => $scan_schedule_label,
			__( 'スキャン状態 (非同期)', 'wpkanri' ) => $scan_async['status'],
			__( '最終チェック', 'wpkanri' )        => $last_scan && ! empty( $last_scan['finished_at'] )
				? $this->format_datetime( (int) $last_scan['finished_at'] )
				: '—',
			__( 'ホワイトラベルモード', 'wpkanri' ) => $connector->is_whitelabel_mode() ? 'ON' : 'OFF',
		);

		// ── WordPress ──────────────────────────────────────
		$wp_info = array(
			'WordPress'                          => $wp_version,
			__( 'ロケール', 'wpkanri' )           => get_locale(),
			__( 'タイムゾーン', 'wpkanri' )       => (string) wp_timezone_string(),
			__( 'サイト URL', 'wpkanri' )         => home_url(),
			__( 'サイト名', 'wpkanri' )           => get_bloginfo( 'name' ),
			__( 'マルチサイト', 'wpkanri' )       => is_multisite() ? 'Yes' : 'No',
			__( 'WP_DEBUG', 'wpkanri' )           => ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? 'ON' : 'OFF',
			__( 'WP メモリ上限', 'wpkanri' )      => defined( 'WP_MEMORY_LIMIT' ) ? (string) WP_MEMORY_LIMIT : '—',
			__( 'テーブル接頭辞', 'wpkanri' )    => $wpdb->prefix,
			'ABSPATH'                            => ABSPATH,
		);

		// ── Server ─────────────────────────────────────────
		$server = array(
			'PHP'                                      => PHP_VERSION,
			__( 'SAPI', 'wpkanri' )                    => PHP_SAPI,
			__( 'Web サーバー', 'wpkanri' )            => isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '—',
			__( 'OS', 'wpkanri' )                      => PHP_OS,
			__( 'memory_limit', 'wpkanri' )            => (string) ini_get( 'memory_limit' ),
			__( 'max_execution_time', 'wpkanri' )      => (string) ini_get( 'max_execution_time' ) . 's',
			__( 'upload_max_filesize', 'wpkanri' )     => (string) ini_get( 'upload_max_filesize' ),
			__( 'post_max_size', 'wpkanri' )           => (string) ini_get( 'post_max_size' ),
			__( 'MySQL', 'wpkanri' )                   => is_object( $wpdb ) ? (string) $wpdb->db_version() : '—',
			__( '現在メモリ使用量', 'wpkanri' )        => size_format( memory_get_usage( true ) ),
			__( 'ディスク残量 (ABSPATH)', 'wpkanri' )  => function_exists( 'disk_free_space' ) ? size_format( (int) @disk_free_space( ABSPATH ) ) : '—',
		);

		// ── Active theme ───────────────────────────────────
		$theme = wp_get_theme();
		$active_theme = array(
			__( '名前', 'wpkanri' )     => (string) $theme->get( 'Name' ),
			__( 'バージョン', 'wpkanri' ) => (string) $theme->get( 'Version' ),
			__( '作者', 'wpkanri' )     => wp_strip_all_tags( (string) $theme->get( 'Author' ) ),
			__( 'スラッグ', 'wpkanri' ) => (string) $theme->get_stylesheet(),
			__( '親テーマ', 'wpkanri' ) => $theme->parent() ? (string) $theme->parent()->get_stylesheet() : '—',
		);

		// ── Plugins list ───────────────────────────────────
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all_plugins    = get_plugins();
		$active_plugins = (array) get_option( 'active_plugins', array() );
		$plugins = array();
		foreach ( $all_plugins as $file => $data ) {
			$plugins[] = array(
				'name'    => isset( $data['Name'] ) ? (string) $data['Name'] : $file,
				'version' => isset( $data['Version'] ) ? (string) $data['Version'] : '—',
				'active'  => in_array( (string) $file, $active_plugins, true ),
				'file'    => (string) $file,
			);
		}

		// ── Themes list ────────────────────────────────────
		$all_themes = wp_get_themes();
		$active_stylesheet = (string) get_stylesheet();
		$themes = array();
		foreach ( $all_themes as $slug => $t ) {
			$themes[] = array(
				'name'    => (string) $t->get( 'Name' ),
				'version' => (string) $t->get( 'Version' ),
				'active'  => (string) $slug === $active_stylesheet,
				'slug'    => (string) $slug,
			);
		}

		return array(
			'features'     => $features,
			'plugin_state' => $plugin_state,
			'wordpress'    => $wp_info,
			'server'       => $server,
			'active_theme' => $active_theme,
			'plugins'      => $plugins,
			'themes'       => $themes,
		);
	}

	/**
	 * Build a plaintext version of the diagnostics for easy copy+paste.
	 */
	private function diagnostics_as_text( array $d ): string {
		$lines = array();
		$lines[] = '===== WPKanri Diagnostics =====';
		$lines[] = 'Generated: ' . gmdate( 'c' );
		$lines[] = '';

		$lines[] = '--- 機能別 動作状況 ---';
		foreach ( $d['features'] as $f ) {
			$lines[] = sprintf( '[%s] %s — %s', strtoupper( $f['state'] ), $f['name'], $f['detail'] );
		}
		$lines[] = '';

		$sections = array(
			'プラグイン状態' => $d['plugin_state'],
			'WordPress'      => $d['wordpress'],
			'サーバー環境'  => $d['server'],
			'アクティブテーマ' => $d['active_theme'],
		);
		foreach ( $sections as $title => $kv ) {
			$lines[] = '--- ' . $title . ' ---';
			foreach ( $kv as $k => $v ) {
				$lines[] = $k . ': ' . $v;
			}
			$lines[] = '';
		}

		$lines[] = '--- プラグイン一覧 (' . count( $d['plugins'] ) . ') ---';
		foreach ( $d['plugins'] as $p ) {
			$lines[] = sprintf( '%s v%s [%s] — %s', $p['name'], $p['version'], $p['active'] ? 'ON' : 'OFF', $p['file'] );
		}
		$lines[] = '';
		$lines[] = '--- テーマ一覧 (' . count( $d['themes'] ) . ') ---';
		foreach ( $d['themes'] as $t ) {
			$lines[] = sprintf( '%s v%s [%s] — %s', $t['name'], $t['version'], $t['active'] ? 'ACTIVE' : '—', $t['slug'] );
		}
		return implode( "\n", $lines );
	}

	/**
	 * @param array<string,string> $kv
	 */
	private function render_kv_list( array $kv ): void {
		echo '<dl class="wpkanri-kv">';
		foreach ( $kv as $label => $value ) {
			echo '<div class="wpkanri-kv__row">';
			echo '<dt>' . esc_html( (string) $label ) . '</dt>';
			echo '<dd>' . esc_html( (string) $value ) . '</dd>';
			echo '</div>';
		}
		echo '</dl>';
	}

	/**
	 * Emit scoped CSS for the admin page. Kept inline (no asset enqueue) so
	 * the settings screen works even if something breaks the wp-admin asset
	 * pipeline — and so it does not leak onto other admin pages.
	 */
	private function render_admin_styles(): void {
		?>
		<style>
		.wpkanri-admin { max-width: 1280px; }
		.wpkanri-admin__title { font-size: 28px; margin-top: 12px; }
		.wpkanri-admin__subtitle { color: #50575e; font-size: 14px; margin: 4px 0 20px; }

		.wpkanri-cards {
			display: grid;
			grid-template-columns: 1fr;
			gap: 16px;
			margin-top: 20px;
		}
		@media (min-width: 1200px) {
			.wpkanri-cards { grid-template-columns: 2fr 1fr; }
			.wpkanri-card--status { grid-column: 1 / -1; }
			.wpkanri-card--advanced { grid-column: 1 / -1; }
		}

		/* Debug tab: always single column, full width — content is
		   data-dense (tables, long key-value lists) and breaks badly in
		   the 2-col grid used by the main tab. */
		.wpkanri-cards--debug {
			grid-template-columns: 1fr !important;
		}

		.wpkanri-card {
			background: #fff;
			border: 1px solid #dcdcde;
			border-radius: 8px;
			box-shadow: 0 1px 2px rgba(0,0,0,0.04);
			overflow: hidden;
		}
		.wpkanri-card__header {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 12px;
			padding: 16px 20px;
			border-bottom: 1px solid #f0f0f1;
			background: #f9fafb;
			list-style: none;
		}
		.wpkanri-card__header::-webkit-details-marker { display: none; }
		details > .wpkanri-card__header { cursor: pointer; }
		details > .wpkanri-card__header::after {
			content: "▸";
			color: #646970;
			font-size: 12px;
			margin-left: auto;
		}
		details[open] > .wpkanri-card__header::after { content: "▾"; }
		.wpkanri-card__title {
			margin: 0;
			font-size: 15px;
			font-weight: 600;
			color: #1d2327;
		}
		.wpkanri-card__subtitle {
			margin: 0 0 8px;
			font-size: 14px;
			font-weight: 600;
			color: #1d2327;
		}
		.wpkanri-card__body { padding: 20px; }
		.wpkanri-card__actions {
			margin-top: 16px;
			display: flex;
			align-items: center;
			gap: 12px;
			flex-wrap: wrap;
		}

		.wpkanri-lead { font-size: 14px; color: #1d2327; margin: 0 0 10px; }
		.wpkanri-help { font-size: 13px; color: #646970; margin: 0 0 6px; line-height: 1.6; }

		.wpkanri-badge {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			padding: 3px 10px;
			border-radius: 999px;
			font-size: 12px;
			font-weight: 600;
			line-height: 1.6;
		}
		.wpkanri-badge span { font-size: 8px; line-height: 1; }
		.wpkanri-badge--ok    { background: #e7f7ed; color: #15803d; }
		.wpkanri-badge--warn  { background: #fff4e5; color: #b45309; }
		.wpkanri-badge--error { background: #fde8e8; color: #b42318; }

		.wpkanri-meta { margin: 0 0 12px; }
		.wpkanri-meta__row {
			display: grid;
			grid-template-columns: 120px 1fr;
			gap: 12px;
			padding: 6px 0;
			border-bottom: 1px dashed #f0f0f1;
			font-size: 13px;
		}
		.wpkanri-meta__row:last-child { border-bottom: 0; }
		.wpkanri-meta__row dt { color: #646970; margin: 0; }
		.wpkanri-meta__row dd { margin: 0; color: #1d2327; word-break: break-all; }

		.wpkanri-stats {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
			gap: 10px;
			margin: 12px 0 14px;
		}
		.wpkanri-stat {
			padding: 12px 14px;
			border: 1px solid #dcdcde;
			border-radius: 6px;
			background: #fff;
			display: flex;
			flex-direction: column;
			gap: 4px;
		}
		.wpkanri-stat__label { font-size: 12px; color: #646970; }
		.wpkanri-stat__value { font-size: 20px; font-weight: 600; color: #1d2327; font-variant-numeric: tabular-nums; }
		.wpkanri-stat--ok    { background: #f7fbf8; border-color: #c5e5d1; }
		.wpkanri-stat--ok    .wpkanri-stat__value { color: #15803d; }
		.wpkanri-stat--error { background: #fdf6f6; border-color: #f0c2be; }
		.wpkanri-stat--error .wpkanri-stat__value { color: #b42318; }

		.wpkanri-divider {
			border: 0;
			border-top: 1px solid #f0f0f1;
			margin: 24px 0;
		}
		.wpkanri-mismatches { margin: 12px 0; }

		.wpkanri-schedule {
			margin: 10px 0 18px;
			padding: 14px 16px;
			background: #f6f7f7;
			border: 1px solid #dcdcde;
			border-radius: 6px;
			display: flex;
			align-items: center;
			gap: 10px;
			flex-wrap: wrap;
		}
		.wpkanri-schedule__label {
			font-size: 13px;
			font-weight: 600;
			color: #1d2327;
		}
		.wpkanri-schedule__select {
			font-size: 13px;
			padding: 4px 6px;
		}

		.wpkanri-card__subtitle {
			margin-top: 18px;
		}

		.wpkanri-badge--info { background: #e7f1fd; color: #2271b1; }
		.wpkanri-spinner {
			display: inline-block;
			width: 10px;
			height: 10px;
			border: 2px solid currentColor;
			border-right-color: transparent;
			border-radius: 50%;
			vertical-align: middle;
		}
		@media (prefers-reduced-motion: no-preference) {
			.wpkanri-spinner { animation: wpkanri-spin 0.9s linear infinite; }
		}
		@keyframes wpkanri-spin { to { transform: rotate(360deg); } }
		.wpkanri-spinner--lg {
			width: 20px;
			height: 20px;
			border-width: 3px;
			color: #2271b1;
		}
		.wpkanri-running {
			display: flex;
			align-items: flex-start;
			gap: 12px;
			padding: 14px 16px;
			background: #eef5fc;
			border: 1px solid #b8d4ec;
			border-radius: 6px;
			margin: 12px 0;
		}

		.wpkanri-tabs { margin: 16px 0 0; }

		/* Wrapper to allow horizontal scroll on very narrow viewports without
		   compressing the columns and destroying readability. */
		.wpkanri-card__body .wpkanri-diag-table { width: 100%; }
		.wpkanri-diag-table {
			border-collapse: collapse;
			font-size: 13px;
			table-layout: auto;
		}
		.wpkanri-diag-table th,
		.wpkanri-diag-table td {
			text-align: left;
			padding: 10px 14px;
			border-bottom: 1px solid #f0f0f1;
			vertical-align: top;
			line-height: 1.5;
		}
		.wpkanri-diag-table th {
			background: #f9fafb;
			font-weight: 600;
			color: #646970;
			font-size: 12px;
			text-transform: uppercase;
			letter-spacing: 0.02em;
			white-space: nowrap;
		}
		.wpkanri-diag-table tr:last-child td { border-bottom: 0; }
		.wpkanri-diag-table tr:hover td { background: #fafbfc; }
		.wpkanri-diag-table code {
			font-size: 12px;
			background: #f6f7f7;
			padding: 1px 5px;
			border-radius: 3px;
		}
		.wpkanri-diag-table td:first-child { font-weight: 500; color: #1d2327; }

		/* Two-column key/value list. Responsive: stacks on narrow viewports. */
		.wpkanri-kv {
			margin: 0;
			columns: 2;
			column-gap: 32px;
		}
		@media (max-width: 900px) {
			.wpkanri-kv { columns: 1; }
		}
		.wpkanri-kv__row {
			display: grid;
			grid-template-columns: minmax(160px, 1fr) 2fr;
			gap: 12px;
			padding: 8px 0;
			border-bottom: 1px dashed #f0f0f1;
			font-size: 13px;
			break-inside: avoid;
		}
		.wpkanri-kv__row:last-child { border-bottom: 0; }
		.wpkanri-kv__row dt { color: #646970; margin: 0; }
		.wpkanri-kv__row dd {
			margin: 0;
			color: #1d2327;
			word-break: break-all;
			font-family: Menlo, Monaco, Consolas, monospace;
			font-size: 12px;
		}

		.wpkanri-diag-text {
			width: 100%;
			min-height: 240px;
			font-family: Menlo, Monaco, Consolas, "Liberation Mono", monospace;
			font-size: 12px;
			line-height: 1.5;
			background: #f6f7f7;
			color: #1d2327;
			border: 1px solid #dcdcde;
			border-radius: 4px;
			padding: 10px;
			resize: vertical;
		}
		</style>
		<script>
		(function () {
			var card = document.querySelector('[data-wpkanri-scan-card]');
			if (!card || card.getAttribute('data-running') !== '1') return;
			// Poll the current URL every 5 s until the card no longer reports
			// "running". Uses visibility check to skip polling in background tabs.
			setTimeout(function tick() {
				if (document.visibilityState === 'hidden') {
					setTimeout(tick, 5000);
					return;
				}
				window.location.reload();
			}, 5000);
		})();
		</script>
		<?php
	}

	/**
	 * Inline setup wizard shown at the top of the settings page. Displays the
	 * three-step progress (接続 → 初回スキャン → 完了) and highlights the next
	 * action the user should take. Auto-hides the completion banner after the
	 * first time it is shown post-welcome.
	 *
	 * @param array<string,mixed>|null $last_scan
	 */
	private function render_setup_wizard( Connector $connector, string $site_id, ?array $last_scan ): void {
		$connected = '' !== $connector->get_api_key() && '' !== $site_id;
		$scanned   = null !== $last_scan && ! empty( $last_scan['finished_at'] );
		$welcome   = isset( $_GET['welcome'] );

		// Step states: current | done | todo
		$step1 = $connected ? 'done' : 'current';
		$step2 = $connected ? ( $scanned ? 'done' : 'current' ) : 'todo';
		$step3 = $connected && $scanned ? 'done' : 'todo';

		$all_done = $connected && $scanned;
		// Once everything is done, only show the wizard if the user just
		// arrived via the activation redirect (welcome=1).
		if ( $all_done && ! $welcome ) {
			return;
		}
		?>
		<div style="background:#f6f7f7; border:1px solid #dcdcde; border-left:4px solid #2271b1; padding:16px 20px; margin:20px 0; border-radius:4px;">
			<h2 style="margin-top:0;">
				<?php
				echo esc_html(
					$all_done
						? __( 'セットアップ完了', 'wpkanri' )
						: __( '初期セットアップ', 'wpkanri' )
				);
				?>
			</h2>

			<?php if ( $all_done ) : ?>
				<p><?php echo esc_html__( '全ての初期設定が完了しました。クラウドのコンパネからこのサイトを管理できます。', 'wpkanri' ); ?></p>
			<?php else : ?>
				<p><?php echo esc_html__( '以下の 3 ステップで初期設定を完了してください:', 'wpkanri' ); ?></p>
			<?php endif; ?>

			<ol style="list-style:none; padding:0; margin:12px 0 0; display:flex; gap:16px; flex-wrap:wrap;">
				<?php
				$this->render_wizard_step( 1, __( 'クラウドに接続', 'wpkanri' ), $step1 );
				$this->render_wizard_step( 2, __( '初回チェックを実行', 'wpkanri' ), $step2 );
				$this->render_wizard_step( 3, __( '完了', 'wpkanri' ), $step3 );
				?>
			</ol>

			<?php if ( ! $connected ) : ?>
				<p style="margin-top:16px; margin-bottom:0;">
					<strong>
						<?php echo esc_html__( '次のアクション:', 'wpkanri' ); ?>
					</strong>
					<?php echo esc_html__( '下の「接続する」ボタンを押してください。', 'wpkanri' ); ?>
				</p>
			<?php elseif ( ! $scanned ) : ?>
				<p style="margin-top:16px; margin-bottom:0;">
					<strong>
						<?php echo esc_html__( '次のアクション:', 'wpkanri' ); ?>
					</strong>
					<?php echo esc_html__( '下の「今すぐチェック」で初回のコアファイル整合性チェックを実行してください。', 'wpkanri' ); ?>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	private function render_wizard_step( int $number, string $label, string $state ): void {
		$colors = array(
			'done'    => array( 'bg' => '#15803d', 'fg' => '#ffffff', 'icon' => '✓', 'text' => 'color:#15803d;' ),
			'current' => array( 'bg' => '#2271b1', 'fg' => '#ffffff', 'icon' => (string) $number, 'text' => 'color:#2271b1; font-weight:600;' ),
			'todo'    => array( 'bg' => '#dcdcde', 'fg' => '#50575e', 'icon' => (string) $number, 'text' => 'color:#50575e;' ),
		);
		$c = $colors[ $state ] ?? $colors['todo'];
		?>
		<li style="display:flex; align-items:center; gap:8px;">
			<span style="display:inline-flex; align-items:center; justify-content:center; width:24px; height:24px; border-radius:50%; background:<?php echo esc_attr( $c['bg'] ); ?>; color:<?php echo esc_attr( $c['fg'] ); ?>; font-size:13px; font-weight:600;">
				<?php echo esc_html( $c['icon'] ); ?>
			</span>
			<span style="<?php echo esc_attr( $c['text'] ); ?>">
				<?php echo esc_html( $label ); ?>
			</span>
		</li>
		<?php
	}

	// ── Action handlers ──────────────────────────────────────

	public function handle_test(): void {
		$this->ensure_can( self::ACTION_TEST );
		$res = ( new Api_Client() )->ping();
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( '接続に失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$this->push_notice( 'success', __( '接続成功。クラウドから応答がありました。', 'wpkanri' ) );
		}
		$this->redirect_back();
	}

	public function handle_register(): void {
		$this->ensure_can( self::ACTION_REGISTER );
		$name = (string) get_bloginfo( 'name' );
		$url  = (string) home_url();
		$res  = ( new Api_Client() )->register_site( $name, $url );
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( 'サイト登録に失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$site_id = isset( $res['id'] ) ? (string) $res['id'] : '';
			if ( $site_id ) {
				Connector::instance()->set_site_id( $site_id );
				$this->push_notice(
					'success',
					sprintf(
						/* translators: %s: site id */
						__( 'サイトを登録しました: %s', 'wpkanri' ),
						$site_id
					)
				);
			} else {
				$this->push_notice( 'warning', __( 'サイト登録レスポンスに id が含まれていません。', 'wpkanri' ) );
			}
		}
		$this->redirect_back();
	}

	public function handle_scan(): void {
		$this->ensure_can( self::ACTION_SCAN );
		$res = Scanner::instance()->start_async();
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( 'チェック開始に失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$this->push_notice(
				'info',
				__( 'チェックを開始しました。バックグラウンドで実行中です。完了まで画面を閉じても問題ありません (通常 30 秒〜 1 分)。', 'wpkanri' )
			);
		}
		$this->redirect_back();
	}

	// ── Integrity check schedule ─────────────────────────────

	public function handle_save_schedule(): void {
		$this->ensure_can( self::ACTION_SCHEDULE );
		$schedule = isset( $_POST['schedule'] ) ? sanitize_text_field( wp_unslash( $_POST['schedule'] ) ) : 'auto';
		Connector::instance()->set_scan_schedule( $schedule );
		$this->push_notice( 'success', __( '実行タイミングを更新しました。', 'wpkanri' ) );
		$this->redirect_back();
	}

	// ── OAuth-style connect flow ─────────────────────────────

	/**
	 * Kicks off the connect flow. Generates a state nonce, stores it in a
	 * transient, and redirects the admin's browser to the conpanel /connect
	 * route with all parameters the approval screen needs.
	 */
	public function handle_connect_start(): void {
		$this->ensure_can( self::ACTION_CONNECT );

		$connector = Connector::instance();
		$state     = wp_generate_password( 40, false, false );

		set_transient( self::STATE_TRANSIENT, $state, self::STATE_TTL );

		$callback = add_query_arg(
			array( 'action' => self::ACTION_CALLBACK ),
			admin_url( 'admin-post.php' )
		);

		$connect_url = add_query_arg(
			array(
				'state'     => $state,
				'callback'  => $callback,
				'site_url'  => home_url(),
				'site_name' => get_bloginfo( 'name' ),
			),
			untrailingslashit( $connector->get_api_base() ) . '/connect'
		);

		wp_redirect( $connect_url );
		exit;
	}

	/**
	 * Handles the redirect back from the conpanel. Verifies the state matches
	 * our transient, stores the returned api_key + site_id, and redirects the
	 * admin back to the settings page with a notice.
	 */
	public function handle_connect_callback(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'wpkanri' ), '', array( 'response' => 403 ) );
		}

		$received_state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		$stored_state   = (string) get_transient( self::STATE_TRANSIENT );
		delete_transient( self::STATE_TRANSIENT );

		if ( '' === $received_state || '' === $stored_state || ! hash_equals( $stored_state, $received_state ) ) {
			$this->push_notice( 'error', __( '接続リクエストの検証に失敗しました。もう一度「接続する」から開始してください。', 'wpkanri' ) );
			$this->redirect_back();
			return;
		}

		// Check for cancellation from the conpanel.
		if ( isset( $_GET['error'] ) && '' !== $_GET['error'] ) {
			$this->push_notice( 'warning', __( '接続がキャンセルされました。', 'wpkanri' ) );
			$this->redirect_back();
			return;
		}

		$api_key = isset( $_GET['api_key'] ) ? sanitize_text_field( wp_unslash( $_GET['api_key'] ) ) : '';
		$site_id = isset( $_GET['site_id'] ) ? sanitize_text_field( wp_unslash( $_GET['site_id'] ) ) : '';

		// Accept any of the known KanriPress API key prefixes:
		//   kpa_live_ — REST API key (Assist, current)
		//   kpa_mcp_  — MCP token (Assist, current)
		//   kph_live_ — REST API key (Helper, legacy)
		//   kph_mcp_  — MCP token (Helper, legacy)
		// The legacy kph_* prefixes are retained so existing installs do not
		// break when the plugin is upgraded ahead of Worker-side migration.
		$valid_prefix = (
			0 === strpos( $api_key, 'kpa_live_' ) ||
			0 === strpos( $api_key, 'kpa_mcp_' )  ||
			0 === strpos( $api_key, 'kph_live_' ) ||
			0 === strpos( $api_key, 'kph_mcp_' )
		);

		if ( '' === $api_key || '' === $site_id || ! $valid_prefix ) {
			// Persist diagnostic so we can see WHAT came back (no full key —
			// only length + leading 10 chars to avoid leaking the token into
			// the admin notice while still being debuggable).
			$diag = sprintf(
				'site_id=[%s] api_key_len=%d api_key_head=[%s]',
				$site_id,
				strlen( $api_key ),
				substr( $api_key, 0, 10 )
			);
			update_option( 'wpkanri_last_callback_diag', $diag );
			$this->push_notice(
				'error',
				sprintf(
					/* translators: %s: diagnostic string */
					__( '接続情報が正しく返されませんでした。(%s)', 'wpkanri' ),
					$diag
				)
			);
			$this->redirect_back();
			return;
		}

		$connector = Connector::instance();
		$connector->set_api_key( $api_key );
		$connector->set_site_id( $site_id );

		$this->push_notice( 'success', __( '接続が完了しました。', 'wpkanri' ) );
		$this->redirect_back();
	}

	// ── Notice plumbing ──────────────────────────────────────

	public function render_notices(): void {
		$notice = get_transient( self::NOTICE_TRANSIENT );
		if ( ! is_array( $notice ) || empty( $notice['message'] ) ) {
			return;
		}
		delete_transient( self::NOTICE_TRANSIENT );
		$type  = (string) ( $notice['type'] ?? 'info' );
		$class = 'notice notice-' . sanitize_html_class( $type, 'info' );
		printf(
			'<div class="%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $class ),
			esc_html( (string) $notice['message'] )
		);
	}

	private function push_notice( string $type, string $message ): void {
		set_transient(
			self::NOTICE_TRANSIENT,
			array(
				'type'    => $type,
				'message' => $message,
			),
			60
		);
	}

	private function ensure_can( string $action ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'wpkanri' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action );
	}

	private function redirect_back(): void {
		wp_safe_redirect(
			admin_url( 'options-general.php?page=' . self::MENU_SLUG )
		);
		exit;
	}

	private function format_datetime( int $timestamp ): string {
		if ( 0 === $timestamp ) {
			return '-';
		}
		return wp_date( 'Y-m-d H:i', $timestamp );
	}
}
