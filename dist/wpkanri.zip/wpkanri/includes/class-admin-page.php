<?php
/**
 * Admin settings page for WPKanri.
 *
 * Uses WP's Settings API for the persisted fields (API base / API key) and
 * admin-post.php endpoints for the action buttons (test connection, register
 * site, run scan). Everything sits under Settings → WPKanri.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Admin_Page {

	private const MENU_SLUG         = 'wpkanri';
	private const OPTION_GROUP      = 'wpkanri_settings';
	private const ACTION_TEST       = 'wpkanri_test';
	private const ACTION_REGISTER   = 'wpkanri_register';
	private const ACTION_SCAN       = 'wpkanri_scan';
	private const ACTION_CONNECT    = 'wpkanri_connect';
	private const ACTION_CALLBACK   = 'wpkanri_connect_callback';
	private const NOTICE_TRANSIENT  = 'wpkanri_notice';
	private const STATE_TRANSIENT   = 'wpkanri_connect_state';
	private const STATE_TTL         = 15 * MINUTE_IN_SECONDS;

	private static ?Admin_Page $instance = null;

	public static function instance(): Admin_Page {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_init', array( $this, 'maybe_activation_redirect' ) );
		add_action( 'admin_notices', array( $this, 'render_notices' ) );
		add_action( 'admin_notices', array( $this, 'render_setup_notice' ) );

		add_action( 'admin_post_' . self::ACTION_TEST, array( $this, 'handle_test' ) );
		add_action( 'admin_post_' . self::ACTION_REGISTER, array( $this, 'handle_register' ) );
		add_action( 'admin_post_' . self::ACTION_SCAN, array( $this, 'handle_scan' ) );
		add_action( 'admin_post_' . self::ACTION_CONNECT, array( $this, 'handle_connect_start' ) );
		add_action( 'admin_post_' . self::ACTION_CALLBACK, array( $this, 'handle_connect_callback' ) );
	}

	// ── Activation redirect / setup notice ───────────────────

	/**
	 * One-shot redirect to the settings page right after plugin activation.
	 * Guarded by a 30 sec transient so it never fires twice. Skipped in
	 * white-label mode to avoid revealing the KanriPress URL to end clients.
	 */
	public function maybe_activation_redirect(): void {
		if ( ! get_transient( 'wpkanri_activation_redirect' ) ) {
			return;
		}
		delete_transient( 'wpkanri_activation_redirect' );

		// Never redirect on bulk-activate, multisite network activate, or AJAX.
		if ( isset( $_GET['activate-multi'] ) || wp_doing_ajax() || is_network_admin() ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( Connector::instance()->is_whitelabel_mode() ) {
			return;
		}

		wp_safe_redirect( admin_url( 'options-general.php?page=' . self::MENU_SLUG . '&welcome=1' ) );
		exit;
	}

	/**
	 * Global admin notice shown on every admin page (except our own settings
	 * page) when setup is not yet complete. Acts as the "setup wizard" entry
	 * point — one-line prompt with a CTA button to the settings page.
	 *
	 * Entirely suppressed in white-label mode so agency clients do not see
	 * any reference to KanriPress on their site.
	 */
	public function render_setup_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$connector = Connector::instance();
		if ( $connector->is_setup_complete() ) {
			return;
		}
		if ( $connector->is_whitelabel_mode() ) {
			return;
		}

		// Avoid double messaging on our own page (the page already shows the
		// inline wizard).
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false !== strpos( (string) $screen->id, self::MENU_SLUG ) ) {
			return;
		}

		$url = admin_url( 'options-general.php?page=' . self::MENU_SLUG );
		printf(
			'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a href="%3$s" class="button button-primary" style="margin-left:8px;">%4$s</a></p></div>',
			esc_html( $connector->get_brand_name() . ':' ),
			esc_html__( '初期セットアップが完了していません。クラウドに接続してサイトを保護してください。', 'wpkanri' ),
			esc_url( $url ),
			esc_html__( '設定を続ける', 'wpkanri' )
		);
	}

	public function register_menu(): void {
		$brand = Connector::instance()->get_brand_name();
		add_options_page(
			$brand,
			$brand,
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function register_settings(): void {
		register_setting(
			self::OPTION_GROUP,
			Connector::instance()->opt_key( 'api_base' ),
			array(
				'type'              => 'string',
				'sanitize_callback' => 'esc_url_raw',
				'default'           => WPKANRI_DEFAULT_API_BASE,
			)
		);
		register_setting(
			self::OPTION_GROUP,
			Connector::instance()->opt_key( 'api_key' ),
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_api_key' ),
				'default'           => '',
			)
		);
	}

	public function sanitize_api_key( $value ): string {
		$value = is_string( $value ) ? trim( $value ) : '';
		// If the field was left as the masked placeholder, keep the existing key.
		if ( '' === $value || false !== strpos( $value, '…' ) ) {
			return Connector::instance()->get_api_key();
		}
		return sanitize_text_field( $value );
	}

	// ── Page render ──────────────────────────────────────────

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$connector = Connector::instance();
		$api_base  = $connector->get_api_base();
		$masked    = $connector->masked_api_key();
		$site_id   = $connector->get_site_id();
		$last_scan = $connector->get_last_scan();

		$settings_url = admin_url( 'options-general.php?page=' . self::MENU_SLUG );
		$action_url   = admin_url( 'admin-post.php' );
		?>
		<div class="wrap">
			<h1><?php echo esc_html( $connector->get_brand_name() ); ?></h1>
			<p><?php echo esc_html( $connector->get_brand_description() ); ?></p>

			<?php $this->render_setup_wizard( $connector, $site_id, $last_scan ); ?>

			<h2 class="title"><?php echo esc_html__( 'ワンクリック接続 (推奨)', 'wpkanri' ); ?></h2>
			<?php if ( $connector->has_api_key() && $site_id ) : ?>
				<p>
					<?php echo esc_html__( '状態:', 'wpkanri' ); ?>
					<strong style="color:#15803d;">✅ <?php echo esc_html__( '接続済み', 'wpkanri' ); ?></strong>
					&nbsp; <code><?php echo esc_html( $site_id ); ?></code>
					&nbsp; <code><?php echo esc_html( $connector->masked_api_key() ); ?></code>
				</p>
			<?php else : ?>
				<p>
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: host name of the configured API base URL */
							__( 'まだ接続されていません。下のボタンを押すと %s のログイン画面に移動し、承認すると API キーが自動発行されてこのサイトに返却されます。', 'wpkanri' ),
							wp_parse_url( $connector->get_api_base(), PHP_URL_HOST ) ?: 'assist.kanripress.com'
						)
					);
					?>
				</p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( $action_url ); ?>">
				<?php wp_nonce_field( self::ACTION_CONNECT ); ?>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_CONNECT ); ?>" />
				<p>
					<button type="submit" class="button button-primary">
						<?php
						echo esc_html(
							$connector->has_api_key() && $site_id
								? __( '再接続する', 'wpkanri' )
								: __( '接続する', 'wpkanri' )
						);
						?>
					</button>
				</p>
			</form>

			<h2 class="title"><?php echo esc_html__( '接続設定 (手動)', 'wpkanri' ); ?></h2>
			<p class="description"><?php echo esc_html__( '通常は上の「接続する」を使ってください。手動入力はトラブル時の代替手段です。', 'wpkanri' ); ?></p>
			<form method="post" action="options.php">
				<?php settings_fields( self::OPTION_GROUP ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="wpkanri_api_base"><?php echo esc_html__( 'API Base URL', 'wpkanri' ); ?></label>
						</th>
						<td>
							<input
								type="url"
								id="wpkanri_api_base"
								name="<?php echo esc_attr( $connector->opt_key( 'api_base' ) ); ?>"
								value="<?php echo esc_attr( $api_base ); ?>"
								class="regular-text"
								placeholder="https://assist.kanripress.com"
							/>
							<p class="description"><?php echo esc_html__( '通常は既定値のままで結構です。ローカル開発時のみ変更してください。', 'wpkanri' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="wpkanri_api_key"><?php echo esc_html__( 'API キー', 'wpkanri' ); ?></label>
						</th>
						<td>
							<input
								type="text"
								id="wpkanri_api_key"
								name="<?php echo esc_attr( $connector->opt_key( 'api_key' ) ); ?>"
								value="<?php echo esc_attr( $masked ); ?>"
								class="regular-text"
								placeholder="kph_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
								autocomplete="off"
								spellcheck="false"
							/>
							<p class="description">
								<?php echo esc_html__( 'コンパネの「設定 > API キー」で発行したキーを貼り付けてください。既存のキーは masked 表示されます。', 'wpkanri' ); ?>
							</p>
						</td>
					</tr>
				</table>
				<?php submit_button( __( '設定を保存', 'wpkanri' ) ); ?>
			</form>

			<h2 class="title"><?php echo esc_html__( '接続テスト', 'wpkanri' ); ?></h2>
			<form method="post" action="<?php echo esc_url( $action_url ); ?>">
				<?php wp_nonce_field( self::ACTION_TEST ); ?>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_TEST ); ?>" />
				<p>
					<button type="submit" class="button">
						<?php echo esc_html__( '接続テストを実行', 'wpkanri' ); ?>
					</button>
					<span class="description" style="margin-left:8px;">
						<?php echo esc_html__( 'Worker の /api/v1/public/health に到達できるか確認します。', 'wpkanri' ); ?>
					</span>
				</p>
			</form>

			<h2 class="title"><?php echo esc_html__( 'サイト登録', 'wpkanri' ); ?></h2>
			<?php if ( $site_id ) : ?>
				<p>
					<?php echo esc_html__( '状態:', 'wpkanri' ); ?>
					<strong style="color:#15803d;">✅ <?php echo esc_html__( '登録済み', 'wpkanri' ); ?></strong>
					<code><?php echo esc_html( $site_id ); ?></code>
				</p>
			<?php else : ?>
				<p>
					<?php echo esc_html__( '状態:', 'wpkanri' ); ?>
					<strong style="color:#b45309;">⚠️ <?php echo esc_html__( '未登録', 'wpkanri' ); ?></strong>
				</p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( $action_url ); ?>">
				<?php wp_nonce_field( self::ACTION_REGISTER ); ?>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_REGISTER ); ?>" />
				<p>
					<button type="submit" class="button button-primary">
						<?php
						echo esc_html(
							$site_id
								? __( '再登録する', 'wpkanri' )
								: __( '今すぐ登録する', 'wpkanri' )
						);
						?>
					</button>
				</p>
			</form>

			<h2 class="title"><?php echo esc_html__( 'コアスキャン', 'wpkanri' ); ?></h2>
			<?php if ( $last_scan ) : ?>
				<p>
					<?php echo esc_html__( '最終スキャン:', 'wpkanri' ); ?>
					<strong><?php echo esc_html( $this->format_datetime( (int) $last_scan['finished_at'] ) ); ?></strong>
				</p>
				<p>
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: total files, 2: matches, 3: mismatches, 4: unknown */
							__( '全 %1$d ファイル ／ 一致 %2$d ／ 不一致 %3$d ／ 不明 %4$d', 'wpkanri' ),
							(int) $last_scan['total'],
							(int) $last_scan['match'],
							(int) $last_scan['mismatch'],
							(int) $last_scan['unknown']
						)
					);
					?>
					<?php if ( ! empty( $last_scan['truncated'] ) ) : ?>
						<em>(<?php echo esc_html__( '上限打ち切りあり', 'wpkanri' ); ?>)</em>
					<?php endif; ?>
				</p>
				<?php if ( ! empty( $last_scan['mismatches'] ) ) : ?>
					<div class="notice notice-warning inline">
						<p><strong><?php echo esc_html__( '改ざんの疑いがあるファイル:', 'wpkanri' ); ?></strong></p>
						<ul>
							<?php foreach ( $last_scan['mismatches'] as $row ) : ?>
								<li><code><?php echo esc_html( (string) ( $row['path'] ?? '' ) ); ?></code></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endif; ?>
			<?php else : ?>
				<p><?php echo esc_html__( '最終スキャン: 未実行', 'wpkanri' ); ?></p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( $action_url ); ?>">
				<?php wp_nonce_field( self::ACTION_SCAN ); ?>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_SCAN ); ?>" />
				<p>
					<button type="submit" class="button">
						<?php echo esc_html__( '今すぐスキャン', 'wpkanri' ); ?>
					</button>
					<span class="description" style="margin-left:8px;">
						<?php echo esc_html__( 'wp-admin / wp-includes の全ファイルの md5 を Worker と照合します。数十秒かかります。', 'wpkanri' ); ?>
					</span>
				</p>
			</form>
			<?php unset( $settings_url ); ?>
		</div>
		<?php
	}

	/**
	 * Inline setup wizard shown at the top of the settings page. Displays the
	 * three-step progress (接続 → 初回スキャン → 完了) and highlights the next
	 * action the user should take. Auto-hides the completion banner after the
	 * first time it is shown post-welcome.
	 *
	 * @param array<string,mixed>|null $last_scan
	 */
	private function render_setup_wizard( Connector $connector, string $site_id, ?array $last_scan ): void {
		$connected = '' !== $connector->get_api_key() && '' !== $site_id;
		$scanned   = null !== $last_scan && ! empty( $last_scan['finished_at'] );
		$welcome   = isset( $_GET['welcome'] );

		// Step states: current | done | todo
		$step1 = $connected ? 'done' : 'current';
		$step2 = $connected ? ( $scanned ? 'done' : 'current' ) : 'todo';
		$step3 = $connected && $scanned ? 'done' : 'todo';

		$all_done = $connected && $scanned;
		// Once everything is done, only show the wizard if the user just
		// arrived via the activation redirect (welcome=1).
		if ( $all_done && ! $welcome ) {
			return;
		}
		?>
		<div style="background:#f6f7f7; border:1px solid #dcdcde; border-left:4px solid #2271b1; padding:16px 20px; margin:20px 0; border-radius:4px;">
			<h2 style="margin-top:0;">
				<?php
				echo esc_html(
					$all_done
						? __( 'セットアップ完了', 'wpkanri' )
						: __( '初期セットアップ', 'wpkanri' )
				);
				?>
			</h2>

			<?php if ( $all_done ) : ?>
				<p><?php echo esc_html__( '全ての初期設定が完了しました。クラウドのコンパネからこのサイトを管理できます。', 'wpkanri' ); ?></p>
			<?php else : ?>
				<p><?php echo esc_html__( '以下の 3 ステップで初期設定を完了してください:', 'wpkanri' ); ?></p>
			<?php endif; ?>

			<ol style="list-style:none; padding:0; margin:12px 0 0; display:flex; gap:16px; flex-wrap:wrap;">
				<?php
				$this->render_wizard_step( 1, __( 'クラウドに接続', 'wpkanri' ), $step1 );
				$this->render_wizard_step( 2, __( '初回スキャンを実行', 'wpkanri' ), $step2 );
				$this->render_wizard_step( 3, __( '完了', 'wpkanri' ), $step3 );
				?>
			</ol>

			<?php if ( ! $connected ) : ?>
				<p style="margin-top:16px; margin-bottom:0;">
					<strong>
						<?php echo esc_html__( '次のアクション:', 'wpkanri' ); ?>
					</strong>
					<?php echo esc_html__( '下の「接続する」ボタンを押してください。', 'wpkanri' ); ?>
				</p>
			<?php elseif ( ! $scanned ) : ?>
				<p style="margin-top:16px; margin-bottom:0;">
					<strong>
						<?php echo esc_html__( '次のアクション:', 'wpkanri' ); ?>
					</strong>
					<?php echo esc_html__( '下の「今すぐスキャン」で初回スキャンを実行してください。', 'wpkanri' ); ?>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	private function render_wizard_step( int $number, string $label, string $state ): void {
		$colors = array(
			'done'    => array( 'bg' => '#15803d', 'fg' => '#ffffff', 'icon' => '✓', 'text' => 'color:#15803d;' ),
			'current' => array( 'bg' => '#2271b1', 'fg' => '#ffffff', 'icon' => (string) $number, 'text' => 'color:#2271b1; font-weight:600;' ),
			'todo'    => array( 'bg' => '#dcdcde', 'fg' => '#50575e', 'icon' => (string) $number, 'text' => 'color:#50575e;' ),
		);
		$c = $colors[ $state ] ?? $colors['todo'];
		?>
		<li style="display:flex; align-items:center; gap:8px;">
			<span style="display:inline-flex; align-items:center; justify-content:center; width:24px; height:24px; border-radius:50%; background:<?php echo esc_attr( $c['bg'] ); ?>; color:<?php echo esc_attr( $c['fg'] ); ?>; font-size:13px; font-weight:600;">
				<?php echo esc_html( $c['icon'] ); ?>
			</span>
			<span style="<?php echo esc_attr( $c['text'] ); ?>">
				<?php echo esc_html( $label ); ?>
			</span>
		</li>
		<?php
	}

	// ── Action handlers ──────────────────────────────────────

	public function handle_test(): void {
		$this->ensure_can( self::ACTION_TEST );
		$res = ( new Api_Client() )->ping();
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( '接続に失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$this->push_notice( 'success', __( '接続成功。Worker から応答がありました。', 'wpkanri' ) );
		}
		$this->redirect_back();
	}

	public function handle_register(): void {
		$this->ensure_can( self::ACTION_REGISTER );
		$name = (string) get_bloginfo( 'name' );
		$url  = (string) home_url();
		$res  = ( new Api_Client() )->register_site( $name, $url );
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( 'サイト登録に失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$site_id = isset( $res['id'] ) ? (string) $res['id'] : '';
			if ( $site_id ) {
				Connector::instance()->set_site_id( $site_id );
				$this->push_notice(
					'success',
					sprintf(
						/* translators: %s: site id */
						__( 'サイトを登録しました: %s', 'wpkanri' ),
						$site_id
					)
				);
			} else {
				$this->push_notice( 'warning', __( 'サイト登録レスポンスに id が含まれていません。', 'wpkanri' ) );
			}
		}
		$this->redirect_back();
	}

	public function handle_scan(): void {
		$this->ensure_can( self::ACTION_SCAN );
		$res = Scanner::instance()->run();
		if ( is_wp_error( $res ) ) {
			$this->push_notice( 'error', __( 'スキャンに失敗しました: ', 'wpkanri' ) . $res->get_error_message() );
		} else {
			$mismatch = (int) ( $res['mismatch'] ?? 0 );
			if ( $mismatch > 0 ) {
				$this->push_notice(
					'warning',
					sprintf(
						/* translators: %d: number of mismatches */
						__( 'スキャン完了 ― %d 件の不一致が検出されました。', 'wpkanri' ),
						$mismatch
					)
				);
			} else {
				$this->push_notice( 'success', __( 'スキャン完了 ― 改ざんは検出されませんでした。', 'wpkanri' ) );
			}
		}
		$this->redirect_back();
	}

	// ── OAuth-style connect flow ─────────────────────────────

	/**
	 * Kicks off the connect flow. Generates a state nonce, stores it in a
	 * transient, and redirects the admin's browser to the conpanel /connect
	 * route with all parameters the approval screen needs.
	 */
	public function handle_connect_start(): void {
		$this->ensure_can( self::ACTION_CONNECT );

		$connector = Connector::instance();
		$state     = wp_generate_password( 40, false, false );

		set_transient( self::STATE_TRANSIENT, $state, self::STATE_TTL );

		$callback = add_query_arg(
			array( 'action' => self::ACTION_CALLBACK ),
			admin_url( 'admin-post.php' )
		);

		$connect_url = add_query_arg(
			array(
				'state'     => $state,
				'callback'  => $callback,
				'site_url'  => home_url(),
				'site_name' => get_bloginfo( 'name' ),
			),
			untrailingslashit( $connector->get_api_base() ) . '/connect'
		);

		wp_redirect( $connect_url );
		exit;
	}

	/**
	 * Handles the redirect back from the conpanel. Verifies the state matches
	 * our transient, stores the returned api_key + site_id, and redirects the
	 * admin back to the settings page with a notice.
	 */
	public function handle_connect_callback(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'wpkanri' ), '', array( 'response' => 403 ) );
		}

		$received_state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		$stored_state   = (string) get_transient( self::STATE_TRANSIENT );
		delete_transient( self::STATE_TRANSIENT );

		if ( '' === $received_state || '' === $stored_state || ! hash_equals( $stored_state, $received_state ) ) {
			$this->push_notice( 'error', __( '接続リクエストの検証に失敗しました。もう一度「接続する」から開始してください。', 'wpkanri' ) );
			$this->redirect_back();
			return;
		}

		// Check for cancellation from the conpanel.
		if ( isset( $_GET['error'] ) && '' !== $_GET['error'] ) {
			$this->push_notice( 'warning', __( '接続がキャンセルされました。', 'wpkanri' ) );
			$this->redirect_back();
			return;
		}

		$api_key = isset( $_GET['api_key'] ) ? sanitize_text_field( wp_unslash( $_GET['api_key'] ) ) : '';
		$site_id = isset( $_GET['site_id'] ) ? sanitize_text_field( wp_unslash( $_GET['site_id'] ) ) : '';

		if ( '' === $api_key || '' === $site_id || 0 !== strpos( $api_key, 'kph_live_' ) ) {
			$this->push_notice( 'error', __( '接続情報が正しく返されませんでした。', 'wpkanri' ) );
			$this->redirect_back();
			return;
		}

		$connector = Connector::instance();
		$connector->set_api_key( $api_key );
		$connector->set_site_id( $site_id );

		$this->push_notice( 'success', __( '接続が完了しました。', 'wpkanri' ) );
		$this->redirect_back();
	}

	// ── Notice plumbing ──────────────────────────────────────

	public function render_notices(): void {
		$notice = get_transient( self::NOTICE_TRANSIENT );
		if ( ! is_array( $notice ) || empty( $notice['message'] ) ) {
			return;
		}
		delete_transient( self::NOTICE_TRANSIENT );
		$type  = (string) ( $notice['type'] ?? 'info' );
		$class = 'notice notice-' . sanitize_html_class( $type, 'info' );
		printf(
			'<div class="%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $class ),
			esc_html( (string) $notice['message'] )
		);
	}

	private function push_notice( string $type, string $message ): void {
		set_transient(
			self::NOTICE_TRANSIENT,
			array(
				'type'    => $type,
				'message' => $message,
			),
			60
		);
	}

	private function ensure_can( string $action ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'wpkanri' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action );
	}

	private function redirect_back(): void {
		wp_safe_redirect(
			admin_url( 'options-general.php?page=' . self::MENU_SLUG )
		);
		exit;
	}

	private function format_datetime( int $timestamp ): string {
		if ( 0 === $timestamp ) {
			return '-';
		}
		return wp_date( 'Y-m-d H:i', $timestamp );
	}
}
