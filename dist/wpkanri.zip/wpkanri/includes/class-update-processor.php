<?php
/**
 * Update Processor — applies pending updates dispatched by the Worker.
 *
 * Each record returned in `/status`'s `pending_updates` carries:
 *   id             — ULID used when reporting back
 *   component      — plugin | theme | core
 *   slug           — plugin/theme slug (empty for core)
 *   from_version / to_version
 *   apply_mode     — safe | fast | scheduled
 *
 * Apply-mode semantics:
 *   safe       → engage maintenance → WP_Upgrader → disengage maintenance
 *   fast       → no maintenance; atomic rename-based swap (not yet
 *                implemented — falls back to safe with a warning)
 *   scheduled  → same handler as safe; the Worker has already filtered
 *                records by scheduled_apply_at so we just run them.
 *
 * Post-apply, cache is flushed and DB is optimized. Result is reported to
 * `/updates/:id/report`; the Worker then auto-releases maintenance on
 * its side if reason === 'update'.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Update_Processor {

	private static ?Update_Processor $instance = null;

	public static function instance(): Update_Processor {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	/**
	 * Process every pending update in a single poll cycle.
	 *
	 * @param array<int,array<string,mixed>> $updates
	 */
	public function process_batch( array $updates ): void {
		foreach ( $updates as $update ) {
			if ( ! is_array( $update ) ) {
				continue;
			}
			$this->process_one( $update );
		}
	}

	private function process_one( array $update ): void {
		$id        = isset( $update['id'] ) ? (string) $update['id'] : '';
		$component = isset( $update['component'] ) ? (string) $update['component'] : '';
		$slug      = isset( $update['slug'] ) ? (string) $update['slug'] : '';
		$to        = isset( $update['to_version'] ) ? (string) $update['to_version'] : '';
		$mode      = isset( $update['apply_mode'] ) ? (string) $update['apply_mode'] : 'safe';

		if ( '' === $id || '' === $component ) {
			return;
		}

		$client = new Api_Client();
		$site_id = Connector::instance()->get_site_id();

		$use_maintenance = in_array( $mode, array( 'safe', 'scheduled' ), true );

		try {
			if ( $use_maintenance ) {
				Branded_Maintenance::instance()->enable();
				Maintenance::instance()->enable( '', 'update' );
			}

			$apply_result = $this->apply( $component, $slug, $to );

			if ( $use_maintenance ) {
				Maintenance::instance()->disable();
				Branded_Maintenance::instance()->disable();
			}

			if ( true === $apply_result ) {
				// Post-update housekeeping.
				Cache_Clear::flush_all();
				DB_Optimize::run();
				$client->report_update_result( $site_id, $id, 'applied' );
			} else {
				$client->report_update_result( $site_id, $id, 'failed', (string) $apply_result );
			}
		} catch ( \Throwable $e ) {
			if ( $use_maintenance ) {
				// Best-effort: always try to disengage maintenance.
				Maintenance::instance()->disable();
				Branded_Maintenance::instance()->disable();
			}
			$client->report_update_result( $site_id, $id, 'failed', $e->getMessage() );
		}
	}

	/**
	 * @return true|string  True on success; an error message string on failure.
	 */
	private function apply( string $component, string $slug, string $to_version ) {
		if ( ! function_exists( 'request_filesystem_credentials' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';

		// Force-refresh update data so WP_Upgrader has something to install.
		wp_clean_update_cache();
		if ( function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
		}
		if ( function_exists( 'wp_update_themes' ) ) {
			wp_update_themes();
		}

		ob_start();
		$skin = new \WP_Upgrader_Skin();

		if ( 'plugin' === $component ) {
			if ( '' === $slug ) {
				ob_end_clean();
				return 'plugin slug is required';
			}
			// Find plugin file by slug.
			$plugin_file = $this->resolve_plugin_file( $slug );
			if ( null === $plugin_file ) {
				ob_end_clean();
				return sprintf( 'plugin not found: %s', $slug );
			}
			$upgrader = new \Plugin_Upgrader( $skin );
			$result = $upgrader->upgrade( $plugin_file );
		} elseif ( 'theme' === $component ) {
			if ( '' === $slug ) {
				ob_end_clean();
				return 'theme slug is required';
			}
			$upgrader = new \Theme_Upgrader( $skin );
			$result = $upgrader->upgrade( $slug );
		} elseif ( 'core' === $component ) {
			require_once ABSPATH . 'wp-admin/includes/update.php';
			$updates = get_core_updates();
			if ( empty( $updates ) ) {
				ob_end_clean();
				return 'no core updates available';
			}
			$upgrader = new \Core_Upgrader( $skin );
			$result   = $upgrader->upgrade( $updates[0] );
		} else {
			ob_end_clean();
			return sprintf( 'unknown component: %s', $component );
		}

		ob_end_clean();

		if ( is_wp_error( $result ) ) {
			return $result->get_error_message();
		}
		if ( false === $result ) {
			return 'WP_Upgrader returned false';
		}
		unset( $to_version ); // not used but kept in signature for the Worker contract
		return true;
	}

	private function resolve_plugin_file( string $slug ): ?string {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all = get_plugins();
		foreach ( array_keys( $all ) as $file ) {
			// `folder/plugin.php` → folder.
			$parts = explode( '/', (string) $file );
			if ( isset( $parts[0] ) && $parts[0] === $slug ) {
				return (string) $file;
			}
		}
		return null;
	}
}
