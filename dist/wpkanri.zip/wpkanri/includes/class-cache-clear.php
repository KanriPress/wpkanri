<?php
/**
 * Cache Clear helper — calls into every caching plugin we know about
 * plus WP core object cache, suppressing errors if a given plugin is not
 * installed. Used post-update and post-restore.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Cache_Clear {

	/**
	 * Flush every cache layer we can find. Returns a list of engine labels
	 * that were actually invoked so callers can log what happened.
	 *
	 * @return array<int,string>
	 */
	public static function flush_all(): array {
		$invoked = array();

		// WordPress core object cache (memcached / redis drop-ins respect this).
		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
			$invoked[] = 'wp_core';
		}

		// W3 Total Cache
		if ( function_exists( 'w3tc_flush_all' ) ) {
			try {
				w3tc_flush_all();
				$invoked[] = 'w3_total_cache';
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		// WP Rocket
		if ( function_exists( 'rocket_clean_domain' ) ) {
			try {
				rocket_clean_domain();
				$invoked[] = 'wp_rocket';
			} catch ( \Throwable $e ) {
				// ignore
			}
		}
		if ( function_exists( 'rocket_clean_minify' ) ) {
			try {
				rocket_clean_minify();
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		// LiteSpeed Cache
		if ( has_action( 'litespeed_purge_all' ) ) {
			do_action( 'litespeed_purge_all' );
			$invoked[] = 'litespeed';
		}

		// WP Super Cache
		if ( function_exists( 'wp_cache_clean_cache' ) ) {
			global $file_prefix;
			try {
				wp_cache_clean_cache( $file_prefix, true );
				$invoked[] = 'wp_super_cache';
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		// Autoptimize
		if ( class_exists( '\autoptimizeCache' ) && method_exists( '\autoptimizeCache', 'clearall' ) ) {
			try {
				\autoptimizeCache::clearall();
				$invoked[] = 'autoptimize';
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		// Cache Enabler
		if ( class_exists( '\Cache_Enabler' ) && method_exists( '\Cache_Enabler', 'clear_complete_cache' ) ) {
			try {
				\Cache_Enabler::clear_complete_cache();
				$invoked[] = 'cache_enabler';
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		// Breeze
		if ( class_exists( '\Breeze_PurgeCache' ) && method_exists( '\Breeze_PurgeCache', 'breeze_cache_flush' ) ) {
			try {
				\Breeze_PurgeCache::breeze_cache_flush();
				$invoked[] = 'breeze';
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		// SiteGround Optimizer
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			try {
				sg_cachepress_purge_cache();
				$invoked[] = 'sg_optimizer';
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		// Kinsta MU
		if ( class_exists( '\Kinsta\Cache' ) ) {
			try {
				global $kinsta_cache;
				if ( isset( $kinsta_cache->kinsta_cache_purge ) && is_object( $kinsta_cache->kinsta_cache_purge ) ) {
					$kinsta_cache->kinsta_cache_purge->purge_complete_caches();
					$invoked[] = 'kinsta';
				}
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		// Cloudflare plugin (by CF)
		if ( class_exists( '\CF\WordPress\Hooks' ) ) {
			try {
				$cf_hooks = new \CF\WordPress\Hooks();
				if ( method_exists( $cf_hooks, 'purgeCacheEverything' ) ) {
					$cf_hooks->purgeCacheEverything();
					$invoked[] = 'cloudflare';
				}
			} catch ( \Throwable $e ) {
				// ignore
			}
		}

		return $invoked;
	}
}
