<?php
/**
 * Code Snippets — poll pending deployments, execute each with sandboxing
 * guard rails, and report the outcome back.
 *
 * The Worker signs every payload with SHA-256 on the `code` field. We
 * re-compute and refuse execution on mismatch to prevent a replay with
 * mutated code.
 *
 * Execution is intentionally conservative:
 *   - 15 second wall-clock timeout (set_time_limit + signal check)
 *   - Output buffered and returned as stdout (≤ 64 KB)
 *   - `error_reporting` captured, exceptions trapped
 *
 * Only users with `manage_options` effectively trigger this (the API
 * key owner is by definition an Agency admin). End users cannot inject
 * code through this path.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Snippets {

	public const CRON_HOOK = 'wpkanri_snippets_poll';

	private const MAX_STDOUT_BYTES = 64 * 1024;
	private const TIMEOUT_SECONDS  = 15;

	private static ?Snippets $instance = null;

	public static function instance(): Snippets {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( self::CRON_HOOK, array( $this, 'run' ) );
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + 2 * MINUTE_IN_SECONDS, 'hourly', self::CRON_HOOK );
		}
	}

	public static function unschedule(): void {
		$ts = wp_next_scheduled( self::CRON_HOOK );
		if ( false !== $ts ) {
			wp_unschedule_event( $ts, self::CRON_HOOK );
		}
	}

	public function run(): void {
		$connector = Connector::instance();
		if ( ! $connector->is_setup_complete() ) {
			return;
		}

		$client = new Api_Client();
		$response = $client->get_pending_snippets( $connector->get_site_id() );
		if ( is_wp_error( $response ) ) {
			return;
		}

		$snippets = isset( $response['snippets'] ) && is_array( $response['snippets'] ) ? $response['snippets'] : array();
		foreach ( $snippets as $snippet ) {
			if ( ! is_array( $snippet ) ) {
				continue;
			}
			$this->dispatch( $client, $snippet );
		}
	}

	/**
	 * @param array<string,mixed> $snippet
	 */
	private function dispatch( Api_Client $client, array $snippet ): void {
		$id   = isset( $snippet['id'] ) ? (string) $snippet['id'] : '';
		$code = isset( $snippet['code'] ) ? (string) $snippet['code'] : '';
		$sig  = isset( $snippet['sha256'] ) ? (string) $snippet['sha256'] : '';
		if ( '' === $id ) {
			return;
		}

		// ── Integrity check ──
		$actual = hash( 'sha256', $code );
		if ( '' === $sig || ! hash_equals( $sig, $actual ) ) {
			$client->report_snippet_deployment(
				$id,
				'failed',
				array( 'ok' => false, 'error' => 'sha256 mismatch' )
			);
			$this->log_execution( $client, $id, 'rejected_signature', 0, '' );
			return;
		}

		// ── Execute ──
		$result = $this->execute( $code );

		$client->report_snippet_deployment(
			$id,
			$result['ok'] ? 'deployed' : 'failed',
			$result
		);

		$this->log_execution(
			$client,
			$id,
			$result['ok'] ? 'executed' : 'failed',
			strlen( $code ),
			isset( $result['error'] ) ? (string) $result['error'] : ''
		);
	}

	/**
	 * Non-blocking audit-trail entry so snippet executions are visible on the
	 * conpanel timeline alongside other high-risk events (plugin activate,
	 * core updates, etc.).
	 */
	private function log_execution( Api_Client $client, string $id, string $outcome, int $code_bytes, string $error ): void {
		$site_id = Connector::instance()->get_site_id();
		if ( '' === $site_id ) {
			return;
		}
		$client->send_activity(
			$site_id,
			'snippet_exec',
			sprintf( 'snippet %s: %s', $id, $outcome ),
			array(
				'deployment_id' => $id,
				'outcome'       => $outcome,
				'bytes'         => $code_bytes,
				'error'         => mb_substr( $error, 0, 500 ),
			)
		);
	}

	/**
	 * @return array{ok:bool,stdout:string,error:string}
	 */
	private function execute( string $code ): array {
		$previous_limit = (int) ini_get( 'max_execution_time' );
		@set_time_limit( self::TIMEOUT_SECONDS );

		ob_start();
		$error = '';
		try {
			// Execute within an anonymous function to avoid polluting globals.
			$executor = static function () use ( $code ) {
				// phpcs:ignore Squiz.PHP.Eval.Discouraged
				eval( $code );
			};
			$executor();
		} catch ( \Throwable $e ) {
			$error = $e->getMessage();
		}
		$stdout = (string) ob_get_clean();

		if ( strlen( $stdout ) > self::MAX_STDOUT_BYTES ) {
			$stdout = substr( $stdout, 0, self::MAX_STDOUT_BYTES ) . "\n…(truncated)";
		}

		@set_time_limit( $previous_limit > 0 ? $previous_limit : 30 );

		return array(
			'ok'     => '' === $error,
			'stdout' => $stdout,
			'error'  => $error,
		);
	}
}
