<?php
/**
 * WP health REST endpoint.
 *
 * Exposes GET /wp-json/wpkanri/v1/health with a signed token in the
 * X-WPKanri-Token header. The Worker's death-monitor cron (Phase 2) will
 * call this endpoint to detect wp_cron / db / memory issues that HTTP 200
 * alone would miss.
 */

namespace WPKanri;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Health {

	private static ?Health $instance = null;

	public static function instance(): Health {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes(): void {
		register_rest_route(
			WPKANRI_REST_NAMESPACE,
			'/health',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => array( $this, 'check_auth' ),
			)
		);
	}

	/** @return true|WP_Error */
	public function check_auth( WP_REST_Request $request ) {
		$provided = (string) $request->get_header( 'x_wpkanri_token' );
		if ( '' === $provided ) {
			// REST requests pass custom headers through the `x_` prefix. Some
			// proxies strip that so also accept the literal header name.
			$provided = (string) $request->get_header( 'x-wpkanri-token' );
		}
		$expected = Connector::instance()->get_api_key();
		if ( '' === $expected || '' === $provided ) {
			return new WP_Error(
				'wpkanri_unauthorized',
				__( '認証に失敗しました。', 'wpkanri' ),
				array( 'status' => 401 )
			);
		}
		if ( ! hash_equals( $expected, $provided ) ) {
			return new WP_Error(
				'wpkanri_unauthorized',
				__( '認証に失敗しました。', 'wpkanri' ),
				array( 'status' => 401 )
			);
		}
		return true;
	}

	public function handle( WP_REST_Request $request ): WP_REST_Response {
		unset( $request );

		global $wpdb;
		$db_ok = false;
		if ( isset( $wpdb ) ) {
			$db_ok = (bool) $wpdb->get_var( 'SELECT 1' );
		}

		$wp_cron_ok = ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON );

		$memory_usage = $this->format_bytes( memory_get_usage( true ) );
		$memory_limit = (string) ini_get( 'memory_limit' );

		return new WP_REST_Response(
			array(
				'status'         => 'ok',
				'wp_cron'        => $wp_cron_ok,
				'db'             => $db_ok,
				'memory_usage'   => $memory_usage,
				'memory_limit'   => $memory_limit,
				'php_version'    => PHP_VERSION,
				'wp_version'     => (string) get_bloginfo( 'version' ),
				'locale'         => (string) get_locale(),
				'plugin_version' => WPKANRI_VERSION,
			),
			200
		);
	}

	private function format_bytes( int $bytes ): string {
		$units = array( 'B', 'KB', 'MB', 'GB' );
		$unit  = 0;
		$value = (float) $bytes;
		while ( $value >= 1024 && $unit < count( $units ) - 1 ) {
			$value = $value / 1024;
			++$unit;
		}
		return round( $value, 1 ) . $units[ $unit ];
	}
}
