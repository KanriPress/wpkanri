<?php
/**
 * Branded Maintenance — Apache-layer maintenance page.
 *
 * Per the 2026-04-18 spec addition, the server returns a proper 503
 * response even when WordPress is down by rewriting non-asset requests
 * to a prebuilt HTML template stored at the docroot.
 *
 * Files written to ABSPATH:
 *   kanripress-maintenance.html   — rendered template from Worker
 *   kanripress-maintenance.flag   — empty file; presence = maintenance ON
 *   .htaccess                     — gets a BEGIN/END KanriPress block
 *
 * The mu-plugin (kanripress-maintenance-mu.php) acts as the nginx / IIS
 * fallback by serving the same HTML from PHP — both layers are always
 * kept in sync.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Branded_Maintenance {

	private const HTML_FILE         = 'kanripress-maintenance.html';
	private const FLAG_FILE         = 'kanripress-maintenance.flag';
	private const HT_BEGIN          = '# BEGIN KanriPress Maintenance';
	private const HT_END            = '# END KanriPress Maintenance';
	private const OPT_ETAG          = 'wpkanri_maintenance_etag';
	private const OPT_ACTIVE        = 'wpkanri_maintenance_active';
	/** Hard cap on the maintenance HTML body (1 MiB). Guards against disk-fill
	 *  if the Worker or an MITM returns an oversized response. */
	private const MAX_TEMPLATE_BYTES = 1048576;

	private static ?Branded_Maintenance $instance = null;

	public static function instance(): Branded_Maintenance {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	// ── Public API ───────────────────────────────────────────

	public function enable(): bool {
		if ( ! $this->ensure_template() ) {
			return false;
		}
		if ( ! $this->write_flag() ) {
			return false;
		}
		$this->inject_htaccess_block();
		update_option( self::OPT_ACTIVE, true );
		return true;
	}

	public function disable(): void {
		$this->remove_flag();
		$this->remove_htaccess_block();
		update_option( self::OPT_ACTIVE, false );
	}

	/**
	 * Fetch the latest template HTML if the server's ETag differs from ours.
	 * Called both on every poll (template version change) and lazily before
	 * enable() runs.
	 */
	public function maybe_refresh_template(): bool {
		$connector = Connector::instance();
		if ( ! $connector->is_setup_complete() ) {
			return false;
		}

		$client = new Api_Client();
		$prev_etag = (string) get_option( self::OPT_ETAG, '' );
		$result = $client->fetch_maintenance_template( $connector->get_site_id(), $prev_etag );

		if ( is_wp_error( $result ) ) {
			return false;
		}

		$status = (int) ( $result['status'] ?? 0 );
		if ( 304 === $status ) {
			return true; // unchanged, nothing to do
		}
		if ( 200 !== $status ) {
			return false;
		}

		$body = (string) ( $result['body'] ?? '' );
		$etag = (string) ( $result['etag'] ?? '' );
		if ( '' === $body || strlen( $body ) > self::MAX_TEMPLATE_BYTES ) {
			return false;
		}

		$path = ABSPATH . self::HTML_FILE;
		if ( false === @file_put_contents( $path, $body ) ) {
			return false;
		}
		if ( '' !== $etag ) {
			update_option( self::OPT_ETAG, $etag );
		}
		return true;
	}

	// ── Flag file ────────────────────────────────────────────

	private function write_flag(): bool {
		$path = ABSPATH . self::FLAG_FILE;
		if ( file_exists( $path ) ) {
			return true;
		}
		return false !== @file_put_contents( $path, '' );
	}

	private function remove_flag(): void {
		$path = ABSPATH . self::FLAG_FILE;
		if ( file_exists( $path ) ) {
			@unlink( $path );
		}
	}

	private function ensure_template(): bool {
		$path = ABSPATH . self::HTML_FILE;
		if ( file_exists( $path ) ) {
			return true;
		}
		return $this->maybe_refresh_template();
	}

	// ── .htaccess manipulation ───────────────────────────────

	private function htaccess_path(): string {
		return ABSPATH . '.htaccess';
	}

	private function htaccess_block(): string {
		return implode(
			"\n",
			array(
				self::HT_BEGIN,
				'<IfModule mod_rewrite.c>',
				'RewriteEngine On',
				'RewriteCond %{DOCUMENT_ROOT}/' . self::FLAG_FILE . ' -f',
				'RewriteCond %{REQUEST_URI} !^/' . self::HTML_FILE . '$',
				'RewriteCond %{REQUEST_URI} !\\.(css|js|png|jpg|jpeg|svg|gif|webp|ico|woff2?)$',
				'RewriteCond %{HTTP_COOKIE} !kanripress_bypass=([a-f0-9]{32})',
				'RewriteRule ^(.*)$ /' . self::HTML_FILE . ' [R=503,L]',
				'</IfModule>',
				'<IfModule mod_headers.c>',
				'<Files "' . self::HTML_FILE . '">',
				'  Header always set Retry-After "1800"',
				'  Header always set Cache-Control "no-store"',
				'</Files>',
				'</IfModule>',
				self::HT_END,
				'',
			)
		);
	}

	private function inject_htaccess_block(): void {
		$path = $this->htaccess_path();
		$current = file_exists( $path ) ? (string) @file_get_contents( $path ) : '';

		// Strip any previous block first so re-enable replaces cleanly.
		$stripped = $this->strip_block( $current );

		$new = rtrim( $stripped ) . "\n\n" . $this->htaccess_block();
		@file_put_contents( $path, $new );
	}

	private function remove_htaccess_block(): void {
		$path = $this->htaccess_path();
		if ( ! file_exists( $path ) ) {
			return;
		}
		$current = (string) @file_get_contents( $path );
		$new = $this->strip_block( $current );
		if ( $new !== $current ) {
			@file_put_contents( $path, $new );
		}
	}

	private function strip_block( string $content ): string {
		$begin = preg_quote( self::HT_BEGIN, '/' );
		$end   = preg_quote( self::HT_END, '/' );
		return (string) preg_replace( "/{$begin}.*?{$end}\s*/s", '', $content );
	}
}
