<?php
/**
 * Core checksum scanner.
 *
 * Walks wp-admin/ and wp-includes/, computes md5 of each file, and asks the
 * WPKanri Worker whether each hash matches the upstream wp.org
 * checksum for the current WP version/locale. Phase 1 only: the VPS-based
 * Magika + YARA engine will layer on top of this in Phase 2.
 */

namespace WPKanri;

use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Scanner {

	private const MAX_FILES     = 2000;
	private const LOOKUP_CHUNK  = 100;
	private const ALLOWED_EXTS  = array( 'php', 'js', 'css', 'html' );

	private static ?Scanner $instance = null;

	public static function instance(): Scanner {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( WPKANRI_CRON_HOOK, array( $this, 'run' ) );
	}

	/**
	 * Execute a scan pass and persist the result.
	 *
	 * @return array<string,mixed>|WP_Error
	 */
	public function run() {
		$connector = Connector::instance();
		if ( ! $connector->has_api_key() ) {
			return new WP_Error(
				'wpkanri_no_api_key',
				__( 'API キーが未設定のためスキャンを実行できません。', 'wpkanri' )
			);
		}

		$wp_version = (string) get_bloginfo( 'version' );
		$locale     = $this->normalize_locale( (string) get_locale() );

		$files = $this->collect_files();
		$total = count( $files );
		$truncated = $total >= self::MAX_FILES;

		$client = new Api_Client();
		$match_count    = 0;
		$mismatch_count = 0;
		$unknown_count  = 0;
		$mismatches     = array();

		foreach ( array_chunk( $files, self::LOOKUP_CHUNK ) as $chunk ) {
			$response = $client->lookup_checksums( $wp_version, $locale, $chunk );
			if ( is_wp_error( $response ) ) {
				return $response;
			}
			$matches = isset( $response['matches'] ) && is_array( $response['matches'] )
				? $response['matches']
				: array();
			foreach ( $matches as $row ) {
				if ( ! is_array( $row ) || empty( $row['path'] ) || empty( $row['status'] ) ) {
					continue;
				}
				switch ( $row['status'] ) {
					case 'match':
						++$match_count;
						break;
					case 'mismatch':
						++$mismatch_count;
						$mismatches[] = array(
							'path'     => (string) $row['path'],
							'expected' => isset( $row['expected'] ) ? (string) $row['expected'] : '',
						);
						break;
					default:
						++$unknown_count;
				}
			}
		}

		$result = array(
			'finished_at' => time(),
			'wp_version'  => $wp_version,
			'locale'      => $locale,
			'total'       => $total,
			'match'       => $match_count,
			'mismatch'    => $mismatch_count,
			'unknown'     => $unknown_count,
			'truncated'   => $truncated,
			'mismatches'  => array_slice( $mismatches, 0, 50 ),
		);
		$connector->set_last_scan( $result );
		return $result;
	}

	// ── Internal ─────────────────────────────────────────────

	/**
	 * @return array<int,array{path:string,md5:string}>
	 */
	private function collect_files(): array {
		$roots = array(
			'wp-admin'    => ABSPATH . 'wp-admin',
			'wp-includes' => ABSPATH . 'wp-includes',
		);

		$collected = array();
		foreach ( $roots as $label => $root ) {
			if ( ! is_dir( $root ) ) {
				continue;
			}
			$this->walk_directory( $root, $label, $collected );
			if ( count( $collected ) >= self::MAX_FILES ) {
				break;
			}
		}

		return array_slice( $collected, 0, self::MAX_FILES );
	}

	/**
	 * @param array<int,array{path:string,md5:string}> $out
	 */
	private function walk_directory( string $root, string $rel_root, array &$out ): void {
		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator(
					$root,
					RecursiveDirectoryIterator::SKIP_DOTS | RecursiveDirectoryIterator::FOLLOW_SYMLINKS
				),
				RecursiveIteratorIterator::LEAVES_ONLY
			);
		} catch ( \Throwable $e ) {
			return;
		}

		foreach ( $iterator as $file ) {
			if ( count( $out ) >= self::MAX_FILES ) {
				return;
			}
			if ( ! $file->isFile() ) {
				continue;
			}
			$ext = strtolower( $file->getExtension() );
			if ( ! in_array( $ext, self::ALLOWED_EXTS, true ) ) {
				continue;
			}
			$path = $file->getPathname();
			if ( false !== strpos( $path, DIRECTORY_SEPARATOR . '.' ) ) {
				continue; // skip dotfiles/dirs
			}
			$md5 = @md5_file( $path );
			if ( false === $md5 ) {
				continue;
			}
			$relative = $rel_root . '/' . ltrim(
				str_replace( array( $root, DIRECTORY_SEPARATOR ), array( '', '/' ), $path ),
				'/'
			);
			$out[] = array(
				'path' => $relative,
				'md5'  => $md5,
			);
		}
	}

	private function normalize_locale( string $locale ): string {
		// wp.org checksum API accepts "en_US", "ja", "fr_FR"...
		if ( '' === $locale || 'en' === $locale ) {
			return 'en_US';
		}
		return $locale;
	}
}
