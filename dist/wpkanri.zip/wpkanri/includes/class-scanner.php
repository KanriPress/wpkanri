<?php
/**
 * Core checksum scanner.
 *
 * Walks wp-admin/ and wp-includes/, computes md5 of each file, and asks the
 * WPKanri Worker whether each hash matches the upstream wp.org
 * checksum for the current WP version/locale. Phase 1 only: the VPS-based
 * Magika + YARA engine will layer on top of this in Phase 2.
 */

namespace WPKanri;

use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Scanner {

	private const MAX_FILES     = 2000;
	private const LOOKUP_CHUNK  = 100;
	private const ALLOWED_EXTS  = array( 'php', 'js', 'css', 'html' );

	private static ?Scanner $instance = null;

	public static function instance(): Scanner {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	/** Option keys for async status tracking. */
	public const OPT_STATUS     = 'wpkanri_scan_status';
	public const OPT_STARTED_AT = 'wpkanri_scan_started_at';
	public const OPT_ERROR      = 'wpkanri_scan_last_error';

	/** One-off cron hook for user-initiated (background) scans. */
	public const CRON_MANUAL = 'wpkanri_scan_manual_now';

	/** AJAX action name for async loopback trigger. */
	public const AJAX_ACTION = 'wpkanri_run_async_scan';

	/** Option holding the one-time trigger token. */
	private const OPT_TRIGGER_TOKEN = 'wpkanri_scan_trigger_token';

	public function boot(): void {
		add_action( WPKANRI_CRON_HOOK, array( $this, 'run' ) );
		add_action( self::CRON_MANUAL, array( $this, 'run_async' ) );

		// Async loopback endpoint (called by start_async via wp_remote_post).
		// Uses nopriv because cookies don't always survive a loopback fetch
		// on sandboxes like InstaWP; we authenticate via a one-time token.
		add_action( 'wp_ajax_' . self::AJAX_ACTION, array( $this, 'handle_ajax' ) );
		add_action( 'wp_ajax_nopriv_' . self::AJAX_ACTION, array( $this, 'handle_ajax' ) );

		// Graceful fallback: if status has been "running" with no progress
		// for a short while, take the opportunity of this admin pageload to
		// run the scan inline. Guarantees completion even when wp-cron never
		// fires and the AJAX loopback is also blocked.
		if ( is_admin() && ! wp_doing_ajax() && ! wp_doing_cron() ) {
			add_action( 'admin_init', array( $this, 'maybe_run_inline_fallback' ), 20 );
		}
	}

	/**
	 * Fire a scan in the background. Returns immediately after scheduling the
	 * cron event — the actual work happens in another PHP process.
	 *
	 * @return true|\WP_Error
	 */
	public function start_async() {
		$connector = Connector::instance();
		if ( ! $connector->has_api_key() ) {
			return new WP_Error(
				'wpkanri_no_api_key',
				__( 'API キーが未設定のためチェックを実行できません。', 'wpkanri' )
			);
		}

		$status = (string) get_option( self::OPT_STATUS, 'idle' );
		if ( 'running' === $status ) {
			$started = (int) get_option( self::OPT_STARTED_AT, 0 );
			// Stale lock after 10 minutes — allow retry.
			if ( $started > 0 && time() - $started < 10 * MINUTE_IN_SECONDS ) {
				return new WP_Error(
					'wpkanri_scan_already_running',
					__( '既にチェックが実行中です。完了までお待ちください。', 'wpkanri' )
				);
			}
		}

		update_option( self::OPT_STATUS, 'running' );
		update_option( self::OPT_STARTED_AT, time() );
		delete_option( self::OPT_ERROR );

		// Mint a one-time token used to authenticate the loopback HTTP call
		// below. Cookies are unreliable on sandboxed WP hosts (InstaWP etc.),
		// so we sign the async trigger instead.
		$token = wp_generate_password( 40, false, false );
		update_option( self::OPT_TRIGGER_TOKEN, $token );

		// 1) Non-blocking loopback to admin-ajax.php — this is the primary
		//    trigger. Fires immediately in a separate PHP worker.
		$ajax_url = admin_url( 'admin-ajax.php' );
		wp_remote_post(
			$ajax_url,
			array(
				'timeout'    => 0.1,
				'blocking'   => false,
				'sslverify'  => apply_filters( 'https_local_ssl_verify', false ),
				'user-agent' => defined( 'WPKANRI_HTTP_USER_AGENT' ) ? WPKANRI_HTTP_USER_AGENT : 'WPKanri',
				'body'       => array(
					'action' => self::AJAX_ACTION,
					'token'  => $token,
				),
			)
		);

		// 2) Also schedule a cron event as a secondary path in case the
		//    loopback HTTP is blocked by the host.
		wp_schedule_single_event( time(), self::CRON_MANUAL );
		if ( function_exists( 'spawn_cron' ) ) {
			spawn_cron();
		}

		// (Tertiary fallback: maybe_run_inline_fallback() on next admin page
		// load will run inline if neither of the above fires within 30 s.)

		return true;
	}

	/**
	 * Admin-ajax handler — validates the one-time token and runs the scan.
	 * No Firebase/WP auth is checked here because we only trust the token
	 * we just minted in start_async(); loopback cookies are unreliable.
	 */
	public function handle_ajax(): void {
		// Per-IP throttle to prevent brute-force of the one-time token.
		$remote_ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
		$throttle_k = 'wpkanri_scan_trigger_fails_' . md5( $remote_ip );
		$fail_count = (int) get_transient( $throttle_k );
		if ( $fail_count >= 5 ) {
			wp_send_json_error( 'rate limited', 429 );
		}

		$token    = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$expected = (string) get_option( self::OPT_TRIGGER_TOKEN, '' );
		if ( '' === $expected || '' === $token || ! hash_equals( $expected, $token ) ) {
			set_transient( $throttle_k, $fail_count + 1, 15 * MINUTE_IN_SECONDS );
			wp_send_json_error( 'invalid token', 403 );
		}
		// Consume the token so it cannot be replayed; clear throttle on success.
		delete_option( self::OPT_TRIGGER_TOKEN );
		delete_transient( $throttle_k );

		// Allow enough time to process; wp_ajax has no default hard cap.
		@set_time_limit( 120 );
		@ignore_user_abort( true );

		$this->run_async();
		wp_send_json_success( array( 'status' => (string) get_option( self::OPT_STATUS, 'idle' ) ) );
	}

	/**
	 * Last-resort: when the user lands on an admin page and status is still
	 * "running" after 30 s with no progress, the async worker clearly didn't
	 * fire. Run the scan inline on this pageload so the user eventually sees
	 * results even on hosts where both loopback HTTP and wp-cron are dead.
	 */
	public function maybe_run_inline_fallback(): void {
		$status = (string) get_option( self::OPT_STATUS, 'idle' );
		if ( 'running' !== $status ) {
			return;
		}
		$started = (int) get_option( self::OPT_STARTED_AT, 0 );
		if ( 0 === $started || time() - $started < 30 ) {
			return;
		}
		// Only run on pages where the user is deliberately interacting with
		// WP admin (not every auto-ping). Limit to our own settings page.
		if ( ! isset( $_GET['page'] ) || 'wpkanri' !== $_GET['page'] ) {
			return;
		}
		// Extra guard so we don't start 3 fallbacks in a row on slow hosts.
		if ( get_transient( 'wpkanri_scan_fallback_lock' ) ) {
			return;
		}
		set_transient( 'wpkanri_scan_fallback_lock', 1, 5 * MINUTE_IN_SECONDS );

		@set_time_limit( 120 );
		@ignore_user_abort( true );
		$this->run_async();

		delete_transient( 'wpkanri_scan_fallback_lock' );
	}

	/**
	 * Wrapper used as the async cron callback — runs run() and persists
	 * status transitions + errors.
	 */
	public function run_async(): void {
		$result = $this->run();
		if ( is_wp_error( $result ) ) {
			update_option( self::OPT_STATUS, 'failed' );
			update_option( self::OPT_ERROR, $result->get_error_message() );
		} else {
			update_option( self::OPT_STATUS, 'complete' );
			delete_option( self::OPT_ERROR );
		}
	}

	/**
	 * @return array{status:string,started_at:int,error:string}
	 */
	public function get_async_status(): array {
		return array(
			'status'     => (string) get_option( self::OPT_STATUS, 'idle' ),
			'started_at' => (int) get_option( self::OPT_STARTED_AT, 0 ),
			'error'      => (string) get_option( self::OPT_ERROR, '' ),
		);
	}

	/**
	 * Execute a scan pass and persist the result.
	 *
	 * @return array<string,mixed>|WP_Error
	 */
	public function run() {
		$connector = Connector::instance();
		if ( ! $connector->has_api_key() ) {
			return new WP_Error(
				'wpkanri_no_api_key',
				__( 'API キーが未設定のためスキャンを実行できません。', 'wpkanri' )
			);
		}

		$wp_version = (string) get_bloginfo( 'version' );
		$locale     = $this->normalize_locale( (string) get_locale() );

		$files = $this->collect_files();
		$total = count( $files );
		$truncated = $total >= self::MAX_FILES;

		$client = new Api_Client();
		$match_count    = 0;
		$mismatch_count = 0;
		$unknown_count  = 0;
		$mismatches     = array();

		foreach ( array_chunk( $files, self::LOOKUP_CHUNK ) as $chunk ) {
			$response = $client->lookup_checksums( $wp_version, $locale, $chunk );
			if ( is_wp_error( $response ) ) {
				return $response;
			}
			$matches = isset( $response['matches'] ) && is_array( $response['matches'] )
				? $response['matches']
				: array();
			foreach ( $matches as $row ) {
				if ( ! is_array( $row ) || empty( $row['path'] ) || empty( $row['status'] ) ) {
					continue;
				}
				switch ( $row['status'] ) {
					case 'match':
						++$match_count;
						break;
					case 'mismatch':
						++$mismatch_count;
						$mismatches[] = array(
							'path'     => (string) $row['path'],
							'expected' => isset( $row['expected'] ) ? (string) $row['expected'] : '',
						);
						break;
					default:
						++$unknown_count;
				}
			}
		}

		$result = array(
			'finished_at' => time(),
			'wp_version'  => $wp_version,
			'locale'      => $locale,
			'total'       => $total,
			'match'       => $match_count,
			'mismatch'    => $mismatch_count,
			'unknown'     => $unknown_count,
			'truncated'   => $truncated,
			'mismatches'  => array_slice( $mismatches, 0, 50 ),
		);
		$connector->set_last_scan( $result );
		return $result;
	}

	// ── Internal ─────────────────────────────────────────────

	/**
	 * @return array<int,array{path:string,md5:string}>
	 */
	private function collect_files(): array {
		$roots = array(
			'wp-admin'    => ABSPATH . 'wp-admin',
			'wp-includes' => ABSPATH . 'wp-includes',
		);

		$collected = array();
		foreach ( $roots as $label => $root ) {
			if ( ! is_dir( $root ) ) {
				continue;
			}
			$this->walk_directory( $root, $label, $collected );
			if ( count( $collected ) >= self::MAX_FILES ) {
				break;
			}
		}

		return array_slice( $collected, 0, self::MAX_FILES );
	}

	/**
	 * @param array<int,array{path:string,md5:string}> $out
	 */
	private function walk_directory( string $root, string $rel_root, array &$out ): void {
		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator(
					$root,
					RecursiveDirectoryIterator::SKIP_DOTS | RecursiveDirectoryIterator::FOLLOW_SYMLINKS
				),
				RecursiveIteratorIterator::LEAVES_ONLY
			);
		} catch ( \Throwable $e ) {
			return;
		}

		foreach ( $iterator as $file ) {
			if ( count( $out ) >= self::MAX_FILES ) {
				return;
			}
			if ( ! $file->isFile() ) {
				continue;
			}
			$ext = strtolower( $file->getExtension() );
			if ( ! in_array( $ext, self::ALLOWED_EXTS, true ) ) {
				continue;
			}
			$path = $file->getPathname();
			if ( false !== strpos( $path, DIRECTORY_SEPARATOR . '.' ) ) {
				continue; // skip dotfiles/dirs
			}
			$md5 = @md5_file( $path );
			if ( false === $md5 ) {
				continue;
			}
			$relative = $rel_root . '/' . ltrim(
				str_replace( array( $root, DIRECTORY_SEPARATOR ), array( '', '/' ), $path ),
				'/'
			);
			$out[] = array(
				'path' => $relative,
				'md5'  => $md5,
			);
		}
	}

	private function normalize_locale( string $locale ): string {
		// wp.org checksum API accepts "en_US", "ja", "fr_FR"...
		if ( '' === $locale || 'en' === $locale ) {
			return 'en_US';
		}
		return $locale;
	}
}
