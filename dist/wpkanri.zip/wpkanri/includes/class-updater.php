<?php
/**
 * Auto-update from GitHub Releases via Plugin Update Checker (PUC) v5.6.
 *
 * Reads release metadata from https://github.com/<owner>/<repo>/releases
 * and injects it into WordPress's native update pipeline, so users see the
 * "An update is available" notice on the Plugins screen and can install it
 * with one click — exactly like a plugin hosted on wp.org.
 *
 * The release ZIP must be a release *asset* (not the auto-generated source
 * archive) named `wpkanri.zip` and containing a top-level `wpkanri/` folder
 * that matches the installed plugin directory.
 *
 * Configurable via constants so agencies can repoint to a fork:
 *   WPKANRI_GITHUB_REPO         — owner/repo (default: KanriPress/wpkanri)
 *   WPKANRI_GITHUB_BRANCH       — branch for pre-releases (default: main)
 *   WPKANRI_DISABLE_AUTO_UPDATE — set truthy to disable the check entirely
 *
 * @see https://github.com/YahnisElsts/plugin-update-checker
 */

namespace WPKanri;

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Updater {

	private const DEFAULT_REPO   = 'KanriPress/wpkanri';
	private const DEFAULT_BRANCH = 'main';
	private const SLUG           = 'wpkanri';

	private static ?Updater $instance = null;

	public static function instance(): Updater {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		if ( defined( 'WPKANRI_DISABLE_AUTO_UPDATE' ) && WPKANRI_DISABLE_AUTO_UPDATE ) {
			return;
		}

		$library = WPKANRI_PLUGIN_DIR . 'vendor/plugin-update-checker/plugin-update-checker.php';
		if ( ! file_exists( $library ) ) {
			return;
		}
		require_once $library;

		if ( ! class_exists( PucFactory::class ) ) {
			return;
		}

		$repo   = defined( 'WPKANRI_GITHUB_REPO' ) ? (string) WPKANRI_GITHUB_REPO : self::DEFAULT_REPO;
		$branch = defined( 'WPKANRI_GITHUB_BRANCH' ) ? (string) WPKANRI_GITHUB_BRANCH : self::DEFAULT_BRANCH;

		$checker = PucFactory::buildUpdateChecker(
			sprintf( 'https://github.com/%s/', $repo ),
			WPKANRI_PLUGIN_FILE,
			self::SLUG
		);

		// Pull updates from tagged releases (release assets), not raw branch heads.
		$checker->setBranch( $branch );
		$api = $checker->getVcsApi();
		if ( method_exists( $api, 'enableReleaseAssets' ) ) {
			// Accept any asset with a .zip extension so we can ship `wpkanri.zip`.
			$api->enableReleaseAssets( '/\\.zip($|\\?)/i' );
		}
	}
}
