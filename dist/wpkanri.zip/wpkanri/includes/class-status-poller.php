<?php
/**
 * Status Poller — polls GET /api/v1/public/sites/:id/status every 5 min
 * via wp-cron and dispatches the response to feature handlers:
 *
 *   maintenance.enabled  → Maintenance / Branded_Maintenance
 *   pending_updates      → Update_Processor
 *   template_version     → Branded_Maintenance::refresh_template()
 *
 * The polling interval is hard-coded at 5 minutes per the spec
 * (kanripresshelper.md + project_decisions_2026_04_16.md). The Worker
 * side can return `poll_interval_seconds` to override but we currently
 * always respect the default.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Status_Poller {

	public const CRON_HOOK   = 'wpkanri_status_poll';
	private const LOCK_KEY   = 'wpkanri_status_poll_lock';
	private const LOCK_TTL   = 60; // seconds — must be < cron interval (5 min).

	private static ?Status_Poller $instance = null;

	public static function instance(): Status_Poller {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( self::CRON_HOOK, array( $this, 'run' ) );
	}

	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			// Start 1 minute out so activation does not trigger an immediate poll.
			wp_schedule_event( time() + 60, 'wpkanri_5min', self::CRON_HOOK );
		}
	}

	public static function unschedule(): void {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		if ( false !== $timestamp ) {
			wp_unschedule_event( $timestamp, self::CRON_HOOK );
		}
	}

	/**
	 * Register the 5-minute custom cron schedule.
	 */
	public static function register_schedule( array $schedules ): array {
		if ( ! isset( $schedules['wpkanri_5min'] ) ) {
			$schedules['wpkanri_5min'] = array(
				'interval' => 5 * MINUTE_IN_SECONDS,
				'display'  => __( 'Every 5 Minutes (WPKanri)', 'wpkanri' ),
			);
		}
		return $schedules;
	}

	public function run(): void {
		$connector = Connector::instance();
		if ( ! $connector->is_setup_complete() ) {
			return;
		}

		// Skip if a previous poll is still in flight. TTL bounds stale locks
		// if PHP crashes before release.
		if ( false !== get_transient( self::LOCK_KEY ) ) {
			return;
		}
		set_transient( self::LOCK_KEY, 1, self::LOCK_TTL );

		try {
			$client   = new Api_Client();
			$response = $client->get_site_status( $connector->get_site_id() );
			if ( is_wp_error( $response ) ) {
				// Swallow — polling failures are non-fatal.
				return;
			}

			// ── Maintenance ──
			$maintenance = isset( $response['maintenance'] ) && is_array( $response['maintenance'] ) ? $response['maintenance'] : array();
			$this->handle_maintenance( $maintenance );

			// ── Pending updates ──
			$pending = isset( $response['pending_updates'] ) && is_array( $response['pending_updates'] ) ? $response['pending_updates'] : array();
			if ( ! empty( $pending ) ) {
				Update_Processor::instance()->process_batch( $pending );
			}
		} finally {
			delete_transient( self::LOCK_KEY );
		}
	}

	/**
	 * @param array<string,mixed> $maintenance
	 */
	private function handle_maintenance( array $maintenance ): void {
		$enabled = ! empty( $maintenance['enabled'] );
		$reason  = isset( $maintenance['reason'] ) ? (string) $maintenance['reason'] : 'manual';
		$message = isset( $maintenance['message'] ) ? (string) $maintenance['message'] : '';

		// Refresh branded template cache if the version changed.
		if ( isset( $maintenance['template_version'] ) && is_string( $maintenance['template_version'] ) ) {
			Branded_Maintenance::instance()->maybe_refresh_template();
		}

		if ( $enabled ) {
			Branded_Maintenance::instance()->enable();
			Maintenance::instance()->enable( $message, $reason );
		} else {
			Branded_Maintenance::instance()->disable();
			Maintenance::instance()->disable();
		}
	}
}
