<?php
/**
 * Connection Options — reads the `site_connection_options` blob that
 * the Worker returns in the `/status` response and materialises it
 * locally so subsequent wp_remote_* calls can honour it.
 *
 * Currently handles:
 *   - HTTP Basic auth headers on outbound Worker calls (if the
 *     upstream proxy requires Basic to reach this WP site back-end)
 *   - Forcing the Cloudflare Tunnel hostname into `home_url` filter
 *     results when reverse-tunnelling
 *
 * The Worker stores much richer settings (IP allowlists, Tunnel
 * tokens, etc.) but those require infrastructure outside the plugin's
 * reach. We stay conservative and only apply what is applicable
 * inside PHP-land.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Connection_Options {

	private const OPT_CACHE = 'wpkanri_connection_options';

	private static ?Connection_Options $instance = null;

	public static function instance(): Connection_Options {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		// Filter outbound HTTP so requests to our Worker include Basic
		// auth when the upstream requires it (reverse situation — Worker
		// → plugin over Tunnel needs Basic). For plugin → Worker direction
		// we typically do not need Basic, but the option field carries
		// both directions in case the install runs behind corporate IdP.
		add_filter( 'http_request_args', array( $this, 'filter_request_args' ), 10, 2 );
	}

	/**
	 * Called from Status_Poller after every poll to keep the local cache
	 * in sync with the Worker's view.
	 *
	 * @param array<string,mixed> $options
	 */
	public function store( array $options ): void {
		update_option( self::OPT_CACHE, $options );
	}

	/**
	 * @return array<string,mixed>
	 */
	public function get(): array {
		$value = get_option( self::OPT_CACHE, array() );
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Attach Basic auth to outbound requests that target assist.kanripress.com
	 * when the option `outbound_basic_auth` is populated.
	 *
	 * @param array<string,mixed> $args
	 * @param string              $url
	 * @return array<string,mixed>
	 */
	public function filter_request_args( $args, $url ) {
		if ( ! is_array( $args ) ) {
			return $args;
		}
		$opts = $this->get();
		$basic = isset( $opts['outbound_basic_auth'] ) && is_array( $opts['outbound_basic_auth'] )
			? $opts['outbound_basic_auth']
			: null;
		if ( null === $basic ) {
			return $args;
		}

		$user = isset( $basic['user'] ) ? (string) $basic['user'] : '';
		$pass = isset( $basic['pass'] ) ? (string) $basic['pass'] : '';
		if ( '' === $user ) {
			return $args;
		}

		// Only attach when hitting our configured API base.
		$api_base = Connector::instance()->get_api_base();
		if ( '' === $api_base || 0 !== strpos( (string) $url, untrailingslashit( $api_base ) ) ) {
			return $args;
		}

		if ( ! isset( $args['headers'] ) || ! is_array( $args['headers'] ) ) {
			$args['headers'] = array();
		}
		$args['headers']['Authorization'] = 'Basic ' . base64_encode( $user . ':' . $pass );
		return $args;
	}
}
