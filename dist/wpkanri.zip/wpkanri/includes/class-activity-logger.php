<?php
/**
 * Activity Logger — sends audit-trail events to the Worker.
 *
 * The Worker stores these under `/api/v1/public/activity` and surfaces
 * them on the site's timeline in the conpanel. We stick to WordPress
 * core hooks only so the logger keeps working on any stack.
 *
 * Every dispatch is non-blocking.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Activity_Logger {

	/**
	 * Whitelist of option keys that represent meaningful settings changes.
	 * Noise (transients, session tokens, cron hooks etc.) is filtered out.
	 */
	private const WATCHED_OPTIONS = array(
		'blogname',
		'blogdescription',
		'siteurl',
		'home',
		'admin_email',
		'template',
		'stylesheet',
		'permalink_structure',
		'default_role',
		'users_can_register',
		'blog_public',
		'WPLANG',
	);

	private static ?Activity_Logger $instance = null;

	public static function instance(): Activity_Logger {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		// Plugin activate / deactivate
		add_action( 'activated_plugin', array( $this, 'on_plugin_activated' ), 10, 2 );
		add_action( 'deactivated_plugin', array( $this, 'on_plugin_deactivated' ), 10, 2 );

		// Updates (core / plugin / theme) succeed
		add_action( 'upgrader_process_complete', array( $this, 'on_upgrader_complete' ), 10, 2 );

		// User admin
		add_action( 'user_register', array( $this, 'on_user_register' ), 10, 1 );
		add_action( 'delete_user', array( $this, 'on_user_delete' ), 10, 1 );

		// Watched settings
		add_action( 'updated_option', array( $this, 'on_option_updated' ), 10, 3 );
	}

	// ── Handlers ─────────────────────────────────────────────

	/** @param string $plugin_file folder/plugin.php */
	public function on_plugin_activated( string $plugin_file, bool $network_wide = false ): void {
		$this->send(
			'plugin_activate',
			$this->plugin_label( $plugin_file ),
			array( 'file' => $plugin_file, 'network_wide' => $network_wide )
		);
	}

	public function on_plugin_deactivated( string $plugin_file, bool $network_wide = false ): void {
		$this->send(
			'plugin_deactivate',
			$this->plugin_label( $plugin_file ),
			array( 'file' => $plugin_file, 'network_wide' => $network_wide )
		);
	}

	/**
	 * @param \WP_Upgrader          $upgrader
	 * @param array<string,mixed>   $hook_extra
	 */
	public function on_upgrader_complete( $upgrader, array $hook_extra ): void {
		$action = isset( $hook_extra['action'] ) ? (string) $hook_extra['action'] : '';
		$type   = isset( $hook_extra['type'] ) ? (string) $hook_extra['type'] : '';
		if ( 'update' !== $action ) {
			return;
		}

		switch ( $type ) {
			case 'core':
				$this->send(
					'core_update',
					sprintf( __( 'WordPress を %s に更新', 'wpkanri' ), get_bloginfo( 'version' ) ),
					array( 'version' => get_bloginfo( 'version' ) )
				);
				break;

			case 'plugin':
				$plugins = isset( $hook_extra['plugins'] ) && is_array( $hook_extra['plugins'] ) ? $hook_extra['plugins'] : array();
				foreach ( $plugins as $plugin_file ) {
					$this->send(
						'plugin_update',
						$this->plugin_label( (string) $plugin_file ),
						array( 'file' => (string) $plugin_file )
					);
				}
				break;

			case 'theme':
				$themes = isset( $hook_extra['themes'] ) && is_array( $hook_extra['themes'] ) ? $hook_extra['themes'] : array();
				foreach ( $themes as $slug ) {
					$theme = wp_get_theme( (string) $slug );
					$name  = $theme->exists() ? (string) $theme->get( 'Name' ) : (string) $slug;
					$this->send( 'theme_update', $name, array( 'slug' => (string) $slug ) );
				}
				break;
		}
	}

	/** @param int $user_id */
	public function on_user_register( $user_id ): void {
		$user = get_userdata( (int) $user_id );
		if ( false === $user ) {
			return;
		}
		$this->send(
			'user_create',
			(string) $user->user_login,
			array( 'user_id' => (int) $user_id, 'email' => (string) $user->user_email )
		);
	}

	/** @param int $user_id */
	public function on_user_delete( $user_id ): void {
		$user = get_userdata( (int) $user_id );
		$login = false !== $user ? (string) $user->user_login : (string) $user_id;
		$this->send( 'user_delete', $login, array( 'user_id' => (int) $user_id ) );
	}

	/**
	 * @param string $option
	 * @param mixed  $old_value
	 * @param mixed  $value
	 */
	public function on_option_updated( $option, $old_value, $value ): void {
		if ( ! in_array( (string) $option, self::WATCHED_OPTIONS, true ) ) {
			return;
		}
		$this->send(
			'settings_change',
			(string) $option,
			array(
				'from' => is_scalar( $old_value ) ? (string) $old_value : '',
				'to'   => is_scalar( $value ) ? (string) $value : '',
			)
		);
	}

	// ── Internal ─────────────────────────────────────────────

	private function send( string $type, string $label, array $metadata = array() ): void {
		$connector = Connector::instance();
		if ( ! $connector->is_setup_complete() ) {
			return;
		}
		$client = new Api_Client();
		$client->send_activity(
			$connector->get_site_id(),
			$type,
			mb_substr( $label, 0, 200 ),
			$metadata
		);
	}

	private function plugin_label( string $plugin_file ): string {
		if ( ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$path = WP_PLUGIN_DIR . '/' . $plugin_file;
		if ( ! file_exists( $path ) ) {
			return $plugin_file;
		}
		$data = @get_plugin_data( $path, false, false );
		return isset( $data['Name'] ) && '' !== $data['Name'] ? (string) $data['Name'] : $plugin_file;
	}
}
