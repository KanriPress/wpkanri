<?php
/**
 * DB Optimize — light-touch cleanup after updates.
 *
 * Scope is intentionally conservative: anything destructive (auto-drafts,
 * spam comments) is left alone. We only purge the kinds of rows that WP
 * itself would happily regenerate.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DB_Optimize {

	/**
	 * Run all optimizations. Returns a summary report for the caller to log.
	 *
	 * @return array{revisions:int,expired_transients:int,orphan_postmeta:int,optimized_tables:int}
	 */
	public static function run(): array {
		global $wpdb;

		$report = array(
			'revisions'          => 0,
			'expired_transients' => 0,
			'orphan_postmeta'    => 0,
			'optimized_tables'   => 0,
		);

		// ── Remove revisions ──
		$report['revisions'] = (int) $wpdb->query(
			"DELETE FROM {$wpdb->posts} WHERE post_type = 'revision'"
		);

		// ── Remove expired transients ──
		$now = time();
		$expired = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options}
				 WHERE option_name LIKE %s
				 AND option_value < %d",
				$wpdb->esc_like( '_transient_timeout_' ) . '%',
				$now
			)
		);
		foreach ( $expired as $timeout_key ) {
			$key = (string) $timeout_key;
			$value_key = '_transient_' . substr( $key, strlen( '_transient_timeout_' ) );
			delete_option( $key );
			delete_option( $value_key );
			++$report['expired_transients'];
		}

		// ── Same for site transients (multisite) ──
		$expired_site = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options}
				 WHERE option_name LIKE %s
				 AND option_value < %d",
				$wpdb->esc_like( '_site_transient_timeout_' ) . '%',
				$now
			)
		);
		foreach ( $expired_site as $timeout_key ) {
			$key = (string) $timeout_key;
			$value_key = '_site_transient_' . substr( $key, strlen( '_site_transient_timeout_' ) );
			delete_site_option( $key );
			delete_site_option( $value_key );
			++$report['expired_transients'];
		}

		// ── Remove orphan postmeta (parent post gone) ──
		$report['orphan_postmeta'] = (int) $wpdb->query(
			"DELETE pm FROM {$wpdb->postmeta} pm
			 LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
			 WHERE p.ID IS NULL"
		);

		// ── OPTIMIZE core tables ──
		$core_tables = array( $wpdb->posts, $wpdb->postmeta, $wpdb->options, $wpdb->comments, $wpdb->commentmeta );
		foreach ( $core_tables as $table ) {
			// Only runs on MyISAM / InnoDB handles this as a no-op but safe.
			$result = $wpdb->query( "OPTIMIZE TABLE `{$table}`" );
			if ( false !== $result ) {
				++$report['optimized_tables'];
			}
		}

		return $report;
	}
}
