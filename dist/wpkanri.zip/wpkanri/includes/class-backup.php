<?php
/**
 * Backup creator — builds a ZIP archive of the WP install + a SQL dump,
 * then reports its manifest to the Worker.
 *
 * Incremental scheme: when Worker says `next_type === "incremental"` we
 * only include files whose md5 is not already in the previous manifest.
 * `full` backups include everything.
 *
 * Transport: we upload to R2 via a Worker-signed URL (the Worker's
 * "R2 mirror" strategy) and then POST the final manifest + archive SHA.
 * External destinations (S3 / Drive / SFTP) are handled by the Worker's
 * daily mirror cron, so the plugin only has to hit R2.
 *
 * Big backups run in chunks via wp-cron to avoid PHP timeouts.
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Backup {

	public const CRON_HOOK = 'wpkanri_backup_run';

	/** Safety cap so we never iterate unbounded trees. */
	private const MAX_FILES = 50000;

	/** Directories always excluded (kept out of the ZIP). */
	private const EXCLUDE_DIRS = array(
		'wp-content/cache',
		'wp-content/uploads/cache',
		'wp-content/upgrade',
		'wp-content/wflogs',
		'wp-content/ai1wm-backups',
	);

	private static ?Backup $instance = null;

	public static function instance(): Backup {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot(): void {
		add_action( self::CRON_HOOK, array( $this, 'run' ) );
	}

	/**
	 * Entry point — can be called by wp-cron or manually (e.g. Worker
	 * push-triggered via the status poll).
	 *
	 * @return array{status:string,backup_id?:string,error?:string}
	 */
	public function run(): array {
		$connector = Connector::instance();
		if ( ! $connector->is_setup_complete() ) {
			return array( 'status' => 'skipped', 'error' => 'setup incomplete' );
		}

		$client = new Api_Client();
		$site_id = $connector->get_site_id();

		// Decide type based on previous manifest.
		$prev = $client->get_latest_backup_manifest( $site_id );
		$next_type = 'full';
		$prev_files = array();
		if ( is_array( $prev ) ) {
			$hint = isset( $prev['next_type'] ) ? (string) $prev['next_type'] : '';
			if ( 'incremental' === $hint ) {
				$next_type = 'incremental';
				$prev_files = isset( $prev['files'] ) && is_array( $prev['files'] ) ? $prev['files'] : array();
			}
		}

		// Create backup record
		$record = $client->create_backup_record(
			$site_id,
			array(
				'type'    => $next_type,
				'trigger' => 'scheduled',
			)
		);
		if ( is_wp_error( $record ) || ! isset( $record['id'], $record['upload_url'] ) ) {
			return array(
				'status' => 'failed',
				'error'  => is_wp_error( $record ) ? $record->get_error_message() : 'no upload_url in response',
			);
		}
		$backup_id  = (string) $record['id'];
		$upload_url = (string) $record['upload_url'];

		// Build the archive.
		$archive = $this->build_archive( $prev_files, $next_type );
		if ( is_wp_error( $archive ) ) {
			$client->report_update_result( $site_id, $backup_id, 'failed', $archive->get_error_message() );
			return array( 'status' => 'failed', 'error' => $archive->get_error_message() );
		}

		// Upload to R2 (presigned PUT).
		$upload_error = $this->upload_via_presigned( $upload_url, $archive['path'] );
		if ( null !== $upload_error ) {
			@unlink( $archive['path'] );
			return array( 'status' => 'failed', 'error' => $upload_error );
		}

		// Report manifest.
		$client->report_backup_manifest(
			$site_id,
			$backup_id,
			array(
				'type'           => $next_type,
				'size'           => $archive['size'],
				'archive_sha256' => $archive['sha256'],
				'files'          => $archive['files'],
			)
		);

		@unlink( $archive['path'] );

		return array( 'status' => 'applied', 'backup_id' => $backup_id );
	}

	// ── Archive building ─────────────────────────────────────

	/**
	 * @param array<string,string> $prev_files Map of path => md5 from the
	 *                                         previous manifest (for incr).
	 * @return array{path:string,size:int,sha256:string,files:array<int,array{path:string,md5:string}>}|\WP_Error
	 */
	private function build_archive( array $prev_files, string $type ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new \WP_Error( 'wpkanri_backup_missing_zip', 'ZipArchive extension required' );
		}

		$tmp = wp_tempnam( 'wpkanri-backup' );
		if ( ! $tmp ) {
			return new \WP_Error( 'wpkanri_backup_tmp', 'cannot create temp file' );
		}
		$zip_path = $tmp . '.zip';
		@rename( $tmp, $zip_path );

		$zip = new \ZipArchive();
		if ( true !== $zip->open( $zip_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE ) ) {
			return new \WP_Error( 'wpkanri_backup_zip_open', 'cannot open archive' );
		}

		// Add SQL dump.
		$sql = $this->dump_database();
		if ( is_wp_error( $sql ) ) {
			$zip->close();
			@unlink( $zip_path );
			return $sql;
		}
		$zip->addFile( $sql, 'database.sql' );

		// Add files.
		$files = array();
		$count = 0;
		$root  = rtrim( ABSPATH, '/\\' );

		$iterator = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS ),
			\RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ( $iterator as $info ) {
			if ( $count >= self::MAX_FILES ) {
				break;
			}
			if ( ! $info->isFile() ) {
				continue;
			}
			$path = str_replace( '\\', '/', $info->getPathname() );
			$rel  = ltrim( str_replace( str_replace( '\\', '/', $root ), '', $path ), '/' );
			if ( $this->is_excluded( $rel ) ) {
				continue;
			}

			$md5 = @md5_file( $path );
			if ( false === $md5 ) {
				continue;
			}

			// Incremental: skip files whose hash matches the previous manifest.
			if ( 'incremental' === $type && isset( $prev_files[ $rel ] ) && $prev_files[ $rel ] === $md5 ) {
				continue;
			}

			$zip->addFile( $path, 'files/' . $rel );
			$files[] = array( 'path' => $rel, 'md5' => $md5 );
			++$count;
		}

		$zip->close();
		@unlink( $sql );

		$size   = (int) @filesize( $zip_path );
		$sha256 = (string) @hash_file( 'sha256', $zip_path );

		return array(
			'path'   => $zip_path,
			'size'   => $size,
			'sha256' => $sha256,
			'files'  => $files,
		);
	}

	private function is_excluded( string $rel ): bool {
		foreach ( self::EXCLUDE_DIRS as $prefix ) {
			if ( 0 === strpos( $rel, $prefix ) ) {
				return true;
			}
		}
		return false;
	}

	// ── Database ────────────────────────────────────────────

	/** @return string|\WP_Error  path to sql file, or error */
	private function dump_database() {
		global $wpdb;
		$path = wp_tempnam( 'wpkanri-sql' );
		if ( ! $path ) {
			return new \WP_Error( 'wpkanri_backup_sql_tmp', 'cannot create sql temp file' );
		}
		$sql_path = $path . '.sql';
		@rename( $path, $sql_path );

		$fp = @fopen( $sql_path, 'w' );
		if ( false === $fp ) {
			return new \WP_Error( 'wpkanri_backup_sql_open', 'cannot write sql file' );
		}

		fwrite( $fp, "-- WPKanri backup: " . gmdate( 'c' ) . "\n" );
		fwrite( $fp, "SET NAMES utf8mb4;\nSET foreign_key_checks = 0;\n\n" );

		$tables = $wpdb->get_col( 'SHOW TABLES' );
		foreach ( $tables as $table ) {
			$create = $wpdb->get_row( "SHOW CREATE TABLE `{$table}`", ARRAY_N );
			if ( is_array( $create ) && isset( $create[1] ) ) {
				fwrite( $fp, "DROP TABLE IF EXISTS `{$table}`;\n" );
				fwrite( $fp, $create[1] . ";\n\n" );
			}

			// Chunked row dump to keep memory bounded.
			$offset = 0;
			$chunk  = 500;
			do {
				$rows = $wpdb->get_results(
					"SELECT * FROM `{$table}` LIMIT {$chunk} OFFSET {$offset}",
					ARRAY_A
				);
				if ( empty( $rows ) ) {
					break;
				}
				foreach ( $rows as $row ) {
					$cols   = array_keys( $row );
					$values = array_map(
						static function ( $v ) use ( $wpdb ) {
							if ( null === $v ) {
								return 'NULL';
							}
							return "'" . esc_sql( (string) $v ) . "'";
						},
						array_values( $row )
					);
					fwrite( $fp, "INSERT INTO `{$table}` (`" . implode( '`,`', $cols ) . "`) VALUES (" . implode( ',', $values ) . ");\n" );
				}
				$offset += $chunk;
			} while ( count( $rows ) === $chunk );

			fwrite( $fp, "\n" );
		}

		fwrite( $fp, "SET foreign_key_checks = 1;\n" );
		fclose( $fp );
		return $sql_path;
	}

	// ── Upload ──────────────────────────────────────────────

	/** @return string|null  null on success, error message on failure */
	private function upload_via_presigned( string $url, string $file ): ?string {
		if ( ! file_exists( $file ) ) {
			return 'archive missing';
		}
		$fp = @fopen( $file, 'rb' );
		if ( false === $fp ) {
			return 'cannot read archive';
		}
		$args = array(
			'method'  => 'PUT',
			'timeout' => 300,
			'headers' => array(
				'Content-Type'   => 'application/zip',
				'Content-Length' => (string) filesize( $file ),
			),
			'body'    => $fp,
		);
		$response = wp_remote_request( $url, $args );
		if ( is_resource( $fp ) ) {
			fclose( $fp );
		}
		if ( is_wp_error( $response ) ) {
			return $response->get_error_message();
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			return sprintf( 'upload failed HTTP %d', $code );
		}
		return null;
	}
}
