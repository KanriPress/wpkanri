<?php
/**
 * HTTP client for the WPKanri Worker (assist.kanripress.com).
 *
 * Every method returns either the decoded response array on success or a
 * WP_Error on failure (never throws). The client reads the API base and key
 * from Connector so call sites do not have to.
 */

namespace WPKanri;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Api_Client {

	/**
	 * Per-request network timeout.
	 *
	 * 10 s was the original default but trips on checksum-lookup chunks when
	 * the KanriPress Worker cold-starts or a user is on a slow WP host. 45 s
	 * is generous enough to cover Worker cold-starts (~3-5 s) + 100-file KV
	 * lookups (~2-5 s) + 3x retry headroom, while still bounding hung
	 * requests well below the WP admin request timeout.
	 */
	private const TIMEOUT_SECONDS = 45;

	private string $api_base;
	private string $api_key;

	public function __construct( ?string $api_base = null, ?string $api_key = null ) {
		$connector      = Connector::instance();
		$this->api_base = $api_base ?? $connector->get_api_base();
		$this->api_key  = $api_key ?? $connector->get_api_key();
	}

	/** GET /api/v1/public/health */
	public function ping() {
		return $this->request( 'GET', '/api/v1/public/health' );
	}

	/**
	 * POST /api/v1/public/sites/register
	 *
	 * @return array<string,mixed>|WP_Error
	 */
	public function register_site( string $name, string $url ) {
		return $this->request(
			'POST',
			'/api/v1/public/sites/register',
			array(
				'name' => $name,
				'url'  => $url,
			)
		);
	}

	/**
	 * POST /api/v1/public/checksums/lookup
	 *
	 * @param array<int,array{path:string,md5:string}> $files
	 * @return array<string,mixed>|WP_Error
	 */
	public function lookup_checksums( string $version, string $locale, array $files ) {
		return $this->request(
			'POST',
			'/api/v1/public/checksums/lookup',
			array(
				'version' => $version,
				'locale'  => $locale,
				'files'   => array_values( $files ),
			)
		);
	}

	/**
	 * POST /api/v1/public/errors (non-blocking)
	 *
	 * @return array<string,mixed>|WP_Error
	 */
	public function send_error( string $site_id, string $severity, string $message, string $file = '', int $line = 0 ) {
		return $this->request(
			'POST',
			'/api/v1/public/errors',
			array(
				'site_id'  => $site_id,
				'severity' => $severity,
				'message'  => $message,
				'file'     => $file,
				'line'     => $line,
			)
		);
	}

	/**
	 * POST /api/v1/public/carbon
	 *
	 * @return array<string,mixed>|WP_Error
	 */
	public function send_carbon( string $site_id, int $bytes, string $page_url = '' ) {
		$body = array(
			'site_id' => $site_id,
			'bytes'   => $bytes,
		);
		if ( '' !== $page_url ) {
			$body['page_url'] = $page_url;
		}
		return $this->request( 'POST', '/api/v1/public/carbon', $body );
	}

	// ── Status polling ───────────────────────────────────────

	/** GET /api/v1/public/sites/:id/status */
	public function get_site_status( string $site_id ) {
		return $this->request( 'GET', '/api/v1/public/sites/' . rawurlencode( $site_id ) . '/status' );
	}

	/**
	 * GET /api/v1/public/sites/:id/maintenance-template.html
	 * Returns the raw HTML body + etag separately so callers can dedupe
	 * using `If-None-Match`.
	 *
	 * @return array{status:int,body:string,etag:string}|WP_Error
	 */
	public function fetch_maintenance_template( string $site_id, string $if_none_match = '' ) {
		if ( '' === $this->api_key || '' === $this->api_base ) {
			return new WP_Error( 'wpkanri_missing_auth', __( 'API キーまたは Base URL が未設定です。', 'wpkanri' ) );
		}
		$url = untrailingslashit( $this->api_base ) . '/api/v1/public/sites/' . rawurlencode( $site_id ) . '/maintenance-template.html';
		$headers = array(
			'Authorization' => 'Bearer ' . $this->api_key,
			'Accept'        => 'text/html',
		);
		if ( '' !== $if_none_match ) {
			$headers['If-None-Match'] = $if_none_match;
		}
		$response = wp_remote_get( $url, array( 'timeout' => self::TIMEOUT_SECONDS, 'headers' => $headers ) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		return array(
			'status' => (int) wp_remote_retrieve_response_code( $response ),
			'body'   => (string) wp_remote_retrieve_body( $response ),
			'etag'   => (string) wp_remote_retrieve_header( $response, 'etag' ),
		);
	}

	// ── Activity ────────────────────────────────────────────

	/** POST /api/v1/public/activity (non-blocking) */
	public function send_activity( string $site_id, string $type, string $label, array $metadata = array() ) {
		return $this->request_non_blocking(
			'/api/v1/public/activity',
			array(
				'site_id'  => $site_id,
				'type'     => $type,
				'label'    => $label,
				'metadata' => $metadata,
			)
		);
	}

	// ── Updates ─────────────────────────────────────────────

	/** POST /api/v1/sites/:id/updates — detected updates */
	public function report_detected_updates( string $site_id, array $updates ) {
		return $this->request(
			'POST',
			'/api/v1/sites/' . rawurlencode( $site_id ) . '/updates',
			array( 'updates' => $updates )
		);
	}

	/** POST /api/v1/public/sites/:siteId/updates/:updateId/report */
	public function report_update_result( string $site_id, string $update_id, string $status, string $error_message = '' ) {
		$body = array( 'status' => $status );
		if ( '' !== $error_message ) {
			$body['error_message'] = $error_message;
		}
		return $this->request(
			'POST',
			'/api/v1/public/sites/' . rawurlencode( $site_id ) . '/updates/' . rawurlencode( $update_id ) . '/report',
			$body
		);
	}

	// ── Backups ─────────────────────────────────────────────

	/** GET /api/v1/sites/:id/backups/latest/manifest */
	public function get_latest_backup_manifest( string $site_id ) {
		return $this->request(
			'GET',
			'/api/v1/sites/' . rawurlencode( $site_id ) . '/backups/latest/manifest'
		);
	}

	/** POST /api/v1/sites/:id/backups — create backup record */
	public function create_backup_record( string $site_id, array $body ) {
		return $this->request(
			'POST',
			'/api/v1/sites/' . rawurlencode( $site_id ) . '/backups',
			$body
		);
	}

	/** POST /api/v1/sites/:siteId/backups/:backupId/manifest */
	public function report_backup_manifest( string $site_id, string $backup_id, array $body ) {
		return $this->request(
			'POST',
			'/api/v1/sites/' . rawurlencode( $site_id ) . '/backups/' . rawurlencode( $backup_id ) . '/manifest',
			$body
		);
	}

	// ── Snippets ────────────────────────────────────────────

	/** GET /api/v1/public/sites/:id/pending-snippets */
	public function get_pending_snippets( string $site_id ) {
		return $this->request(
			'GET',
			'/api/v1/public/sites/' . rawurlencode( $site_id ) . '/pending-snippets'
		);
	}

	/** POST /api/v1/public/deployments/:id/report */
	public function report_snippet_deployment( string $deployment_id, string $status, array $exec_result ) {
		return $this->request(
			'POST',
			'/api/v1/public/deployments/' . rawurlencode( $deployment_id ) . '/report',
			array(
				'status'      => $status,
				'exec_result' => $exec_result,
			)
		);
	}

	// ── Internal ─────────────────────────────────────────────

	/**
	 * Fire-and-forget POST, used for activity logs / telemetry where we do
	 * not need to wait for the response.
	 */
	private function request_non_blocking( string $path, array $body ): void {
		if ( '' === $this->api_key || '' === $this->api_base ) {
			return;
		}
		wp_remote_post(
			untrailingslashit( $this->api_base ) . $path,
			array(
				'method'   => 'POST',
				'timeout'  => 1,
				'blocking' => false,
				'headers'  => array(
					'Authorization' => 'Bearer ' . $this->api_key,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'     => wp_json_encode( $body ),
			)
		);
	}

	/**
	 * @param array<string,mixed>|null $body
	 * @return array<string,mixed>|WP_Error
	 */
	private function request( string $method, string $path, ?array $body = null ) {
		if ( '' === $this->api_key ) {
			return new WP_Error(
				'wpkanri_missing_api_key',
				__( 'API キーが設定されていません。', 'wpkanri' )
			);
		}
		if ( '' === $this->api_base ) {
			return new WP_Error(
				'wpkanri_missing_api_base',
				__( 'API Base URL が設定されていません。', 'wpkanri' )
			);
		}

		$url = untrailingslashit( $this->api_base ) . $path;
		$args = array(
			'method'  => $method,
			'timeout' => self::TIMEOUT_SECONDS,
			'headers' => array(
				'Authorization' => 'Bearer ' . $this->api_key,
				'Accept'        => 'application/json',
			),
		);

		if ( null !== $body ) {
			$args['headers']['Content-Type'] = 'application/json';
			$args['body']                    = wp_json_encode( $body );
		}

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( $code >= 200 && $code < 300 ) {
			if ( is_array( $data ) ) {
				return $data;
			}
			return new WP_Error(
				'wpkanri_invalid_response',
				__( 'Worker のレスポンスを解析できませんでした。', 'wpkanri' )
			);
		}

		$message = is_array( $data ) && isset( $data['error']['message'] )
			? (string) $data['error']['message']
			: sprintf( 'HTTP %d', $code );

		return new WP_Error(
			'wpkanri_http_error',
			$message,
			array(
				'status' => $code,
				'body'   => $data,
			)
		);
	}
}
