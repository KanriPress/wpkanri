<?php
/**
 * Connector — plugin bootstrap + option management.
 *
 * Responsibilities:
 *  - Singleton entry point called from the main plugin file
 *  - Load translation domain
 *  - Wire up admin page, health endpoint, scanner on plugins_loaded
 *  - Own the read/write of every `wpkanri_*` option so the rest
 *    of the plugin never touches get_option/update_option directly
 *  - Activation / deactivation lifecycle (cron scheduling, default options)
 */

namespace WPKanri;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Connector {

	private static ?Connector $instance = null;

	public static function instance(): Connector {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	// ── Lifecycle ────────────────────────────────────────────

	public function boot(): void {
		add_action( 'init', array( $this, 'load_textdomain' ) );
		add_filter( 'cron_schedules', array( Status_Poller::class, 'register_schedule' ) );

		if ( is_admin() ) {
			Admin_Page::instance()->boot();
		}

		Health::instance()->boot();
		Scanner::instance()->boot();
		Rum::instance()->boot();
		Error_Monitor::instance()->boot();
		Updater::instance()->boot();

		// Modules that depend on cron + API interaction — register only when
		// setup is complete so poll / detect / log / snippet crons never fire
		// with an empty API key.
		if ( $this->is_setup_complete() ) {
			Status_Poller::instance()->boot();
			Update_Detector::instance()->boot();
			Snippets::instance()->boot();
			Backup::instance()->boot();
			Activity_Logger::instance()->boot();
			Connection_Options::instance()->boot();
		}
	}

	public function activate(): void {
		// Seed defaults without clobbering an existing install.
		if ( false === get_option( $this->opt_key( 'api_base' ), false ) ) {
			update_option( $this->opt_key( 'api_base' ), WPKANRI_DEFAULT_API_BASE );
		}
		if ( false === get_option( $this->opt_key( 'api_key' ), false ) ) {
			update_option( $this->opt_key( 'api_key' ), '' );
		}
		if ( false === get_option( $this->opt_key( 'site_id' ), false ) ) {
			update_option( $this->opt_key( 'site_id' ), '' );
		}

		// Schedule the daily scan cron if it is not already pending.
		if ( ! wp_next_scheduled( WPKANRI_CRON_HOOK ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', WPKANRI_CRON_HOOK );
		}

		// Make the 5-minute schedule available before anything tries to use it.
		add_filter( 'cron_schedules', array( Status_Poller::class, 'register_schedule' ) );

		// Schedule polling / detection / snippet crons.
		Status_Poller::schedule();
		Update_Detector::schedule();
		Snippets::schedule();

		// Drop the Emergency Connector helper file on first activation.
		Emergency::instance()->ensure_installed();

		// Trigger the one-shot post-activation redirect to the setup page
		// unless this is a multisite network activation (those redirect loops
		// are famously painful).
		if ( ! is_network_admin() && ! isset( $_GET['activate-multi'] ) ) {
			set_transient( 'wpkanri_activation_redirect', 1, 30 );
		}
	}

	/**
	 * Has the user completed the initial setup? True only when both the API
	 * key and site_id are populated. Used by the admin notice + wizard steps.
	 */
	public function is_setup_complete(): bool {
		return $this->has_api_key() && $this->is_registered();
	}

	// ── White-label support ──────────────────────────────────

	/**
	 * Whether this install should hide KanriPress branding from the global
	 * admin UI (notices, activation redirect, promotional copy). Enabled when:
	 *
	 *  - `WPKANRI_WHITELABEL` is defined and truthy in wp-config.php
	 *  - the filter `wpkanri_whitelabel_mode` returns true
	 *
	 * The settings page itself still shows the configured brand name —
	 * agencies can override that with WPKANRI_BRAND_NAME.
	 */
	public function is_whitelabel_mode(): bool {
		$value = defined( 'WPKANRI_WHITELABEL' ) && WPKANRI_WHITELABEL;
		return (bool) apply_filters( 'wpkanri_whitelabel_mode', $value );
	}

	/**
	 * Brand name displayed in the admin menu + settings page. Defaults to
	 * "WPKanri". Agencies can override with WPKANRI_BRAND_NAME
	 * or the `wpkanri_brand_name` filter.
	 */
	public function get_brand_name(): string {
		$name = defined( 'WPKANRI_BRAND_NAME' ) && is_string( WPKANRI_BRAND_NAME )
			? (string) WPKANRI_BRAND_NAME
			: __( 'WPKanri', 'wpkanri' );
		return (string) apply_filters( 'wpkanri_brand_name', $name );
	}

	/**
	 * Short description used on the settings page. Agencies can override with
	 * WPKANRI_BRAND_DESCRIPTION or the filter.
	 */
	public function get_brand_description(): string {
		$desc = defined( 'WPKANRI_BRAND_DESCRIPTION' ) && is_string( WPKANRI_BRAND_DESCRIPTION )
			? (string) WPKANRI_BRAND_DESCRIPTION
			: __( 'この WordPress サイトを保守管理クラウドに接続します。', 'wpkanri' );
		return (string) apply_filters( 'wpkanri_brand_description', $desc );
	}

	public function deactivate(): void {
		// Keep options so toggling the plugin off/on does not lose the API key.
		$timestamp = wp_next_scheduled( WPKANRI_CRON_HOOK );
		if ( false !== $timestamp ) {
			wp_unschedule_event( $timestamp, WPKANRI_CRON_HOOK );
		}

		Status_Poller::unschedule();
		Update_Detector::unschedule();
		Snippets::unschedule();

		// Leave Emergency file in place — it's the last-resort restore
		// helper. It's only removed on uninstall (not deactivate) via
		// uninstall.php.

		// Also lift any active maintenance lock so the site does not stay
		// in 503 after deactivation.
		Branded_Maintenance::instance()->disable();
		Maintenance::instance()->disable();
	}

	public function load_textdomain(): void {
		load_plugin_textdomain(
			'wpkanri',
			false,
			dirname( plugin_basename( WPKANRI_PLUGIN_FILE ) ) . '/languages'
		);
	}

	// ── Option helpers ───────────────────────────────────────

	public function get_api_base(): string {
		$value = (string) get_option( $this->opt_key( 'api_base' ), WPKANRI_DEFAULT_API_BASE );
		return '' !== $value ? $value : WPKANRI_DEFAULT_API_BASE;
	}

	public function set_api_base( string $value ): void {
		$clean = esc_url_raw( trim( $value ) );
		update_option( $this->opt_key( 'api_base' ), $clean );
	}

	public function get_api_key(): string {
		return (string) get_option( $this->opt_key( 'api_key' ), '' );
	}

	public function set_api_key( string $value ): void {
		$clean = sanitize_text_field( trim( $value ) );
		update_option( $this->opt_key( 'api_key' ), $clean );
	}

	public function has_api_key(): bool {
		return '' !== $this->get_api_key();
	}

	/** Mask all but the first 8 chars after the kpa_live_ prefix. */
	public function masked_api_key(): string {
		$key = $this->get_api_key();
		if ( '' === $key ) {
			return '';
		}
		if ( strlen( $key ) <= 17 ) {
			return str_repeat( '•', strlen( $key ) );
		}
		return substr( $key, 0, 17 ) . '…';
	}

	public function get_site_id(): string {
		return (string) get_option( $this->opt_key( 'site_id' ), '' );
	}

	public function set_site_id( string $value ): void {
		update_option( $this->opt_key( 'site_id' ), sanitize_text_field( $value ) );
	}

	public function is_registered(): bool {
		return '' !== $this->get_site_id();
	}

	/** @return array<string,mixed>|null */
	public function get_last_scan(): ?array {
		$value = get_option( $this->opt_key( 'last_scan' ), null );
		return is_array( $value ) ? $value : null;
	}

	/** @param array<string,mixed> $value */
	public function set_last_scan( array $value ): void {
		update_option( $this->opt_key( 'last_scan' ), $value );
	}

	public function opt_key( string $suffix ): string {
		return WPKANRI_OPTION_PREFIX . $suffix;
	}
}
