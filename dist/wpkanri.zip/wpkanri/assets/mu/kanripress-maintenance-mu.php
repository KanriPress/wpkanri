<?php
/**
 * Plugin Name: WPKanri Maintenance (MU)
 * Description: Maintenance page handler for WPKanri. Auto-installed by the main plugin.
 * Version:     1.0.0
 * Author:      KanriPress
 *
 * This mu-plugin has two responsibilities:
 *
 *   1. Serve the branded maintenance HTML (ABSPATH/kanripress-maintenance.html)
 *      directly for environments where Apache .htaccess rewriting does not
 *      fire — nginx, IIS, LiteSpeed-without-mod_rewrite. Fires in
 *      `muplugins_loaded` (the earliest WP hook) so we respond before any
 *      plugin or theme boots.
 *
 *   2. Override the default `wp_maintenance()` message so even the
 *      core-served fallback page shows the agency's text.
 *
 * Bypass (for the admin adjusting things during maintenance):
 *   - Cookie `kanripress_bypass=<32-hex token>` matching the saved token
 *   - OR the current user is logged in with `manage_options`
 *
 * The admin-auth check runs lazily (`pluggable.php` is not loaded yet when
 * mu-plugins run), so we only check the cookie early and defer user-cap
 * checks to the later fall-through.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── 1. Non-Apache fallback: serve branded HTML directly ──

( static function () {
	$flag = ABSPATH . 'kanripress-maintenance.flag';
	if ( ! file_exists( $flag ) ) {
		return;
	}

	$html = ABSPATH . 'kanripress-maintenance.html';
	if ( ! file_exists( $html ) ) {
		return;
	}

	$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '/';

	// Let the maintenance HTML itself through.
	if ( 0 === strpos( $request_uri, '/kanripress-maintenance.html' ) ) {
		return;
	}

	// Let static assets through so the page's CSS / images / webfonts load.
	if ( preg_match( '~\.(css|js|png|jpg|jpeg|svg|gif|webp|ico|woff2?|ttf|eot)(\?|$)~i', $request_uri ) ) {
		return;
	}

	// Let wp-login.php / wp-admin through so the admin can still log in.
	if ( preg_match( '~(^/wp-login\.php|^/wp-admin)~', $request_uri ) ) {
		return;
	}

	// Bypass cookie — signed 32-hex token saved in wp_options.
	if ( isset( $_COOKIE['kanripress_bypass'] ) && preg_match( '/^[a-f0-9]{32}$/', (string) $_COOKIE['kanripress_bypass'] ) ) {
		$expected = (string) get_option( 'wpkanri_maintenance_bypass_token', '' );
		if ( '' !== $expected && hash_equals( $expected, (string) $_COOKIE['kanripress_bypass'] ) ) {
			return;
		}
	}

	// Serve 503 with the branded HTML body.
	status_header( 503 );
	nocache_headers();
	if ( ! headers_sent() ) {
		header( 'Retry-After: 1800' );
		header( 'Content-Type: text/html; charset=utf-8' );
	}
	readfile( $html );
	exit;
} )();

// ── 2. Override core wp_maintenance() text ──

add_action(
	'init',
	static function () {
		// Issue the admin bypass cookie so authenticated admins can keep
		// working while maintenance is active.
		if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
			$token = (string) get_option( 'wpkanri_maintenance_bypass_token', '' );
			if ( '' !== $token && empty( $_COOKIE['kanripress_bypass'] ) ) {
				if ( ! headers_sent() ) {
					setcookie(
						'kanripress_bypass',
						$token,
						array(
							'expires'  => time() + HOUR_IN_SECONDS,
							'path'     => '/',
							'secure'   => is_ssl(),
							'httponly' => true,
							'samesite' => 'Lax',
						)
					);
				}
			}
		}
	},
	1
);
