/**
 * WPKanri — RUM (Real User Monitoring) + Carbon beacon.
 *
 * Collects Core Web Vitals via web-vitals.js (loaded separately as IIFE)
 * and sends them to the KanriPress Worker via Beacon API on page unload.
 * Also measures transfer bytes for CO2 carbon tracking.
 *
 * @see https://github.com/GoogleChrome/web-vitals
 */
(function () {
	'use strict';

	/* global webVitals, wpkanriRumConfig */
	if ( typeof wpkanriRumConfig === 'undefined' ) {
		return;
	}

	var config = wpkanriRumConfig;
	if ( ! config.siteId || ! config.apiKey ) {
		return;
	}

	var metrics = {};

	function collect( metric ) {
		metrics[ metric.name ] = metric.value;
	}

	// Register web-vitals callbacks.
	if ( typeof webVitals !== 'undefined' ) {
		webVitals.onLCP( collect );
		webVitals.onINP( collect );
		webVitals.onCLS( collect );
		webVitals.onFCP( collect );
		webVitals.onTTFB( collect );
	}

	var sent = false;

	function sendBeacons() {
		if ( sent ) {
			return;
		}
		sent = true;

		var fetchOpts = {
			method:    'POST',
			keepalive: true,
			headers:   {
				'Content-Type':  'application/json',
				'Authorization': 'Bearer ' + config.apiKey,
			},
		};

		// ── RUM beacon ──
		if ( Object.keys( metrics ).length > 0 ) {
			var rumPayload = {
				site_id:  config.siteId,
				page_url: window.location.pathname,
				device:   getDeviceType(),
			};

			if ( typeof metrics.LCP  === 'number' ) { rumPayload.lcp  = Math.round( metrics.LCP ); }
			if ( typeof metrics.INP  === 'number' ) { rumPayload.inp  = Math.round( metrics.INP ); }
			if ( typeof metrics.CLS  === 'number' ) { rumPayload.cls  = parseFloat( metrics.CLS.toFixed( 4 ) ); }
			if ( typeof metrics.FCP  === 'number' ) { rumPayload.fcp  = Math.round( metrics.FCP ); }
			if ( typeof metrics.TTFB === 'number' ) { rumPayload.ttfb = Math.round( metrics.TTFB ); }

			try {
				fetch( config.endpoint, Object.assign( {}, fetchOpts, { body: JSON.stringify( rumPayload ) } ) );
			} catch ( e ) { /* best-effort */ }
		}

		// ── Carbon beacon ──
		var transferSize = getTransferSize();
		if ( transferSize > 0 && config.carbonEndpoint ) {
			var carbonPayload = {
				site_id:  config.siteId,
				bytes:    transferSize,
				page_url: window.location.pathname,
			};
			try {
				fetch( config.carbonEndpoint, Object.assign( {}, fetchOpts, { body: JSON.stringify( carbonPayload ) } ) );
			} catch ( e ) { /* best-effort */ }
		}
	}

	function getTransferSize() {
		try {
			var entries = performance.getEntriesByType( 'navigation' );
			if ( entries.length > 0 && typeof entries[0].transferSize === 'number' ) {
				return entries[0].transferSize;
			}
		} catch ( e ) {
			// Silently fail on browsers that don't support Navigation Timing L2.
		}
		return 0;
	}

	function getDeviceType() {
		var w = window.innerWidth || document.documentElement.clientWidth || 0;
		if ( w < 768 )  { return 'mobile'; }
		if ( w < 1024 ) { return 'tablet'; }
		return 'desktop';
	}

	// Send on page visibility change or unload.
	document.addEventListener( 'visibilitychange', function () {
		if ( document.visibilityState === 'hidden' ) {
			sendBeacons();
		}
	} );
	window.addEventListener( 'pagehide', sendBeacons );
})();
