/**
 * WPKanri — RUM (Real User Monitoring) + Carbon beacon.
 *
 * Collects Core Web Vitals via web-vitals.js (loaded separately as IIFE)
 * and POSTs them to a same-origin admin-ajax endpoint on page unload.
 * The PHP handler proxies the payload to the KanriPress Worker so the
 * API key never leaves the server.
 *
 * @see https://github.com/GoogleChrome/web-vitals
 */
(function () {
	'use strict';

	/* global webVitals, wpkanriRumConfig */
	if ( typeof wpkanriRumConfig === 'undefined' ) {
		return;
	}

	var config = wpkanriRumConfig;
	if ( ! config.siteId || ! config.endpoint ) {
		return;
	}

	var metrics = {};

	function collect( metric ) {
		metrics[ metric.name ] = metric.value;
	}

	if ( typeof webVitals !== 'undefined' ) {
		webVitals.onLCP( collect );
		webVitals.onINP( collect );
		webVitals.onCLS( collect );
		webVitals.onFCP( collect );
		webVitals.onTTFB( collect );
	}

	var sent = false;

	function post( url, body ) {
		try {
			fetch( url, {
				method:      'POST',
				keepalive:   true,
				credentials: 'same-origin',
				headers:     { 'Content-Type': 'application/json' },
				body:        JSON.stringify( body ),
			} );
		} catch ( e ) { /* best-effort */ }
	}

	function sendBeacons() {
		if ( sent ) {
			return;
		}
		sent = true;

		if ( Object.keys( metrics ).length > 0 ) {
			var rumPayload = {
				site_id:  config.siteId,
				page_url: window.location.pathname,
				device:   getDeviceType(),
			};

			if ( typeof metrics.LCP  === 'number' ) { rumPayload.lcp  = Math.round( metrics.LCP ); }
			if ( typeof metrics.INP  === 'number' ) { rumPayload.inp  = Math.round( metrics.INP ); }
			if ( typeof metrics.CLS  === 'number' ) { rumPayload.cls  = parseFloat( metrics.CLS.toFixed( 4 ) ); }
			if ( typeof metrics.FCP  === 'number' ) { rumPayload.fcp  = Math.round( metrics.FCP ); }
			if ( typeof metrics.TTFB === 'number' ) { rumPayload.ttfb = Math.round( metrics.TTFB ); }

			post( config.endpoint, rumPayload );
		}

		var transferSize = getTransferSize();
		if ( transferSize > 0 && config.carbonEndpoint ) {
			post( config.carbonEndpoint, {
				site_id:  config.siteId,
				bytes:    transferSize,
				page_url: window.location.pathname,
			} );
		}
	}

	function getTransferSize() {
		try {
			var entries = performance.getEntriesByType( 'navigation' );
			if ( entries.length > 0 && typeof entries[0].transferSize === 'number' ) {
				return entries[0].transferSize;
			}
		} catch ( e ) {
			// Silently fail on browsers that don't support Navigation Timing L2.
		}
		return 0;
	}

	function getDeviceType() {
		var w = window.innerWidth || document.documentElement.clientWidth || 0;
		if ( w < 768 )  { return 'mobile'; }
		if ( w < 1024 ) { return 'tablet'; }
		return 'desktop';
	}

	document.addEventListener( 'visibilitychange', function () {
		if ( document.visibilityState === 'hidden' ) {
			sendBeacons();
		}
	} );
	window.addEventListener( 'pagehide', sendBeacons );
})();
