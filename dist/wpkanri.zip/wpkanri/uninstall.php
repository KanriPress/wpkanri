<?php
/**
 * WPKanri — uninstall cleanup.
 *
 * Runs only when the user deletes the plugin from the WordPress admin.
 * Removes every `wpkanri_*` option, every scheduled cron, the
 * Emergency Connector file, the maintenance MU-plugin, and the
 * maintenance state files.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// ── Options ──
$emergency_filename = (string) get_option( 'wpkanri_emergency_filename', '' );

$wpdb->query(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE 'wpkanri_%'"
);

// ── Crons ──
foreach (
	array(
		'wpkanri_daily_scan',
		'wpkanri_status_poll',
		'wpkanri_update_detect',
		'wpkanri_snippets_poll',
		'wpkanri_backup_run',
	) as $hook
) {
	wp_clear_scheduled_hook( $hook );
}

// ── Emergency Connector ──
if ( '' !== $emergency_filename && defined( 'WP_CONTENT_DIR' ) ) {
	$emergency_path = WP_CONTENT_DIR . '/' . $emergency_filename;
	if ( file_exists( $emergency_path ) ) {
		@unlink( $emergency_path );
	}
}

// ── Maintenance artefacts ──
if ( defined( 'ABSPATH' ) ) {
	foreach ( array( '.maintenance', 'kanripress-maintenance.flag', 'kanripress-maintenance.html' ) as $leftover ) {
		$path = ABSPATH . $leftover;
		if ( file_exists( $path ) ) {
			@unlink( $path );
		}
	}

	// Strip BEGIN/END KanriPress Maintenance block from .htaccess if present.
	$htaccess = ABSPATH . '.htaccess';
	if ( file_exists( $htaccess ) ) {
		$content = (string) @file_get_contents( $htaccess );
		$clean   = preg_replace( '/# BEGIN KanriPress Maintenance.*?# END KanriPress Maintenance\s*/s', '', $content );
		if ( null !== $clean && $clean !== $content ) {
			@file_put_contents( $htaccess, $clean );
		}
	}
}

// ── MU-plugin ──
$mu_dir = defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/mu-plugins' : '' );
if ( '' !== $mu_dir ) {
	$mu_path = trailingslashit( $mu_dir ) . 'kanripress-maintenance-mu.php';
	if ( file_exists( $mu_path ) ) {
		@unlink( $mu_path );
	}
}
