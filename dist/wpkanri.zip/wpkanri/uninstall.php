<?php
/**
 * WPKanri — uninstall cleanup.
 *
 * Runs only when the user deletes the plugin from the WordPress admin.
 * Removes every `wpkanri_*` option, every scheduled cron, the
 * Emergency Connector file, the maintenance MU-plugin, and the
 * maintenance state files.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$cron_hooks = array(
	'wpkanri_daily_scan',
	'wpkanri_scan_manual_now',
	'wpkanri_status_poll',
	'wpkanri_update_detect',
	'wpkanri_snippets_poll',
	'wpkanri_backup_run',
);

$option_like = $wpdb->esc_like( 'wpkanri_' ) . '%';

$wpkanri_cleanup_site = static function () use ( $wpdb, $cron_hooks, $option_like ) {
	$emergency_filename = (string) get_option( 'wpkanri_emergency_filename', '' );

	// ── Options ──
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$option_like
		)
	);

	// ── Crons ──
	foreach ( $cron_hooks as $hook ) {
		wp_clear_scheduled_hook( $hook );
	}

	// ── Emergency Connector ──
	if ( '' !== $emergency_filename && defined( 'WP_CONTENT_DIR' ) ) {
		$emergency_path = WP_CONTENT_DIR . '/' . $emergency_filename;
		if ( file_exists( $emergency_path ) ) {
			@unlink( $emergency_path );
		}
	}
};

if ( is_multisite() ) {
	$site_ids = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
	foreach ( $site_ids as $blog_id ) {
		switch_to_blog( (int) $blog_id );
		$wpkanri_cleanup_site();
		restore_current_blog();
	}

	// Sitemeta (network-wide options) cleanup.
	if ( isset( $wpdb->sitemeta ) ) {
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s",
				$option_like
			)
		);
	}
} else {
	$wpkanri_cleanup_site();
}

// ── Maintenance artefacts (filesystem is single-instance regardless of multisite) ──
if ( defined( 'ABSPATH' ) ) {
	foreach ( array( '.maintenance', 'kanripress-maintenance.flag', 'kanripress-maintenance.html' ) as $leftover ) {
		$path = ABSPATH . $leftover;
		if ( file_exists( $path ) ) {
			@unlink( $path );
		}
	}

	// Strip BEGIN/END KanriPress Maintenance block from .htaccess if present.
	$htaccess = ABSPATH . '.htaccess';
	if ( file_exists( $htaccess ) ) {
		$content = (string) @file_get_contents( $htaccess );
		$clean   = preg_replace( '/# BEGIN KanriPress Maintenance.*?# END KanriPress Maintenance\s*/s', '', $content );
		if ( null !== $clean && $clean !== $content ) {
			@file_put_contents( $htaccess, $clean );
		}
	}
}

// ── MU-plugin ──
$mu_dir = defined( 'WPMU_PLUGIN_DIR' ) ? WPMU_PLUGIN_DIR : ( defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/mu-plugins' : '' );
if ( '' !== $mu_dir ) {
	$mu_path = trailingslashit( $mu_dir ) . 'kanripress-maintenance-mu.php';
	if ( file_exists( $mu_path ) ) {
		@unlink( $mu_path );
	}
}
