<?php
/**
 * Plugin Name: WPKanri
 * Plugin URI:  https://kanripress.com
 * Description: WPKanri connector plugin. Lightweight connector that links this WordPress site to the WPKanri cloud (assist.kanripress.com) for backups, monitoring, updates, and scans.
 * Version:     0.0.4
 * Author:      KanriPress
 * License:     GPL-2.0-or-later
 * Text Domain: wpkanri
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WPKANRI_VERSION', '0.0.4' );
define( 'WPKANRI_PLUGIN_FILE', __FILE__ );
define( 'WPKANRI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPKANRI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPKANRI_REST_NAMESPACE', 'wpkanri/v1' );
define( 'WPKANRI_DEFAULT_API_BASE', 'https://assist.kanripress.com' );
define( 'WPKANRI_CRON_HOOK', 'wpkanri_daily_scan' );
define( 'WPKANRI_OPTION_PREFIX', 'wpkanri_' );

require_once WPKANRI_PLUGIN_DIR . 'includes/class-connector.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-api-client.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-scanner.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-health.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-rum.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-error-monitor.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-updater.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-cache-clear.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-db-optimize.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-maintenance.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-branded-maintenance.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-update-processor.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-update-detector.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-status-poller.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-activity-logger.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-backup.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-snippets.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-emergency.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-connection-options.php';
require_once WPKANRI_PLUGIN_DIR . 'includes/class-admin-page.php';

register_activation_hook(
	__FILE__,
	static function () {
		\WPKanri\Connector::instance()->activate();
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		\WPKanri\Connector::instance()->deactivate();
	}
);

add_action(
	'plugins_loaded',
	static function () {
		\WPKanri\Connector::instance()->boot();
	}
);
